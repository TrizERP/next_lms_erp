-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: senayan
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `senayan`
--

USE `senayan`;

--
-- Table structure for table `backup_log`
--

DROP TABLE IF EXISTS `backup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_log` (
  `backup_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `backup_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backup_file` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`backup_log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_log`
--

LOCK TABLES `backup_log` WRITE;
/*!40000 ALTER TABLE `backup_log` DISABLE KEYS */;
INSERT INTO `backup_log` VALUES (1,1,'2011-01-11 13:10:35','/var/www/library/files/backup/backup_20110111_131035.sql.tar.gz');
/*!40000 ALTER TABLE `backup_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio`
--

DROP TABLE IF EXISTS `biblio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio` (
  `biblio_id` int(11) NOT NULL AUTO_INCREMENT,
  `gmd_id` int(3) DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `edition` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isbn_issn` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `publish_year` int(4) DEFAULT NULL,
  `collation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `series_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_id` char(5) COLLATE utf8_unicode_ci DEFAULT 'en',
  `source` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish_place_id` int(11) DEFAULT NULL,
  `classification` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_att` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opac_hide` smallint(1) DEFAULT '0',
  `promoted` smallint(1) DEFAULT '0',
  `labels` text COLLATE utf8_unicode_ci,
  `frequency_id` int(11) NOT NULL DEFAULT '0',
  `spec_detail_info` text COLLATE utf8_unicode_ci,
  `input_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`biblio_id`),
  KEY `references_idx` (`gmd_id`,`publisher_id`,`language_id`,`publish_place_id`),
  KEY `classification` (`classification`),
  KEY `biblio_flag_idx` (`opac_hide`,`promoted`),
  FULLTEXT KEY `title_ft_idx` (`title`,`series_title`),
  FULLTEXT KEY `notes_ft_idx` (`notes`),
  FULLTEXT KEY `labels` (`labels`)
) ENGINE=MyISAM AUTO_INCREMENT=478 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio`
--

LOCK TABLES `biblio` WRITE;
/*!40000 ALTER TABLE `biblio` DISABLE KEYS */;
INSERT INTO `biblio` VALUES (1,1,'PHP 5 for dummies',NULL,'0764541668',1,2004,'xiv, 392 p. : ill. ; 24 cm.','For dummies','005.13/3-22 Jan p','en',NULL,1,'005.13/3 22',NULL,'php5_dummies.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 15:36:50','2007-11-29 16:26:59'),(3,1,'The Definitive Guide to MySQL 5',NULL,'9781590595350',3,2005,'784p.','Definitive Guide Series','005.75/85-22 Kof d','en',NULL,NULL,'005.75/85 22',NULL,'mysql_def_guide.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:01:08','2007-11-29 16:26:33'),(4,1,'Cathedral and the Bazaar: Musings on Linux and Open Source by an Accidental Revolutionary',NULL,'0-596-00108-8',2,2001,'208p.',NULL,'005.4/3222 Ray c','en',NULL,2,'005.4/32 22','The Cathedral & the Bazaar is a must for anyone who cares about the future of the computer industry or the dynamics of the information economy. This revised and expanded paperback edition includes new material on open source developments in 1999 and 2000. Raymond\'s clear and effective writing style accurately describing the benefits of open source software has been key to its success. (Source: http://safari.oreilly.com/0596001088)','cathedral_bazaar.jpg','cathedral-bazaar.pdf',0,0,NULL,0,NULL,'2007-11-29 16:14:44','2007-11-29 16:25:43'),(5,1,'Producing open source software : how to run a successful free software project','1st ed.','9780596007591',2,2005,'xx, 279 p. ; 24 cm.',NULL,'005.1-22 Fog p','en',NULL,2,'005.1 22','Includes index.','producing_oss.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:20:45','2007-11-29 16:31:21'),(6,1,'PostgreSQL : a comprehensive guide to building, programming, and administering PostgreSQL databases','1st ed.','0735712573',4,2003,'xvii, 790 p. : ill. ; 23cm.','DeveloperÃ¢â‚¬â„¢s library','005.75/85-22 Kor p','en',NULL,3,'005.75/85 22','PostgreSQL is the world\'s most advanced open-source database. PostgreSQL is the most comprehensive, in-depth, and easy-to-read guide to this award-winning database. This book starts with a thorough overview of SQL, a description of all PostgreSQL data types, and a complete explanation of PostgreSQL commands.','postgresql.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:29:33','0000-00-00 00:00:00'),(7,1,'Web application architecture : principles, protocols, and practices',NULL,'0471486566',5,2003,'xi, 357 p. : ill. ; 23 cm.',NULL,'005.7/2-21 Leo w','en',NULL,1,'005.7/2 21','An in-depth examination of the core concepts and general principles of Web application development.\r\nThis book uses examples from specific technologies (e.g., servlet API or XSL), without promoting or endorsing particular platforms or APIs. Such knowledge is critical when designing and debugging complex systems. This conceptual understanding makes it easier to learn new APIs that arise in the rapidly changing Internet environment.','webapp_arch.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:41:57','2007-11-29 16:32:46'),(8,1,'Ajax : creating Web pages with asynchronous JavaScript and XML','','9780132272674',6,2007,'xxii, 384 p. : ill. ; 24 cm.','Bruce PerensÃ¢â‚¬â„¢ Open Source series','006.7/86-22 Woy a','en',NULL,4,'006.7/86 22','Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.','ajax.jpg',NULL,0,1,NULL,0,'','2007-11-29 16:47:20','2011-01-13 13:22:23'),(9,1,'The organization of information','2nd ed.','1563089769',7,2004,'xxvii, 417 p. : ill. ; 27 cm.','Library and information science text series','025-22 Tay o','en',NULL,5,'025 22','A basic textbook for students of library and information studies, and a guide for practicing school library media specialists. Describes the impact of global forces and the school district on the development and operation of a media center, the technical and human side of management, programmatic activities, supportive services to students, and the quality and quantity of resources available to support programs.','organization_information.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:54:12','2007-11-29 16:27:20'),(10,1,'Library and Information Center Management','7th ed.','9781591584063',7,2007,'xxviii, 492 p. : ill. ; 27 cm.','Library and information science text series','025.1-22 Stu l','en',NULL,5,'025.1 22',NULL,'library_info_center.JPG',NULL,0,0,NULL,0,NULL,'2007-11-29 16:58:51','2007-11-29 16:27:40'),(11,1,'Information Architecture for the World Wide Web: Designing Large-Scale Web Sites','2nd ed.','9780596000356',2,2002,'500p.',NULL,'006.7-22 Mor i','en',NULL,6,'006.7 22','Information Architecture for the World Wide Web is about applying the principles of architecture and library science to web site design. Each website is like a public building, available for tourists and regulars alike to breeze through at their leisure. The job of the architect is to set up the framework for the site to make it comfortable and inviting for people to visit, relax in, and perhaps even return to someday.','information_arch.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:26:14','2007-11-29 16:32:25'),(12,1,'Corruption and development',NULL,'9780714649023',8,1998,'166 p. : ill. ; 22 cm.',NULL,'364.1 Rob c','en',NULL,7,'364.1/322/091724 21','The articles assembled in this volume offer a fresh approach to analysing the problem of corruption in developing countries and the k means to tackle the phenomenon.','corruption_development.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:45:30','2007-11-29 16:20:53'),(13,1,'Corruption and development : the anti-corruption campaigns',NULL,'0230525504',9,2007,'310p.',NULL,'364.1 Bra c','en',NULL,8,'364.1/323091724 22','This book provides a multidisciplinary interrogation of the global anti-corruption campaigns of the last ten years, arguing that while some positive change is observable, the period is also replete with perverse consequences and unintended outcomes','corruption_development_anti_campaign.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:49:49','2007-11-29 16:19:48'),(14,1,'Pigs at the trough : how corporate greed and political corruption are undermining America',NULL,'1400047714',10,2003,'275 p. ; 22 cm.',NULL,'364.1323 Huf p','en',NULL,8,'364.1323',NULL,'pigs_at_trough.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:56:00','2007-11-29 16:18:33'),(15,1,'Lords of poverty : the power, prestige, and corruption of the international aid business',NULL,'9780871134691',11,1994,'xvi, 234 p. ; 22 cm.',NULL,'338.9 Han l','en',NULL,8,'338.9/1/091724 20','Lords of Poverty is a case study in betrayals of a public trust. The shortcomings of aid are numerous, and serious enough to raise questions about the viability of the practice at its most fundamental levels. Hancocks report is thorough, deeply shocking, and certain to cause critical reevaluation of the governments motives in giving foreign aid, and of the true needs of our intended beneficiaries.','lords_of_poverty.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 18:08:13','2007-11-29 16:13:11'),(475,1,'Ajax : creating Web pages with asynchronous JavaScript and XML','','9780132272674',6,2007,'xxii, 384 p. : ill. ; 24 cm.','Bruce PerensÃ¢â‚¬â„¢ Open Source series','006.7/86-22 Woy a','en',NULL,4,'006.7/86 22','Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.',NULL,NULL,0,1,NULL,0,'','2011-01-18 12:52:35','2011-01-18 12:52:35'),(17,1,'media','','',NULL,0,'','','','',NULL,NULL,'','',NULL,NULL,0,0,'a:1:{i:0;a:2:{i:0;s:16:\"label-multimedia\";i:1;s:15:\"www.youtube.com\";}}',0,'','2011-01-12 15:22:44','2011-01-12 15:23:24'),(18,1,'gg','1','',NULL,0,'','','','',NULL,NULL,'','',NULL,NULL,0,1,NULL,0,'','2011-01-12 16:59:52','2011-01-12 17:00:21'),(477,1,'Learn PHP5','5th','123456789',3,2009,'php5','1001','201021','en',NULL,6,'','Learn PHP5 Technology','images.jpg.jpg',NULL,0,1,'a:3:{i:0;a:2:{i:0;s:9:\"label-new\";i:1;s:4:\"PHP5\";}i:1;a:2:{i:0;s:14:\"label-favorite\";i:1;s:11:\"www.php.net\";}i:2;a:2:{i:0;s:16:\"label-multimedia\";i:1;s:42:\"http://www.youtube.com/watch?v=17aAuMVippQ\";}}',8,'Learn PHP Technology','2011-01-21 13:45:56','2011-01-21 13:54:37'),(476,1,'Ajax : creating Web pages with asynchronous JavaScript and XML','','9780132272674',6,2007,'xxii, 384 p. : ill. ; 24 cm.','Bruce PerensÃ¢â‚¬â„¢ Open Source series','006.7/86-22 Woy a','en',NULL,4,'006.7/86 22','Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.',NULL,NULL,0,1,NULL,0,'','2011-01-18 12:52:42','2011-01-18 12:52:42');
/*!40000 ALTER TABLE `biblio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_attachment`
--

DROP TABLE IF EXISTS `biblio_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_attachment` (
  `biblio_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  `access_type` enum('public','private') COLLATE utf8_unicode_ci NOT NULL,
  `access_limit` text COLLATE utf8_unicode_ci,
  KEY `biblio_id` (`biblio_id`),
  KEY `file_id` (`file_id`),
  KEY `biblio_id_2` (`biblio_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_attachment`
--

LOCK TABLES `biblio_attachment` WRITE;
/*!40000 ALTER TABLE `biblio_attachment` DISABLE KEYS */;
INSERT INTO `biblio_attachment` VALUES (1,0,'public','a:1:{i:0;s:1:\"1\";}');
/*!40000 ALTER TABLE `biblio_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_author`
--

DROP TABLE IF EXISTS `biblio_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_author` (
  `biblio_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biblio_id`,`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_author`
--

LOCK TABLES `biblio_author` WRITE;
/*!40000 ALTER TABLE `biblio_author` DISABLE KEYS */;
INSERT INTO `biblio_author` VALUES (1,1,1),(3,7,1),(3,8,2),(4,9,1),(5,10,1),(6,11,1),(6,12,2),(7,13,1),(7,14,2),(8,15,1),(9,16,1),(10,17,1),(10,18,2),(11,19,1),(11,20,2),(12,21,1),(13,22,1),(14,23,1),(15,24,1),(477,1,1),(18,1,1),(20,26,2),(21,27,2),(22,28,2),(23,29,2),(24,30,2),(25,31,2),(26,32,2),(27,33,2),(28,34,2),(29,35,2),(30,36,2),(31,37,2),(32,38,2),(33,39,2),(34,40,2),(35,41,2),(36,42,2),(37,43,2),(38,44,2),(39,45,2),(40,46,2),(41,47,2),(42,48,2),(43,49,2),(44,50,2),(45,51,2),(46,52,2),(47,53,2),(48,54,2),(49,55,2),(50,56,2),(51,57,2),(52,58,2),(53,59,2),(54,60,2),(55,61,2),(56,62,2),(57,63,2),(58,64,2),(59,65,2),(60,66,2),(61,67,2),(62,68,2),(63,69,2),(64,70,2),(65,71,2),(66,72,2),(67,73,2),(68,74,2),(69,75,2),(70,76,2),(71,77,2);
/*!40000 ALTER TABLE `biblio_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_custom`
--

DROP TABLE IF EXISTS `biblio_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_custom` (
  `biblio_id` int(11) NOT NULL,
  PRIMARY KEY (`biblio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='one to one relation with real biblio table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_custom`
--

LOCK TABLES `biblio_custom` WRITE;
/*!40000 ALTER TABLE `biblio_custom` DISABLE KEYS */;
/*!40000 ALTER TABLE `biblio_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_topic`
--

DROP TABLE IF EXISTS `biblio_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_topic` (
  `biblio_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biblio_id`,`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_topic`
--

LOCK TABLES `biblio_topic` WRITE;
/*!40000 ALTER TABLE `biblio_topic` DISABLE KEYS */;
INSERT INTO `biblio_topic` VALUES (1,1,1),(1,2,2),(3,1,1),(3,6,2),(3,7,2),(4,4,1),(4,8,2),(5,8,1),(5,9,2),(6,1,1),(6,7,2),(7,2,1),(7,10,2),(8,1,1),(8,2,2),(9,11,1),(9,12,2),(9,13,2),(10,11,1),(10,14,2),(12,15,1),(12,16,2),(13,15,1),(14,15,1),(15,15,1),(15,17,2),(20,18,2),(477,1,1);
/*!40000 ALTER TABLE `biblio_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `content_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `content_path` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`content_id`),
  KEY `content_path` (`content_path`),
  FULLTEXT KEY `content_title` (`content_title`),
  FULLTEXT KEY `content_desc` (`content_desc`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,'Library Information','<h3>Contact Information</h3>\r\n<p><strong>Address :</strong> <br /> Jenderal Sudirman Road, Senayan, Jakarta, Indonesia - Postal Code : 10270 <br /> <strong>Phone Number :</strong> <br /> (021) 5711144 <br /> <strong>Fax Number :</strong> <br /> (021) 5711144</p>\r\n<h3>Opening Hours</h3>\r\n<p><strong>Monday - Friday :</strong> <br /> Open : 08.00 AM<br /> Break : 12.00 - 13.00 PM<br /> Close : 20.00 PM <br /> <strong>Saturday  :</strong> <br /> Open : 08.00 AM<br /> Break : 12.00 - 13.00 PM<br /> Close : 17.00 PM</p>\r\n<h3>Collections</h3>\r\n<p>We have many types of collections in our library, range from Fictions to Sciences Material, from printed material to digital collections such CD-ROM, CD, VCD and DVD. We also collect daily serials publications such as newspaper and also monthly serials such as magazines.</p>\r\n<h3>Library Membership</h3>\r\n<p>To be able to loan our library collections, you must first become library member. There is terms and conditions that you must obey.</p>','libinfo','2009-09-13 19:48:16','2009-09-13 19:48:16'),(2,'Help On Usage','<h3>Searching</h3>\r\n<p>There is 2 method available on searching library catalog. The first one is <strong>SIMPLE SEARCH</strong>, which is the simplest method on searching catalog, you just enter any keyword, either it contained in document titles, authors name or subjects. You can supply more than one keywords in Simple Search method and it will expanding your search results.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>ADVANCED SEARCH</strong>, lets you define keywords in more specific fields. If you want your keywords only contained in title field, then type your keyword in Title field and the system will scope it search only on <strong>Title</strong> field, not in other fields. Location field lets you narrowing search results by specific location, so only collection that exists in selected location get fetched by system.</p>','help','2009-09-13 19:48:16','2009-09-13 19:48:16'),(3,'Welcome To Admin Page','<table style=\"width: 100%;\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n<tbody>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon biblioIcon\" href=\"?mod=bibliography\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Bibliography</div>\r\nThe Bibliography module lets you manage your library bibliographical data. It also include collection items management     to manage a copies of your library collection so it can be used in library circulation.</td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon circulationIcon\" href=\"?mod=circulation\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Circulation</div>\r\nThe Circulation module is used for doing library circulation transaction such as collection loans and return. In this module you can also create loan rules that will be used in loan transaction proccess.</td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon memberIcon\" href=\"?mod=membership\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Membership</div>\r\nThe Membership module lets you manage library members such adding, updating and also removing. You can also manage membership type in this module.<br /><br /></td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon stockTakeIcon\" href=\"?mod=stock_take\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Stock Take</div>\r\nThe Stock Take module is the easy way to do Stock Opname for your library collections. Follow several steps that ease your pain in Stock Opname proccess. <br /><br /></td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon masterFileIcon\" href=\"?mod=master_file\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Master File</div>\r\nThe Master File modules lets you manage referential data that will be used by another modules. It include Authority File management such     as Authority, Subject/Topic List, GMD and other data.</td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon systemIcon\" href=\"?mod=system\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">System</div>\r\nThe System module is used to configure application globally.</td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon reportIcon\" href=\"?mod=reporting\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Reporting</div>\r\n<p>Reporting lets you view various type of reports regardings membership data, circulation data and bibliographic data. All compiled on-the-fly from         current library database.</p>\r\n<br /></td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon serialIcon\" href=\"?mod=serial_control\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Serial Control</div>\r\nSerial Control module help you manage library\'s serial publication subscription. You can track issues for each subscription.</td>\r\n</tr>\r\n</tbody>\r\n</table>','adminhome','2009-09-13 19:48:16','2011-01-19 12:58:39'),(4,'Homepage Info','<p>Welcome To <strong>Triz\'s</strong> Online Public Access Catalog (OPAC). Use OPAC to search collection in our library.</p>','headerinfo','2009-09-13 19:48:16','2011-01-10 17:38:48');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_title` text COLLATE utf8_unicode_ci NOT NULL,
  `file_name` text COLLATE utf8_unicode_ci NOT NULL,
  `file_url` text COLLATE utf8_unicode_ci,
  `file_dir` text COLLATE utf8_unicode_ci,
  `mime_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_desc` text COLLATE utf8_unicode_ci,
  `uploader_id` int(11) NOT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `file_name` (`file_name`),
  FULLTEXT KEY `file_dir` (`file_dir`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fines`
--

DROP TABLE IF EXISTS `fines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fines` (
  `fines_id` int(11) NOT NULL AUTO_INCREMENT,
  `fines_date` date NOT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `debet` int(11) DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fines_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fines`
--

LOCK TABLES `fines` WRITE;
/*!40000 ALTER TABLE `fines` DISABLE KEYS */;
INSERT INTO `fines` VALUES (1,'2011-01-19','1',1,1,'dsfdsf'),(2,'2011-01-20','1',1,1,'iiiiiiiiiiiiiiiiiiiiiiiii'),(3,'2011-01-21','1',30,30,'Overdue fines for item b00001');
/*!40000 ALTER TABLE `fines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_access`
--

DROP TABLE IF EXISTS `group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_access` (
  `group_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `r` int(1) NOT NULL DEFAULT '0',
  `w` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`,`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_access`
--

LOCK TABLES `group_access` WRITE;
/*!40000 ALTER TABLE `group_access` DISABLE KEYS */;
INSERT INTO `group_access` VALUES (1,1,1,1),(1,2,1,1),(1,3,1,1),(1,4,1,1),(1,5,1,1),(1,6,1,1),(1,7,1,1),(1,8,1,1),(2,8,1,0),(2,7,1,0),(2,6,1,0),(2,5,1,0),(2,4,1,0),(2,3,1,0),(2,2,1,0),(2,1,1,0);
/*!40000 ALTER TABLE `group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_dayname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `holiday_date` date DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`holiday_id`),
  UNIQUE KEY `holiday_dayname` (`holiday_dayname`,`holiday_date`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday`
--

LOCK TABLES `holiday` WRITE;
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
INSERT INTO `holiday` VALUES (1,'Mon','2009-06-01','Tes Libur'),(2,'Tue','2009-06-02','Tes Libur'),(3,'Wed','2009-06-03','Tes Libur'),(4,'Thu','2009-06-04','Tes Libur'),(5,'Fri','2009-06-05','Tes Libur'),(6,'Sat','2009-06-06','Tes Libur');
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `biblio_id` int(11) DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coll_type_id` int(3) DEFAULT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inventory_code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `supplier_id` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_no` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `item_status_id` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` int(1) NOT NULL DEFAULT '0',
  `invoice` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `price_currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `item_references_idx` (`coll_type_id`,`location_id`,`item_status_id`),
  KEY `biblio_id_idx` (`biblio_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,8,NULL,1,'B00001','INV/B00001','0000-00-00','0','','SL','0000-00-00','0','',1,'',500000,'Rupiah','0000-00-00','2008-12-26 22:11:10','2008-12-26 22:14:13'),(2,6,NULL,1,'B00002','INV/B00002','0000-00-00','0','','SL','0000-00-00','0','',1,'',700000,'Rupiah','0000-00-00','2008-12-26 22:11:45','2008-12-26 22:13:45'),(3,15,NULL,1,'B00003','INV/B00003','0000-00-00','0','','SL','0000-00-00','0','',1,'',300000,'Rupiah','0000-00-00','2008-12-26 22:15:09','2008-12-26 22:15:09'),(4,14,NULL,1,'B00004','INV/B00004','0000-00-00','0','','SL','0000-00-00','0','',1,'',250000,'Rupiah','0000-00-00','2008-12-26 22:15:49','2008-12-26 22:15:49'),(5,13,NULL,1,'B00005','INV/B00005','0000-00-00','0','','SL','0000-00-00','0','',2,'',0,NULL,'0000-00-00','2008-12-26 22:17:04','2008-12-26 22:17:04'),(6,12,NULL,1,'B00006','INV/B00006','0000-00-00','0','','SL','0000-00-00','0','',1,'',350000,'Rupiah','0000-00-00','2008-12-26 22:17:52','2008-12-26 22:17:52'),(7,4,NULL,1,'B00007','INV/B00007','0000-00-00','0','','SL','0000-00-00','0','',1,'',450000,'Rupiah','0000-00-00','2008-12-26 22:18:29','2008-12-26 22:18:29'),(8,4,NULL,1,'B00008','INV/B00008','0000-00-00','0','','SL','0000-00-00','0','',2,'',0,NULL,'0000-00-00','2008-12-26 22:18:51','2008-12-26 22:18:51'),(14,477,'201021',2,'D101','I101','2011-01-21','0','O101','SL','2011-01-21','0','',1,'123456',300,'Ruppee','2011-01-21','2011-01-21 13:48:17','2011-01-21 13:48:17'),(13,20,NULL,NULL,'birthplace',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'0000-00-00 00:00:00',NULL),(15,477,'201021',2,'D102','I101','2011-01-21','0','O101','SL','2011-01-21','0','',1,'123456',300,'Ruppee','2011-01-21','2011-01-21 13:49:06','2011-01-21 13:49:06'),(16,477,'201021',2,'D103','I101','2011-01-21','0','O101','SL','2011-01-21','0','',1,'',300,'Ruppee','2011-01-21','2011-01-21 13:49:45','2011-01-21 13:49:45');
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kardex`
--

DROP TABLE IF EXISTS `kardex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kardex` (
  `kardex_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_expected` date NOT NULL,
  `date_received` date DEFAULT NULL,
  `seq_number` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `serial_id` int(11) DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`kardex_id`),
  KEY `fk_serial` (`serial_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kardex`
--

LOCK TABLES `kardex` WRITE;
/*!40000 ALTER TABLE `kardex` DISABLE KEYS */;
/*!40000 ALTER TABLE `kardex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `loan_date` date NOT NULL,
  `due_date` date NOT NULL,
  `renewed` int(11) NOT NULL DEFAULT '0',
  `loan_rules_id` int(11) NOT NULL DEFAULT '0',
  `actual` date DEFAULT NULL,
  `is_lent` int(11) NOT NULL DEFAULT '0',
  `is_return` int(11) NOT NULL DEFAULT '0',
  `return_date` date DEFAULT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `item_code` (`item_code`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (1,'101','harshit','2011-01-10','2011-01-17',0,0,NULL,1,1,'2011-01-10'),(2,'101','1','2011-01-10','2011-01-25',0,1,NULL,1,1,'2011-01-11'),(3,'101','1','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-11'),(4,'102','harshit','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-11'),(5,'101','3','2011-01-11','2011-01-26',1,1,NULL,1,1,'2011-01-11'),(6,'101','harshit','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-11'),(7,'101','harshit','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-12'),(8,'102','1','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-12'),(9,'101','1','2011-01-12','2011-01-27',0,1,NULL,1,1,'2011-01-12'),(10,'b00009','1','2011-01-11','2011-01-12',0,1,NULL,1,1,'2011-01-13'),(11,'b00001','1','2011-01-13','2011-01-28',0,1,NULL,1,1,'2011-01-13'),(12,'b00002','2','2011-01-13','2011-01-28',0,1,NULL,1,1,'2011-01-13'),(16,'b00004','2','2011-01-17','2011-02-01',0,1,NULL,1,0,NULL),(13,'b00001','harshit','2011-01-13','2011-01-28',0,1,NULL,1,1,'2011-01-13'),(14,'b00002','1','2011-01-13','2011-02-03',1,1,NULL,1,1,'2011-01-20'),(15,'b00001','1','2011-01-13','2011-01-28',0,1,NULL,1,1,'2011-01-20'),(17,'b00005','2','2011-01-17','2011-02-01',0,1,NULL,1,0,NULL),(18,'b00001','1','2011-01-11','2011-01-15',0,1,NULL,1,1,'2011-01-21'),(19,'D101','1','2011-01-21','2011-02-05',0,1,NULL,1,0,NULL),(20,'D102','1','2011-01-21','2011-02-05',0,1,NULL,1,0,NULL),(21,'D103','1','2011-01-21','2011-02-05',1,1,NULL,1,1,'2011-01-21');
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `member_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(1) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `member_type_id` int(6) DEFAULT NULL,
  `member_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inst_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_new` int(1) DEFAULT NULL,
  `member_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pin` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_fax` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_since_date` date DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  `expire_date` date NOT NULL,
  `member_notes` text COLLATE utf8_unicode_ci,
  `is_pending` smallint(1) NOT NULL DEFAULT '0',
  `mpasswd` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `member_name` (`member_name`),
  KEY `member_type_id` (`member_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('M00001','Hendro Wicaksono',1,'1974-06-05',1,'','hendrowicaksono@yahoo.com','','Perpustakaan Depdiknas',NULL,NULL,'','','','2009-04-15','2009-04-15','2010-04-15','',0,NULL,NULL,NULL,'2009-04-15','2009-06-11'),('M00002','Arie Nugraha',1,'1982-12-06',1,'','dicarve@yahoo.com','','Perpustakaan Depdiknas',NULL,NULL,'','','','2009-04-15','2009-04-15','2010-04-15','',0,NULL,NULL,NULL,'2009-04-15','2009-06-11'),('1','iresh',1,'1992-01-10',1,'','ireshparmar@gmail.com','','',NULL,NULL,'','','','2011-01-10','2011-01-10','2012-01-10','',0,'e8803a533120facc671d141febf14c32','2011-01-21 14:03:08','192.168.1.10','2011-01-10','2011-01-10'),('2','harshit bhatt',1,'2011-01-26',1,'surat','hbhatt26@gmail.com','395003','Tatva Foundation',NULL,NULL,'','','','2011-01-10','2011-01-10','2012-01-10','',0,'e99a18c428cb38d5f260853678922e03','2011-01-12 16:47:09','192.168.1.20','2011-01-10','2011-01-10'),('3','hiren',1,'1994-01-11',1,'','','','',NULL,NULL,'','','','2011-01-01','2011-01-11','2012-01-11','',0,'ec560dff9aaf87483e469b6abd8cd50c',NULL,NULL,'2011-01-11','2011-01-11'),('5','hiren',0,'0000-00-00',1,'','ireshparmar@gmail.com','','',NULL,NULL,'','','','2011-01-08','2011-01-17','2012-01-17','',0,'ec560dff9aaf87483e469b6abd8cd50c','2011-01-17 16:20:19','127.0.0.1','2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_author`
--

DROP TABLE IF EXISTS `mst_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `authority_type` enum('p','o','c') COLLATE utf8_unicode_ci DEFAULT 'p',
  `auth_list` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  UNIQUE KEY `author_name` (`author_name`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_author`
--

LOCK TABLES `mst_author` WRITE;
/*!40000 ALTER TABLE `mst_author` DISABLE KEYS */;
INSERT INTO `mst_author` VALUES (1,'Valade, Janet','p',NULL,'2007-11-29','2007-11-29'),(2,'Siever, Ellen','p',NULL,'2007-11-29','2007-11-29'),(3,'Love, Robert','p',NULL,'2007-11-29','2007-11-29'),(4,'Robbins, Arnold','p',NULL,'2007-11-29','2007-11-29'),(5,'Figgins, Stephen','p',NULL,'2007-11-29','2007-11-29'),(6,'Weber, Aaron','p',NULL,'2007-11-29','2007-11-29'),(7,'Kofler, Michael','p',NULL,'2007-11-29','2007-11-29'),(8,'Kramer, David','p',NULL,'2007-11-29','2007-11-29'),(9,'Raymond, Eric','p',NULL,'2007-11-29','2007-11-29'),(10,'Fogel, Karl','p',NULL,'2007-11-29','2007-11-29'),(11,'Douglas, Korry','p',NULL,'2007-11-29','2007-11-29'),(12,'Douglas, Susan','p',NULL,'2007-11-29','2007-11-29'),(13,'Shklar, Leon','p',NULL,'2007-11-29','2007-11-29'),(14,'Rosen, Richard','p',NULL,'2007-11-29','2007-11-29'),(15,'Woychowsky, Edmond','p',NULL,'2007-11-29','2007-11-29'),(16,'Taylor, Arlene G.','p',NULL,'2007-11-29','2007-11-29'),(17,'Stueart, Robert D.','p',NULL,'2007-11-29','2007-11-29'),(18,'Moran, Barbara B.','p',NULL,'2007-11-29','2007-11-29'),(19,'Morville, Peter','p',NULL,'2007-11-29','2007-11-29'),(20,'Rosenfeld, Louis','p',NULL,'2007-11-29','2007-11-29'),(21,'Robinson, Mark','p',NULL,'2007-11-29','2007-11-29'),(22,'Bracking, Sarah','p',NULL,'2007-11-29','2007-11-29'),(23,'Huffington, Arianna Stassinopoulos','p',NULL,'2007-11-29','2007-11-29'),(24,'Hancock, Graham','p',NULL,'2007-11-29','2007-11-29'),(25,'iresh','p',NULL,'2011-01-12','2011-01-12'),(26,'birthdate','p',NULL,'2011-01-17','2011-01-17'),(27,'23/11/1989','p',NULL,'2011-01-17','2011-01-17'),(28,'24/08/1989','p',NULL,'2011-01-17','2011-01-17'),(29,'8/7/1987','p',NULL,'2011-01-17','2011-01-17'),(30,'13/04/1986','p',NULL,'2011-01-17','2011-01-17'),(31,'27/11/1984','p',NULL,'2011-01-17','2011-01-17'),(32,'17/05/1989','p',NULL,'2011-01-17','2011-01-17'),(33,'9/7/1989','p',NULL,'2011-01-17','2011-01-17'),(34,'11/8/1987','p',NULL,'2011-01-17','2011-01-17'),(35,'11/9/1988','p',NULL,'2011-01-17','2011-01-17'),(36,'19/11/1985','p',NULL,'2011-01-17','2011-01-17'),(37,'24/10/1984','p',NULL,'2011-01-17','2011-01-17'),(38,'7/10/1987','p',NULL,'2011-01-17','2011-01-17'),(39,'5/6/1989','p',NULL,'2011-01-17','2011-01-17'),(40,'22/12/1989','p',NULL,'2011-01-17','2011-01-17'),(41,'28/08/1983','p',NULL,'2011-01-17','2011-01-17'),(42,'18/06/1990','p',NULL,'2011-01-17','2011-01-17'),(43,'22/04/1989','p',NULL,'2011-01-17','2011-01-17'),(44,'5/6/1990','p',NULL,'2011-01-17','2011-01-17'),(45,'13/06/1988','p',NULL,'2011-01-17','2011-01-17'),(46,'15/08/1989','p',NULL,'2011-01-17','2011-01-17'),(47,'13/11/1989','p',NULL,'2011-01-17','2011-01-17'),(48,'8/2/1990','p',NULL,'2011-01-17','2011-01-17'),(49,'6/1/1986','p',NULL,'2011-01-17','2011-01-17'),(50,'2/10/1989','p',NULL,'2011-01-17','2011-01-17'),(51,'6/8/1990','p',NULL,'2011-01-17','2011-01-17'),(52,'25/06/1989','p',NULL,'2011-01-17','2011-01-17'),(53,'24/03/1989','p',NULL,'2011-01-17','2011-01-17'),(54,'15/06/1989','p',NULL,'2011-01-17','2011-01-17'),(55,'22/05/1987','p',NULL,'2011-01-17','2011-01-17'),(56,'3/12/1989','p',NULL,'2011-01-17','2011-01-17'),(57,'4/6/1990','p',NULL,'2011-01-17','2011-01-17'),(58,'9/12/1989','p',NULL,'2011-01-17','2011-01-17'),(59,'20/11/1989','p',NULL,'2011-01-17','2011-01-17'),(60,'6/12/1989','p',NULL,'2011-01-17','2011-01-17'),(61,'28/05/1989','p',NULL,'2011-01-17','2011-01-17'),(62,'24/03/1990','p',NULL,'2011-01-17','2011-01-17'),(63,'15/10/1988','p',NULL,'2011-01-17','2011-01-17'),(64,'19/08/1990','p',NULL,'2011-01-17','2011-01-17'),(65,'1/9/1985','p',NULL,'2011-01-17','2011-01-17'),(66,'14/11/1989','p',NULL,'2011-01-17','2011-01-17'),(67,'9/3/1990','p',NULL,'2011-01-17','2011-01-17'),(68,'19/11/1989','p',NULL,'2011-01-17','2011-01-17'),(69,'18/05/1989','p',NULL,'2011-01-17','2011-01-17'),(70,'16/08/1988','p',NULL,'2011-01-17','2011-01-17'),(71,'4/8/1982','p',NULL,'2011-01-17','2011-01-17'),(72,'19/04/1989','p',NULL,'2011-01-17','2011-01-17'),(73,'31/08/1984','p',NULL,'2011-01-17','2011-01-17'),(74,'6/10/1989','p',NULL,'2011-01-17','2011-01-17'),(75,'18/08/1988','p',NULL,'2011-01-17','2011-01-17'),(76,'23/02/1989','p',NULL,'2011-01-17','2011-01-17'),(77,'26/08/1989','p',NULL,'2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_coll_type`
--

DROP TABLE IF EXISTS `mst_coll_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_coll_type` (
  `coll_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `coll_type_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`coll_type_id`),
  UNIQUE KEY `coll_type_name` (`coll_type_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_coll_type`
--

LOCK TABLES `mst_coll_type` WRITE;
/*!40000 ALTER TABLE `mst_coll_type` DISABLE KEYS */;
INSERT INTO `mst_coll_type` VALUES (1,'Reference','2007-11-29','2007-11-29'),(2,'Textbook','2007-11-29','2007-11-29'),(3,'Fiction','2007-11-29','2007-11-29');
/*!40000 ALTER TABLE `mst_coll_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_frequency`
--

DROP TABLE IF EXISTS `mst_frequency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_frequency` (
  `frequency_id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `language_prefix` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_increment` smallint(6) DEFAULT NULL,
  `time_unit` enum('day','week','month','year') COLLATE utf8_unicode_ci DEFAULT 'day',
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`frequency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_frequency`
--

LOCK TABLES `mst_frequency` WRITE;
/*!40000 ALTER TABLE `mst_frequency` DISABLE KEYS */;
INSERT INTO `mst_frequency` VALUES (1,'Weekly','en',1,'week','2009-05-23','2009-05-23'),(2,'Bi-weekly','en',2,'week','2009-05-23','2009-05-23'),(3,'Fourth-Nightly','en',14,'day','2009-05-23','2009-05-23'),(4,'Monthly','en',1,'month','2009-05-23','2009-05-23'),(5,'Bi-Monthly','en',2,'month','2009-05-23','2009-05-23'),(6,'Quarterly','en',3,'month','2009-05-23','2009-05-23'),(7,'3 Times a Year','en',4,'month','2009-05-23','2009-05-23'),(8,'Annualy','en',1,'year','2009-05-23','2009-05-23');
/*!40000 ALTER TABLE `mst_frequency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_gmd`
--

DROP TABLE IF EXISTS `mst_gmd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_gmd` (
  `gmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `gmd_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmd_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `icon_image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`gmd_id`),
  UNIQUE KEY `gmd_name` (`gmd_name`),
  UNIQUE KEY `gmd_code` (`gmd_code`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_gmd`
--

LOCK TABLES `mst_gmd` WRITE;
/*!40000 ALTER TABLE `mst_gmd` DISABLE KEYS */;
INSERT INTO `mst_gmd` VALUES (1,'TE','Text',NULL,'2011-01-10','2011-01-10'),(2,'AR','Art Original',NULL,'2011-01-10','2011-01-10'),(3,'CH','Chart',NULL,'2011-01-10','2011-01-10'),(4,'CO','Computer Software',NULL,'2011-01-10','2011-01-10'),(5,'DI','Diorama',NULL,'2011-01-10','2011-01-10'),(6,'FI','Filmstrip',NULL,'2011-01-10','2011-01-10'),(7,'FL','Flash Card',NULL,'2011-01-10','2011-01-10'),(8,'GA','Game',NULL,'2011-01-10','2011-01-10'),(9,'GL','Globe',NULL,'2011-01-10','2011-01-10'),(10,'KI','Kit',NULL,'2011-01-10','2011-01-10'),(11,'MA','Map',NULL,'2011-01-10','2011-01-10'),(12,'MI','Microform',NULL,'2011-01-10','2011-01-10'),(13,'MN','Manuscript',NULL,'2011-01-10','2011-01-10'),(14,'MO','Model',NULL,'2011-01-10','2011-01-10'),(15,'MP','Motion Picture',NULL,'2011-01-10','2011-01-10'),(16,'MS','Microscope Slide',NULL,'2011-01-10','2011-01-10'),(17,'MU','Music',NULL,'2011-01-10','2011-01-10'),(18,'PI','Picture',NULL,'2011-01-10','2011-01-10'),(19,'RE','Realia',NULL,'2011-01-10','2011-01-10'),(20,'SL','Slide',NULL,'2011-01-10','2011-01-10'),(21,'SO','Sound Recording',NULL,'2011-01-10','2011-01-10'),(22,'TD','Technical Drawing',NULL,'2011-01-10','2011-01-10'),(23,'TR','Transparency',NULL,'2011-01-10','2011-01-10'),(24,'VI','Video Recording',NULL,'2011-01-10','2011-01-10'),(25,'EQ','Equipment',NULL,'2011-01-10','2011-01-10'),(26,'CF','Computer File',NULL,'2011-01-10','2011-01-10'),(27,'CA','Cartographic Material',NULL,'2011-01-10','2011-01-10'),(28,'CD','CD-ROM',NULL,'2011-01-10','2011-01-10'),(29,'MV','Multimedia',NULL,'2011-01-10','2011-01-10'),(30,'ER','Electronic Resource',NULL,'2011-01-10','2011-01-10'),(31,'DVD','Digital Versatile Disc',NULL,'2011-01-10','2011-01-10'),(32,NULL,'last_name',NULL,'2011-01-17','2011-01-17'),(33,NULL,'SHAH',NULL,'2011-01-17','2011-01-17'),(34,NULL,'PANDYA',NULL,'2011-01-17','2011-01-17'),(35,NULL,'GOSWAMI',NULL,'2011-01-17','2011-01-17'),(36,NULL,'DAVE',NULL,'2011-01-17','2011-01-17'),(37,NULL,'BHEDA',NULL,'2011-01-17','2011-01-17'),(38,NULL,'JOSHI',NULL,'2011-01-17','2011-01-17'),(39,NULL,'BHATT',NULL,'2011-01-17','2011-01-17'),(40,NULL,'PATEL',NULL,'2011-01-17','2011-01-17'),(41,NULL,'DHANDHA',NULL,'2011-01-17','2011-01-17'),(42,NULL,'JETHVA',NULL,'2011-01-17','2011-01-17'),(43,NULL,'RATHOD',NULL,'2011-01-17','2011-01-17'),(44,NULL,'KARNAVAT',NULL,'2011-01-17','2011-01-17'),(45,NULL,'GOHEL',NULL,'2011-01-17','2011-01-17'),(46,NULL,'KHAMBHOLJA',NULL,'2011-01-17','2011-01-17'),(47,NULL,'CHHATTRALA',NULL,'2011-01-17','2011-01-17'),(48,NULL,'RABARA',NULL,'2011-01-17','2011-01-17'),(49,NULL,'SHARMA',NULL,'2011-01-17','2011-01-17'),(50,NULL,'TIRMIZI',NULL,'2011-01-17','2011-01-17'),(51,NULL,'NATHANI',NULL,'2011-01-17','2011-01-17'),(52,NULL,'JHA',NULL,'2011-01-17','2011-01-17'),(53,NULL,'DESAI',NULL,'2011-01-17','2011-01-17'),(54,NULL,'ADESHARA',NULL,'2011-01-17','2011-01-17'),(55,NULL,'VASANI',NULL,'2011-01-17','2011-01-17'),(56,NULL,'DAS',NULL,'2011-01-17','2011-01-17'),(57,NULL,'SHAIKH',NULL,'2011-01-17','2011-01-17'),(58,NULL,'KOTADIYA',NULL,'2011-01-17','2011-01-17'),(59,NULL,'SANKHAVARA',NULL,'2011-01-17','2011-01-17'),(60,NULL,'KAKADIYA',NULL,'2011-01-17','2011-01-17'),(61,NULL,'SONI',NULL,'2011-01-17','2011-01-17'),(62,NULL,'NALIYADHARA',NULL,'2011-01-17','2011-01-17'),(63,NULL,'VAGHANI',NULL,'2011-01-17','2011-01-17'),(64,NULL,'PANCHAL',NULL,'2011-01-17','2011-01-17'),(65,NULL,'THAKKAR',NULL,'2011-01-17','2011-01-17'),(66,NULL,'',NULL,'2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_gmd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_item_status`
--

DROP TABLE IF EXISTS `mst_item_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_item_status` (
  `item_status_id` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `item_status_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `rules` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_loan` smallint(1) NOT NULL DEFAULT '0',
  `skip_stock_take` smallint(1) NOT NULL DEFAULT '0',
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`item_status_id`),
  UNIQUE KEY `item_status_name` (`item_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_item_status`
--

LOCK TABLES `mst_item_status` WRITE;
/*!40000 ALTER TABLE `mst_item_status` DISABLE KEYS */;
INSERT INTO `mst_item_status` VALUES ('R','Repair','a:1:{i:0;s:1:\"1\";}',0,0,'2011-01-10','2011-01-10'),('NL','No Loan','a:1:{i:0;s:1:\"1\";}',0,0,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_item_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_label`
--

DROP TABLE IF EXISTS `mst_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_label` (
  `label_id` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `label_desc` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label_image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`label_id`),
  UNIQUE KEY `label_name` (`label_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_label`
--

LOCK TABLES `mst_label` WRITE;
/*!40000 ALTER TABLE `mst_label` DISABLE KEYS */;
INSERT INTO `mst_label` VALUES (1,'label-new','New Title','label-new.png','2011-01-10','2011-01-10'),(2,'label-favorite','Favorite Title','label-favorite.png','2011-01-10','2011-01-17'),(3,'label-multimedia','Multimedia','label-multimedia.png','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_language`
--

DROP TABLE IF EXISTS `mst_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_language` (
  `language_id` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `language_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `language_name` (`language_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_language`
--

LOCK TABLES `mst_language` WRITE;
/*!40000 ALTER TABLE `mst_language` DISABLE KEYS */;
INSERT INTO `mst_language` VALUES ('','Indonesia','2011-01-12','2011-01-12'),('en','English','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_loan_rules`
--

DROP TABLE IF EXISTS `mst_loan_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_loan_rules` (
  `loan_rules_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_id` int(11) NOT NULL DEFAULT '0',
  `coll_type_id` int(11) DEFAULT '0',
  `gmd_id` int(11) DEFAULT '0',
  `loan_limit` int(3) DEFAULT '0',
  `loan_periode` int(3) DEFAULT '0',
  `reborrow_limit` int(3) DEFAULT '0',
  `fine_each_day` int(3) DEFAULT '0',
  `grace_periode` int(2) DEFAULT '0',
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`loan_rules_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_loan_rules`
--

LOCK TABLES `mst_loan_rules` WRITE;
/*!40000 ALTER TABLE `mst_loan_rules` DISABLE KEYS */;
INSERT INTO `mst_loan_rules` VALUES (1,1,2,1,15,15,15,5,5,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_loan_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_location`
--

DROP TABLE IF EXISTS `mst_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_location` (
  `location_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `location_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_name` (`location_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_location`
--

LOCK TABLES `mst_location` WRITE;
/*!40000 ALTER TABLE `mst_location` DISABLE KEYS */;
INSERT INTO `mst_location` VALUES ('SL','My Library','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_member_type`
--

DROP TABLE IF EXISTS `mst_member_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_member_type` (
  `member_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `loan_limit` int(11) NOT NULL,
  `loan_periode` int(11) NOT NULL,
  `enable_reserve` int(1) NOT NULL DEFAULT '0',
  `reserve_limit` int(11) NOT NULL DEFAULT '0',
  `member_periode` int(11) NOT NULL,
  `reborrow_limit` int(11) NOT NULL,
  `fine_each_day` int(11) NOT NULL,
  `grace_periode` int(2) DEFAULT '0',
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`member_type_id`),
  UNIQUE KEY `member_type_name` (`member_type_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_member_type`
--

LOCK TABLES `mst_member_type` WRITE;
/*!40000 ALTER TABLE `mst_member_type` DISABLE KEYS */;
INSERT INTO `mst_member_type` VALUES (1,'Standard',2,7,1,2,365,1,0,0,'2011-01-10','2011-01-11');
/*!40000 ALTER TABLE `mst_member_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_module`
--

DROP TABLE IF EXISTS `mst_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_module` (
  `module_id` int(3) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `module_path` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `module_name` (`module_name`,`module_path`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_module`
--

LOCK TABLES `mst_module` WRITE;
/*!40000 ALTER TABLE `mst_module` DISABLE KEYS */;
INSERT INTO `mst_module` VALUES (1,'bibliography','bibliography','Manage your bibliographic/catalog and items/copies database'),(2,'circulation','circulation','Module for doing library items circulation such as loan and return'),(3,'membership','membership','Manage your library membership and membership type'),(4,'master_file','master_file','Manage your referential data that will be used by other modules'),(5,'stock_take','stock_take','Ease your pain in doing library stock opname process'),(6,'system','system','Configure system behaviour, user and backups'),(7,'reporting','reporting','Real time and dynamic report about library collections and circulation'),(8,'serial control','serial_control','Serial publication management');
/*!40000 ALTER TABLE `mst_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_place`
--

DROP TABLE IF EXISTS `mst_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_place` (
  `place_id` int(11) NOT NULL AUTO_INCREMENT,
  `place_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`place_id`),
  UNIQUE KEY `place_name` (`place_name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_place`
--

LOCK TABLES `mst_place` WRITE;
/*!40000 ALTER TABLE `mst_place` DISABLE KEYS */;
INSERT INTO `mst_place` VALUES (1,'Hoboken, NJ','2007-11-29','2007-11-29'),(2,'Sebastopol, CA','2007-11-29','2007-11-29'),(3,'Indianapolis','2007-11-29','2007-11-29'),(4,'Upper Saddle River, NJ','2007-11-29','2007-11-29'),(5,'Westport, Conn.','2007-11-29','2007-11-29'),(6,'Cambridge, Mass','2007-11-29','2007-11-29'),(7,'London','2007-11-29','2007-11-29'),(8,'New York','2007-11-29','2007-11-29'),(9,'','2011-01-12','2011-01-12'),(10,'religion','2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_publisher`
--

DROP TABLE IF EXISTS `mst_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_publisher` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`publisher_id`),
  UNIQUE KEY `publisher_name` (`publisher_name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_publisher`
--

LOCK TABLES `mst_publisher` WRITE;
/*!40000 ALTER TABLE `mst_publisher` DISABLE KEYS */;
INSERT INTO `mst_publisher` VALUES (1,'Wiley','2007-11-29','2007-11-29'),(2,'OReilly','2007-11-29','2007-11-29'),(3,'Apress','2007-11-29','2007-11-29'),(4,'Sams','2007-11-29','2007-11-29'),(5,'John Wiley','2007-11-29','2007-11-29'),(6,'Prentice Hall','2007-11-29','2007-11-29'),(7,'Libraries Unlimited','2007-11-29','2007-11-29'),(8,'Taylor & Francis Inc.','2007-11-29','2007-11-29'),(9,'Palgrave Macmillan','2007-11-29','2007-11-29'),(10,'Crown publishers','2007-11-29','2007-11-29'),(11,'Atlantic Monthly Press','2007-11-29','2007-11-29'),(13,'name_suffix','2011-01-17','2011-01-17'),(14,'Miss','2011-01-17','2011-01-17'),(15,'Mr','2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_supplier`
--

DROP TABLE IF EXISTS `mst_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` char(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` char(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `e_mail` char(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `supplier_name` (`supplier_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_supplier`
--

LOCK TABLES `mst_supplier` WRITE;
/*!40000 ALTER TABLE `mst_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `mst_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_topic`
--

DROP TABLE IF EXISTS `mst_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `topic_type` enum('t','g','n','tm','gr','oc') COLLATE utf8_unicode_ci NOT NULL,
  `auth_list` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic` (`topic`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_topic`
--

LOCK TABLES `mst_topic` WRITE;
/*!40000 ALTER TABLE `mst_topic` DISABLE KEYS */;
INSERT INTO `mst_topic` VALUES (1,'Programming','t',NULL,'2007-11-29','2007-11-29'),(2,'Website','t',NULL,'2007-11-29','2007-11-29'),(3,'Operating System','t',NULL,'2007-11-29','2007-11-29'),(4,'Linux','t',NULL,'2007-11-29','2007-11-29'),(5,'Computer','t',NULL,'2007-11-29','2007-11-29'),(6,'Database','t',NULL,'2007-11-29','2007-11-29'),(7,'RDBMS','t',NULL,'2007-11-29','2007-11-29'),(8,'Open Source','t',NULL,'2007-11-29','2007-11-29'),(9,'Project','t',NULL,'2007-11-29','2007-11-29'),(10,'Design','t',NULL,'2007-11-29','2007-11-29'),(11,'Information','t',NULL,'2007-11-29','2007-11-29'),(12,'Organization','t',NULL,'2007-11-29','2007-11-29'),(13,'Metadata','t',NULL,'2007-11-29','2007-11-29'),(14,'Library','t',NULL,'2007-11-29','2007-11-29'),(15,'Corruption','t',NULL,'2007-11-29','2007-11-29'),(16,'Development','t',NULL,'2007-11-29','2007-11-29'),(17,'Poverty','t',NULL,'2007-11-29','2007-11-29'),(18,'birthtime','t',NULL,'2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserve`
--

DROP TABLE IF EXISTS `reserve`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserve` (
  `reserve_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `biblio_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `reserve_date` datetime NOT NULL,
  PRIMARY KEY (`reserve_id`),
  KEY `references_idx` (`member_id`,`biblio_id`),
  KEY `item_code_idx` (`item_code`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserve`
--

LOCK TABLES `reserve` WRITE;
/*!40000 ALTER TABLE `reserve` DISABLE KEYS */;
INSERT INTO `reserve` VALUES (71,'1',14,'B00004','2011-01-16 15:48:59'),(79,'1',477,'D101','2011-01-21 14:00:12');
/*!40000 ALTER TABLE `reserve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serial`
--

DROP TABLE IF EXISTS `serial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serial` (
  `serial_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date DEFAULT NULL,
  `period` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `biblio_id` int(11) DEFAULT NULL,
  `gmd_id` int(11) DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`serial_id`),
  KEY `fk_serial_biblio` (`biblio_id`),
  KEY `fk_serial_gmd` (`gmd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serial`
--

LOCK TABLES `serial` WRITE;
/*!40000 ALTER TABLE `serial` DISABLE KEYS */;
/*!40000 ALTER TABLE `serial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `setting_id` int(3) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `setting_name` (`setting_name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'library_name','s:4:\"Triz\";'),(2,'library_subname','s:37:\"Open Source Library Management System\";'),(3,'template','a:2:{s:5:\"theme\";s:4:\"igos\";s:3:\"css\";s:23:\"template/igos/style.css\";}'),(4,'admin_template','a:2:{s:5:\"theme\";s:4:\"igos\";s:3:\"css\";s:29:\"admin_template/igos/style.css\";}'),(5,'default_lang','s:5:\"en_US\";'),(6,'opac_result_num','s:2:\"10\";'),(7,'enable_promote_titles','a:1:{i:0;s:1:\"1\";}'),(8,'quick_return','b:1;'),(9,'allow_loan_date_change','b:1;'),(10,'loan_limit_override','b:1;'),(11,'enable_xml_detail','b:0;'),(12,'enable_xml_result','b:0;'),(13,'allow_file_download','b:1;'),(14,'session_timeout','s:4:\"7200\";'),(15,'circulation_receipt','b:1;'),(16,'barcode_encoding','s:4:\"128B\";');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take`
--

DROP TABLE IF EXISTS `stock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take` (
  `stock_take_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_take_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `init_user` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `total_item_stock_taked` int(11) DEFAULT NULL,
  `total_item_lost` int(11) DEFAULT NULL,
  `total_item_exists` int(11) DEFAULT '0',
  `total_item_loan` int(11) DEFAULT NULL,
  `stock_take_users` mediumtext COLLATE utf8_unicode_ci,
  `is_active` int(1) NOT NULL DEFAULT '0',
  `report_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`stock_take_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take`
--

LOCK TABLES `stock_take` WRITE;
/*!40000 ALTER TABLE `stock_take` DISABLE KEYS */;
INSERT INTO `stock_take` VALUES (1,'h','2011-01-10 15:51:53','2011-01-10 14:21:49','Administrator',1,1,0,0,'Administrator\n',0,'h_report.html'),(2,'h','2011-01-11 13:09:18',NULL,'Administrator',4,2,0,1,'Administrator\n',1,NULL);
/*!40000 ALTER TABLE `stock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take_item`
--

DROP TABLE IF EXISTS `stock_take_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take_item` (
  `stock_take_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gmd_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `classification` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coll_type_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('e','m','u','l') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'm',
  `checked_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`stock_take_id`,`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `status` (`status`),
  KEY `item_properties_idx` (`gmd_name`,`classification`,`coll_type_name`,`location`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take_item`
--

LOCK TABLES `stock_take_item` WRITE;
/*!40000 ALTER TABLE `stock_take_item` DISABLE KEYS */;
INSERT INTO `stock_take_item` VALUES (2,2,'101','',NULL,NULL,NULL,NULL,'My Library','l','Administrator',NULL),(2,3,'102','',NULL,NULL,NULL,NULL,'My Library','e','Administrator','2011-01-20 13:45:49'),(2,4,'103','',NULL,NULL,NULL,NULL,'My Library','m','Administrator',NULL),(2,5,'201','',NULL,NULL,NULL,NULL,'My Library','m','Administrator',NULL),(2,6,'301','',NULL,NULL,NULL,NULL,'My Library','e','Administrator','2011-01-11 16:33:43');
/*!40000 ALTER TABLE `stock_take_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` enum('staff','member','system') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'staff',
  `id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `log_msg` text COLLATE utf8_unicode_ci NOT NULL,
  `log_date` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
INSERT INTO `system_log` VALUES (1,'member','2','circulation','Administrator reserve item B00005 for member (2)','2011-01-17 16:57:26'),(2,'member','2','circulation','Administrator remove reservation for item B00005 for member (2)','2011-01-17 16:57:34'),(3,'member','2','circulation','Administrator reserve item B00005 for member (2)','2011-01-17 16:58:22'),(4,'member','2','circulation','Administrator remove reservation for item B00005 for member (2)','2011-01-17 16:58:33'),(5,'member','2','circulation','Administrator reserve item B00004 for member (2)','2011-01-17 17:20:33'),(6,'member','2','circulation','Administrator remove reservation for item B00002 for member (2)','2011-01-17 17:20:56'),(7,'member','2','circulation','Administrator remove reservation for item B00004 for member (2)','2011-01-17 17:21:04'),(8,'member','2','circulation','Administrator reserve item B00004 for member (2)','2011-01-17 17:22:21'),(9,'member','2','circulation','Administrator remove reservation for item B00004 for member (2)','2011-01-17 17:23:03'),(10,'member','2','circulation','Administrator reserve item B00004 for member (2)','2011-01-17 17:23:08'),(11,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-17 17:29:33'),(12,'member','2','circulation','Administrator start transaction with member (2)','2011-01-17 17:30:33'),(13,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-17 17:32:35'),(14,'member','','circulation','Administrator start transaction with member ()','2011-01-17 17:32:44'),(15,'member','1','circulation','Administrator start transaction with member (1)','2011-01-17 18:45:25'),(16,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-18 10:52:11'),(17,'member','1','circulation','Administrator start transaction with member (1)','2011-01-18 12:41:35'),(18,'staff','1','bibliography','Administrator insert bibliographic data (Ajax : creating Web pages with asynchronous JavaScript and XML) with biblio_id (475)','2011-01-18 12:52:35'),(19,'staff','1','bibliography','Administrator insert bibliographic data (Ajax : creating Web pages with asynchronous JavaScript and XML) with biblio_id (476)','2011-01-18 12:52:42'),(20,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-18 13:22:31'),(21,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-18 15:51:49'),(22,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-19 11:44:35'),(23,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-19 11:52:58'),(24,'member','','Login','Log Out from address 127.0.0.1','2011-01-19 11:54:46'),(25,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-19 11:54:54'),(26,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-19 12:22:34'),(27,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-19 12:23:44'),(28,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-19 12:23:52'),(29,'staff','1','system','update content data (Welcome To Admin Page) with contentname ()','2011-01-19 12:58:39'),(30,'staff','1','system','Administrator update module data (serialcontrol) with path (serial_control)','2011-01-19 13:27:21'),(31,'staff','1','system','Administrator update module data (serial control) with path (serial_control)','2011-01-19 13:27:46'),(32,'staff','1','system','Administrator update module data (master_file) with path (master_file)','2011-01-19 13:30:48'),(33,'staff','admin','Login','Login success for user admin from address ::1','2011-01-19 15:34:08'),(34,'member','1','circulation','Administrator start transaction with member (1)','2011-01-19 17:29:01'),(35,'member','1','circulation','Administrator extend loan for item b00002 for member (1)','2011-01-19 18:08:36'),(36,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-20 10:41:50'),(37,'member','1','circulation','Administrator start transaction with member (1)','2011-01-20 10:50:37'),(38,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-20 11:55:02'),(39,'member','1','circulation','Administrator return item b00002 for member (1)','2011-01-20 11:55:04'),(40,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-20 11:55:38'),(41,'staff','1','stock_take','Stock Take ERROR : Item Code b00001 doesnt exists in stock take data. Invalid Item Code OR Maybe out of Stock Take range','2011-01-20 13:46:25'),(42,'staff','1','stock_take','Stock Take Re-Synchronization','2011-01-20 14:24:25'),(43,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-20 16:48:34'),(44,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-20 16:48:42'),(45,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 10:55:00'),(46,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-21 13:20:01'),(47,'staff','1','system','Administrator change application global configuration','2011-01-21 13:20:20'),(48,'staff','1','system','Administrator change application global configuration','2011-01-21 13:20:51'),(49,'staff','1','system','Administrator change application global configuration','2011-01-21 13:21:21'),(50,'staff','1','system','Administrator change application global configuration','2011-01-21 13:21:48'),(51,'staff','1','system','Administrator change application global configuration','2011-01-21 13:22:05'),(52,'staff','1','system','Administrator change application global configuration','2011-01-21 13:22:21'),(53,'staff','1','system','Administrator change application global configuration','2011-01-21 13:23:19'),(54,'staff','1','system','Administrator change application global configuration','2011-01-21 13:24:21'),(55,'staff','1','bibliography','Administrator upload image file images.jpg.jpg','2011-01-21 13:45:56'),(56,'staff','1','bibliography','Administrator insert bibliographic data (Learn PHP5) with biblio_id (477)','2011-01-21 13:45:57'),(57,'staff','1','bibliography','Administrator insert item data (D101) with title (Learn PHP5)','2011-01-21 13:48:17'),(58,'staff','1','bibliography','Administrator insert item data (D102) with title (Learn PHP5)','2011-01-21 13:49:06'),(59,'staff','1','bibliography','Administrator insert item data (D103) with title (Learn PHP5)','2011-01-21 13:49:45'),(60,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 13:51:08'),(61,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 13:51:30'),(62,'staff','1','bibliography','Administrator update bibliographic data (Learn PHP5) with biblio_id ()','2011-01-21 13:54:37'),(63,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 13:59:20'),(64,'member','1','circulation','Administrator remove reservation for item B00003 for member (1)','2011-01-21 13:59:44'),(65,'member','1','circulation','Administrator reserve item D101 for member (1)','2011-01-21 14:00:12'),(66,'member','1','Login','Login success for member 1 from address 192.168.1.10','2011-01-21 14:03:08'),(67,'staff','1','system','Administrator update user data (Administrator) with username (admin)','2011-01-21 14:11:43'),(68,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 15:21:19'),(69,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-21 15:21:52'),(70,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 15:24:40'),(71,'staff','1','system','Administrator Log Out from application from address 192.168.1.10','2011-01-21 15:30:30'),(72,'member','','Login','Log Out from address 192.168.1.10','2011-01-21 15:31:34'),(73,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-21 15:32:08'),(74,'staff','1','system','Administrator Log Out from application from address 192.168.1.10','2011-01-21 15:38:46'),(75,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-21 15:40:13'),(76,'staff','1','bibliography','Administrator DELETE bibliographic data (Linux In a Nutshell) with biblio_id (2)','2011-01-21 16:17:01'),(77,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:38:37'),(78,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:38:59'),(79,'member','','circulation','Administrator start transaction with member ()','2011-01-21 16:39:29'),(80,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:39:40'),(81,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:43:17'),(82,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:43:38'),(83,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:44:06'),(84,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:44:32'),(85,'member','1','circulation','Administrator extend loan for item D103 for member (1)','2011-01-21 16:48:35'),(86,'member','1','circulation','Administrator return item D103 for member (1)','2011-01-21 16:48:56'),(87,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-21 16:50:32'),(88,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:52:23');
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `realname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `passwd` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT '0000-00-00',
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `realname` (`realname`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','Administrator','21232f297a57a5a743894a0e4a801fc3','2011-01-21 15:40:13','192.168.1.10','a:1:{i:0;s:1:\"1\";}','2011-01-10','2011-01-21'),(2,'iresh','Administrator','iresh',NULL,NULL,NULL,'0000-00-00',NULL),(3,'harshit','harshit','83a75f0b31435193bafd3b9c5fd45aec',NULL,NULL,'a:1:{i:0;s:1:\"2\";}','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
INSERT INTO `user_group` VALUES (1,'Administrator','2011-01-10','2011-01-10'),(2,'Students','2011-01-10','2011-01-17');
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_count`
--

DROP TABLE IF EXISTS `visitor_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitor_count` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `institution` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `checkin_date` datetime NOT NULL,
  PRIMARY KEY (`visitor_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_count`
--

LOCK TABLES `visitor_count` WRITE;
/*!40000 ALTER TABLE `visitor_count` DISABLE KEYS */;
INSERT INTO `visitor_count` VALUES (1,'1','iresh',NULL,'2011-01-12 12:25:04'),(2,'harshit','harshit bhatt','Tatva Foundation','2011-01-12 12:25:40');
/*!40000 ALTER TABLE `visitor_count` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-21 15:33:01
