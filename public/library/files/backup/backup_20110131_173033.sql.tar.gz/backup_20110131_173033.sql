-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `library`
--

USE `library`;

--
-- Table structure for table `backup_log`
--

DROP TABLE IF EXISTS `backup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_log` (
  `backup_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `backup_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backup_file` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`backup_log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_log`
--

LOCK TABLES `backup_log` WRITE;
/*!40000 ALTER TABLE `backup_log` DISABLE KEYS */;
INSERT INTO `backup_log` VALUES (1,1,'2011-01-11 13:10:35','/var/www/library/files/backup/backup_20110111_131035.sql.tar.gz'),(2,1,'2011-01-21 17:03:01','/var/www/library/files/backup/backup_20110121_170301.sql.tar.gz'),(3,1,'2011-01-25 15:24:44','/var/www/library/files/backup/backup_20110125_152444.sql.tar.gz'),(4,1,'2011-01-31 17:02:49','/var/www/library/files/backup/backup_20110131_170249.sql.tar.gz');
/*!40000 ALTER TABLE `backup_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio`
--

DROP TABLE IF EXISTS `biblio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio` (
  `biblio_id` int(11) NOT NULL AUTO_INCREMENT,
  `gmd_id` int(3) DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `edition` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isbn_issn` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `publish_year` int(4) DEFAULT NULL,
  `collation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `series_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_id` char(5) COLLATE utf8_unicode_ci DEFAULT 'en',
  `source` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish_place_id` int(11) DEFAULT NULL,
  `classification` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_att` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opac_hide` smallint(1) DEFAULT '0',
  `promoted` smallint(1) DEFAULT '0',
  `labels` text COLLATE utf8_unicode_ci,
  `frequency_id` int(11) NOT NULL DEFAULT '0',
  `spec_detail_info` text COLLATE utf8_unicode_ci,
  `input_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`biblio_id`),
  KEY `references_idx` (`gmd_id`,`publisher_id`,`language_id`,`publish_place_id`),
  KEY `classification` (`classification`),
  KEY `biblio_flag_idx` (`opac_hide`,`promoted`),
  FULLTEXT KEY `title_ft_idx` (`title`,`series_title`),
  FULLTEXT KEY `notes_ft_idx` (`notes`),
  FULLTEXT KEY `labels` (`labels`)
) ENGINE=MyISAM AUTO_INCREMENT=478 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio`
--

LOCK TABLES `biblio` WRITE;
/*!40000 ALTER TABLE `biblio` DISABLE KEYS */;
INSERT INTO `biblio` VALUES (1,1,'PHP 5 for dummies',NULL,'0764541668',1,2004,'xiv, 392 p. : ill. ; 24 cm.','For dummies','005.13/3-22 Jan p','en',NULL,1,'005.13/3 22',NULL,'php5_dummies.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 15:36:50','2007-11-29 16:26:59'),(3,1,'The Definitive Guide to MySQL 5',NULL,'9781590595350',3,2005,'784p.','Definitive Guide Series','005.75/85-22 Kof d','en',NULL,NULL,'005.75/85 22',NULL,'mysql_def_guide.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:01:08','2007-11-29 16:26:33'),(4,1,'Cathedral and the Bazaar: Musings on Linux and Open Source by an Accidental Revolutionary',NULL,'0-596-00108-8',2,2001,'208p.',NULL,'005.4/3222 Ray c','en',NULL,2,'005.4/32 22','The Cathedral & the Bazaar is a must for anyone who cares about the future of the computer industry or the dynamics of the information economy. This revised and expanded paperback edition includes new material on open source developments in 1999 and 2000. Raymond\'s clear and effective writing style accurately describing the benefits of open source software has been key to its success. (Source: http://safari.oreilly.com/0596001088)','cathedral_bazaar.jpg','cathedral-bazaar.pdf',0,0,NULL,0,NULL,'2007-11-29 16:14:44','2007-11-29 16:25:43'),(5,1,'Producing open source software : how to run a successful free software project','1st ed.','9780596007591',2,2005,'xx, 279 p. ; 24 cm.',NULL,'005.1-22 Fog p','en',NULL,2,'005.1 22','Includes index.','producing_oss.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:20:45','2007-11-29 16:31:21'),(6,1,'PostgreSQL : a comprehensive guide to building, programming, and administering PostgreSQL databases','1st ed.','0735712573',4,2003,'xvii, 790 p. : ill. ; 23cm.','DeveloperÃ¢â‚¬â„¢s library','005.75/85-22 Kor p','en',NULL,3,'005.75/85 22','PostgreSQL is the world\'s most advanced open-source database. PostgreSQL is the most comprehensive, in-depth, and easy-to-read guide to this award-winning database. This book starts with a thorough overview of SQL, a description of all PostgreSQL data types, and a complete explanation of PostgreSQL commands.','postgresql.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:29:33','0000-00-00 00:00:00'),(7,1,'Web application architecture : principles, protocols, and practices',NULL,'0471486566',5,2003,'xi, 357 p. : ill. ; 23 cm.',NULL,'005.7/2-21 Leo w','en',NULL,1,'005.7/2 21','An in-depth examination of the core concepts and general principles of Web application development.\r\nThis book uses examples from specific technologies (e.g., servlet API or XSL), without promoting or endorsing particular platforms or APIs. Such knowledge is critical when designing and debugging complex systems. This conceptual understanding makes it easier to learn new APIs that arise in the rapidly changing Internet environment.','webapp_arch.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:41:57','2007-11-29 16:32:46'),(8,1,'Ajax : creating Web pages with asynchronous JavaScript and XML','','9780132272674',6,2007,'xxii, 384 p. : ill. ; 24 cm.','Bruce PerensÃ¢â‚¬â„¢ Open Source series','006.7/86-22 Woy a','en',NULL,4,'006.7/86 22','Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.','ajax.jpg',NULL,0,1,NULL,0,'','2007-11-29 16:47:20','2011-01-13 13:22:23'),(9,1,'The organization of information','2nd ed.','1563089769',7,2004,'xxvii, 417 p. : ill. ; 27 cm.','Library and information science text series','025-22 Tay o','en',NULL,5,'025 22','A basic textbook for students of library and information studies, and a guide for practicing school library media specialists. Describes the impact of global forces and the school district on the development and operation of a media center, the technical and human side of management, programmatic activities, supportive services to students, and the quality and quantity of resources available to support programs.','organization_information.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 16:54:12','2007-11-29 16:27:20'),(10,1,'Library and Information Center Management','7th ed.','9781591584063',7,2007,'xxviii, 492 p. : ill. ; 27 cm.','Library and information science text series','025.1-22 Stu l','en',NULL,5,'025.1 22',NULL,'library_info_center.JPG',NULL,0,0,NULL,0,NULL,'2007-11-29 16:58:51','2007-11-29 16:27:40'),(11,1,'Information Architecture for the World Wide Web: Designing Large-Scale Web Sites','2nd ed.','9780596000356',2,2002,'500p.',NULL,'006.7-22 Mor i','en',NULL,6,'006.7 22','Information Architecture for the World Wide Web is about applying the principles of architecture and library science to web site design. Each website is like a public building, available for tourists and regulars alike to breeze through at their leisure. The job of the architect is to set up the framework for the site to make it comfortable and inviting for people to visit, relax in, and perhaps even return to someday.','information_arch.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:26:14','2007-11-29 16:32:25'),(12,1,'Corruption and development',NULL,'9780714649023',8,1998,'166 p. : ill. ; 22 cm.',NULL,'364.1 Rob c','en',NULL,7,'364.1/322/091724 21','The articles assembled in this volume offer a fresh approach to analysing the problem of corruption in developing countries and the k means to tackle the phenomenon.','corruption_development.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:45:30','2007-11-29 16:20:53'),(13,1,'Corruption and development : the anti-corruption campaigns',NULL,'0230525504',9,2007,'310p.',NULL,'364.1 Bra c','en',NULL,8,'364.1/323091724 22','This book provides a multidisciplinary interrogation of the global anti-corruption campaigns of the last ten years, arguing that while some positive change is observable, the period is also replete with perverse consequences and unintended outcomes','corruption_development_anti_campaign.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:49:49','2007-11-29 16:19:48'),(14,1,'Pigs at the trough : how corporate greed and political corruption are undermining America',NULL,'1400047714',10,2003,'275 p. ; 22 cm.',NULL,'364.1323 Huf p','en',NULL,8,'364.1323',NULL,'pigs_at_trough.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 17:56:00','2007-11-29 16:18:33'),(15,1,'Lords of poverty : the power, prestige, and corruption of the international aid business',NULL,'9780871134691',11,1994,'xvi, 234 p. ; 22 cm.',NULL,'338.9 Han l','en',NULL,8,'338.9/1/091724 20','Lords of Poverty is a case study in betrayals of a public trust. The shortcomings of aid are numerous, and serious enough to raise questions about the viability of the practice at its most fundamental levels. Hancocks report is thorough, deeply shocking, and certain to cause critical reevaluation of the governments motives in giving foreign aid, and of the true needs of our intended beneficiaries.','lords_of_poverty.jpg',NULL,0,0,NULL,0,NULL,'2007-11-29 18:08:13','2007-11-29 16:13:11'),(475,1,'Ajax : creating Web pages with asynchronous JavaScript and XML','','9780132272674',6,2007,'xxii, 384 p. : ill. ; 24 cm.','Bruce PerensÃ¢â‚¬â„¢ Open Source series','006.7/86-22 Woy a','en',NULL,4,'006.7/86 22','Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.',NULL,NULL,0,1,NULL,0,'','2011-01-18 12:52:35','2011-01-18 12:52:35'),(17,1,'media','','',NULL,0,'','','','',NULL,NULL,'','',NULL,NULL,0,0,'a:1:{i:0;a:2:{i:0;s:16:\"label-multimedia\";i:1;s:15:\"www.youtube.com\";}}',0,'','2011-01-12 15:22:44','2011-01-12 15:23:24'),(18,1,'gg','1','',NULL,0,'','','','',NULL,NULL,'','',NULL,NULL,0,1,NULL,0,'','2011-01-12 16:59:52','2011-01-12 17:00:21'),(477,1,'Learn PHP5','5th','123456789',3,2009,'php5','1001','201021','en',NULL,6,'','Learn PHP5 Technology','images.jpg.jpg',NULL,0,1,'a:3:{i:0;a:2:{i:0;s:9:\"label-new\";i:1;s:4:\"PHP5\";}i:1;a:2:{i:0;s:14:\"label-favorite\";i:1;s:11:\"www.php.net\";}i:2;a:2:{i:0;s:16:\"label-multimedia\";i:1;s:42:\"http://www.youtube.com/watch?v=17aAuMVippQ\";}}',8,'Learn PHP Technology','2011-01-21 13:45:56','2011-01-21 13:54:37'),(476,1,'Ajax : creating Web pages with asynchronous JavaScript and XML','','9780132272674',6,2007,'xxii, 384 p. : ill. ; 24 cm.','Bruce PerensÃ¢â‚¬â„¢ Open Source series','006.7/86-22 Woy a','en',NULL,4,'006.7/86 22','Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.',NULL,NULL,0,1,NULL,0,'','2011-01-18 12:52:42','2011-01-18 12:52:42');
/*!40000 ALTER TABLE `biblio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_attachment`
--

DROP TABLE IF EXISTS `biblio_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_attachment` (
  `biblio_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  `access_type` enum('public','private') COLLATE utf8_unicode_ci NOT NULL,
  `access_limit` text COLLATE utf8_unicode_ci,
  KEY `biblio_id` (`biblio_id`),
  KEY `file_id` (`file_id`),
  KEY `biblio_id_2` (`biblio_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_attachment`
--

LOCK TABLES `biblio_attachment` WRITE;
/*!40000 ALTER TABLE `biblio_attachment` DISABLE KEYS */;
INSERT INTO `biblio_attachment` VALUES (1,0,'public','a:1:{i:0;s:1:\"1\";}');
/*!40000 ALTER TABLE `biblio_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_author`
--

DROP TABLE IF EXISTS `biblio_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_author` (
  `biblio_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biblio_id`,`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_author`
--

LOCK TABLES `biblio_author` WRITE;
/*!40000 ALTER TABLE `biblio_author` DISABLE KEYS */;
INSERT INTO `biblio_author` VALUES (1,1,1),(3,7,1),(3,8,2),(4,9,1),(5,10,1),(6,11,1),(6,12,2),(7,13,1),(7,14,2),(8,15,1),(9,16,1),(10,17,1),(10,18,2),(11,19,1),(11,20,2),(12,21,1),(13,22,1),(14,23,1),(15,24,1),(477,1,1),(18,1,1),(20,26,2),(21,27,2),(22,28,2),(23,29,2),(24,30,2),(25,31,2),(26,32,2),(27,33,2),(28,34,2),(29,35,2),(30,36,2),(31,37,2),(32,38,2),(33,39,2),(34,40,2),(35,41,2),(36,42,2),(37,43,2),(38,44,2),(39,45,2),(40,46,2),(41,47,2),(42,48,2),(43,49,2),(44,50,2),(45,51,2),(46,52,2),(47,53,2),(48,54,2),(49,55,2),(50,56,2),(51,57,2),(52,58,2),(53,59,2),(54,60,2),(55,61,2),(56,62,2),(57,63,2),(58,64,2),(59,65,2),(60,66,2),(61,67,2),(62,68,2),(63,69,2),(64,70,2),(65,71,2),(66,72,2),(67,73,2),(68,74,2),(69,75,2),(70,76,2),(71,77,2);
/*!40000 ALTER TABLE `biblio_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_custom`
--

DROP TABLE IF EXISTS `biblio_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_custom` (
  `biblio_id` int(11) NOT NULL,
  PRIMARY KEY (`biblio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='one to one relation with real biblio table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_custom`
--

LOCK TABLES `biblio_custom` WRITE;
/*!40000 ALTER TABLE `biblio_custom` DISABLE KEYS */;
/*!40000 ALTER TABLE `biblio_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_topic`
--

DROP TABLE IF EXISTS `biblio_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_topic` (
  `biblio_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biblio_id`,`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_topic`
--

LOCK TABLES `biblio_topic` WRITE;
/*!40000 ALTER TABLE `biblio_topic` DISABLE KEYS */;
INSERT INTO `biblio_topic` VALUES (1,1,1),(1,2,2),(3,1,1),(3,6,2),(3,7,2),(4,4,1),(4,8,2),(5,8,1),(5,9,2),(6,1,1),(6,7,2),(7,2,1),(7,10,2),(8,1,1),(8,2,2),(9,11,1),(9,12,2),(9,13,2),(10,11,1),(10,14,2),(12,15,1),(12,16,2),(13,15,1),(14,15,1),(15,15,1),(15,17,2),(20,18,2),(477,1,1);
/*!40000 ALTER TABLE `biblio_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `content_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `content_path` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`content_id`),
  KEY `content_path` (`content_path`),
  FULLTEXT KEY `content_title` (`content_title`),
  FULLTEXT KEY `content_desc` (`content_desc`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,'Library Information','<h3>Contact Information</h3>\r\n<p><strong>Address :</strong> <br /> Jenderal Sudirman Road, Senayan, Jakarta, Indonesia - Postal Code : 10270 <br /> <strong>Phone Number :</strong> <br /> (021) 5711144 <br /> <strong>Fax Number :</strong> <br /> (021) 5711144</p>\r\n<h3>Opening Hours</h3>\r\n<p><strong>Monday - Friday :</strong> <br /> Open : 08.00 AM<br /> Break : 12.00 - 13.00 PM<br /> Close : 20.00 PM <br /> <strong>Saturday  :</strong> <br /> Open : 08.00 AM<br /> Break : 12.00 - 13.00 PM<br /> Close : 17.00 PM</p>\r\n<h3>Collections</h3>\r\n<p>We have many types of collections in our library, range from Fictions to Sciences Material, from printed material to digital collections such CD-ROM, CD, VCD and DVD. We also collect daily serials publications such as newspaper and also monthly serials such as magazines.</p>\r\n<h3>Library Membership</h3>\r\n<p>To be able to loan our library collections, you must first become library member. There is terms and conditions that you must obey.</p>','libinfo','2009-09-13 19:48:16','2009-09-13 19:48:16'),(2,'Help On Usage','<h3>Searching</h3>\r\n<p>There is 2 method available on searching library catalog. The first one is <strong>SIMPLE SEARCH</strong>, which is the simplest method on searching catalog, you just enter any keyword, either it contained in document titles, authors name or subjects. You can supply more than one keywords in Simple Search method and it will expanding your search results.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>ADVANCED SEARCH</strong>, lets you define keywords in more specific fields. If you want your keywords only contained in title field, then type your keyword in Title field and the system will scope it search only on <strong>Title</strong> field, not in other fields. Location field lets you narrowing search results by specific location, so only collection that exists in selected location get fetched by system.</p>','help','2009-09-13 19:48:16','2009-09-13 19:48:16'),(3,'Welcome To Admin Page','<table style=\"width: 100%;\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n<tbody>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon biblioIcon\" href=\"?mod=bibliography\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Book</div>\r\nThe Book module lets you manage your library book data. It also include collection items management     to manage a copies of your library collection so it can be used in library circulation.</td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon circulationIcon\" href=\"?mod=circulation\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Circulation</div>\r\nThe Circulation module is used for doing library circulation transaction such as collection loans and return. In this module you can also create loan rules that will be used in loan transaction proccess.</td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon memberIcon\" href=\"?mod=membership\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Membership</div>\r\nThe Membership module lets you manage library members such adding, updating and also removing. You can also manage membership type in this module.<br /><br /></td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon stockTakeIcon\" href=\"?mod=stock_take\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Stock Take</div>\r\nThe Stock Take module is the easy way to do Stock Opname for your library collections. Follow several steps that ease your pain in Stock Opname proccess. <br /><br /></td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon masterFileIcon\" href=\"?mod=master_file\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Master File</div>\r\nThe Master File modules lets you manage referential data that will be used by another modules. It include Authority File management such     as Authority, Subject/Topic List, GMD and other data.</td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon systemIcon\" href=\"?mod=system\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">System</div>\r\nThe System module is used to configure application globally.</td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon reportIcon\" href=\"?mod=reporting\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Reporting</div>\r\n<p>Reporting lets you view various type of reports regardings membership data, circulation data and bibliographic data. All compiled on-the-fly from         current library database.</p>\r\n<br /></td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon serialIcon\" href=\"?mod=serial_control\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Serial Control</div>\r\nSerial Control module help you manage library\'s serial publication subscription. You can track issues for each subscription.</td>\r\n</tr>\r\n</tbody>\r\n</table>','adminhome','2009-09-13 19:48:16','2011-01-26 10:54:10'),(4,'Homepage Info','<p>Welcome To <strong>Triz\'s</strong> Online Public Access Catalog (OPAC). Use OPAC to search collection in our library.</p>','headerinfo','2009-09-13 19:48:16','2011-01-10 17:38:48');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_title` text COLLATE utf8_unicode_ci NOT NULL,
  `file_name` text COLLATE utf8_unicode_ci NOT NULL,
  `file_url` text COLLATE utf8_unicode_ci,
  `file_dir` text COLLATE utf8_unicode_ci,
  `mime_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_desc` text COLLATE utf8_unicode_ci,
  `uploader_id` int(11) NOT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `file_name` (`file_name`),
  FULLTEXT KEY `file_dir` (`file_dir`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fines`
--

DROP TABLE IF EXISTS `fines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fines` (
  `fines_id` int(11) NOT NULL AUTO_INCREMENT,
  `fines_date` date NOT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `debet` int(11) DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fines_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fines`
--

LOCK TABLES `fines` WRITE;
/*!40000 ALTER TABLE `fines` DISABLE KEYS */;
INSERT INTO `fines` VALUES (1,'2011-01-19','1',1,1,'dsfdsf'),(2,'2011-01-20','1',1,1,'iiiiiiiiiiiiiiiiiiiiiiiii'),(3,'2011-01-21','1',30,30,'Overdue fines for item b00001');
/*!40000 ALTER TABLE `fines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_access`
--

DROP TABLE IF EXISTS `group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_access` (
  `group_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `r` int(1) NOT NULL DEFAULT '0',
  `w` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`,`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_access`
--

LOCK TABLES `group_access` WRITE;
/*!40000 ALTER TABLE `group_access` DISABLE KEYS */;
INSERT INTO `group_access` VALUES (1,1,1,1),(1,2,1,1),(1,3,1,1),(1,4,1,1),(1,5,1,1),(1,6,1,1),(1,7,1,1),(1,8,1,1),(2,8,1,0),(2,7,1,0),(2,6,1,0),(2,5,1,0),(2,4,1,0),(2,3,1,0),(2,2,1,0),(2,1,1,0);
/*!40000 ALTER TABLE `group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_dayname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `holiday_date` date DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`holiday_id`),
  UNIQUE KEY `holiday_dayname` (`holiday_dayname`,`holiday_date`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday`
--

LOCK TABLES `holiday` WRITE;
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
INSERT INTO `holiday` VALUES (1,'Mon','2009-06-01','Tes Libur'),(2,'Tue','2009-06-02','Tes Libur'),(3,'Wed','2009-06-03','Tes Libur'),(4,'Thu','2009-06-04','Tes Libur'),(5,'Fri','2009-06-05','Tes Libur'),(6,'Sat','2009-06-06','Tes Libur');
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `biblio_id` int(11) DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coll_type_id` int(3) DEFAULT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inventory_code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `supplier_id` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_no` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `item_status_id` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` int(1) NOT NULL DEFAULT '0',
  `invoice` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `price_currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `item_references_idx` (`coll_type_id`,`location_id`,`item_status_id`),
  KEY `biblio_id_idx` (`biblio_id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,8,NULL,1,'b00001','INV/B00001','0000-00-00','0','','SL','0000-00-00','0','',1,'',500000,'Rupiah','0000-00-00','2008-12-26 22:11:10','2008-12-26 22:14:13'),(2,6,NULL,1,'B00002','INV/B00002','0000-00-00','0','','SL','0000-00-00','0','',1,'',700000,'Rupiah','0000-00-00','2008-12-26 22:11:45','2008-12-26 22:13:45'),(3,15,NULL,1,'B00003','INV/B00003','0000-00-00','0','','SL','0000-00-00','0','',1,'',300000,'Rupiah','0000-00-00','2008-12-26 22:15:09','2008-12-26 22:15:09'),(4,14,NULL,1,'B00004','INV/B00004','0000-00-00','0','','SL','0000-00-00','0','',1,'',250000,'Rupiah','0000-00-00','2008-12-26 22:15:49','2008-12-26 22:15:49'),(5,13,NULL,1,'B00005','INV/B00005','0000-00-00','0','','SL','0000-00-00','0','',2,'',0,NULL,'0000-00-00','2008-12-26 22:17:04','2008-12-26 22:17:04'),(6,12,NULL,1,'B00006','INV/B00006','0000-00-00','0','','SL','0000-00-00','0','',1,'',350000,'Rupiah','0000-00-00','2008-12-26 22:17:52','2008-12-26 22:17:52'),(7,4,NULL,1,'B00007','INV/B00007','0000-00-00','0','','SL','0000-00-00','0','',1,'',450000,'Rupiah','0000-00-00','2008-12-26 22:18:29','2008-12-26 22:18:29'),(8,4,NULL,1,'B00008','INV/B00008','0000-00-00','0','','SL','0000-00-00','0','',2,'',0,NULL,'0000-00-00','2008-12-26 22:18:51','2008-12-26 22:18:51'),(74,477,'201021',1,'106',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:39:35','2011-01-26 12:39:35'),(72,477,'201021',1,'104',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:39:35','2011-01-26 12:39:35'),(73,477,'201021',1,'105',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:39:35','2011-01-26 12:39:35'),(71,477,'201021',1,'103',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:39:35','2011-01-26 12:39:35'),(70,477,'201021',1,'102',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:39:35','2011-01-26 12:39:35'),(75,477,'201021',1,'i12',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:44:02','2011-01-26 12:44:02'),(76,477,'201021',1,'i13',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:44:02','2011-01-26 12:44:02'),(77,477,'201021',1,'i14',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:44:02','2011-01-26 12:44:02'),(78,477,'201021',1,'i15',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 12:44:02','2011-01-26 12:44:02'),(79,478,'201021',1,'1',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 18:55:56','2011-01-26 18:55:56'),(80,478,'201021',1,'2',NULL,'2011-01-26','0','','SL','2011-01-26','0','',1,'',0,NULL,'2011-01-26','2011-01-26 18:55:56','2011-01-26 18:55:56'),(81,477,'201021',1,'a',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(82,477,'201021',1,'b',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(83,477,'201021',1,'c',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(84,477,'201021',1,'d',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(85,477,'201021',1,'e',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(86,477,'201021',1,'f',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(87,477,'201021',1,'g',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(88,477,'201021',1,'h',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(89,477,'201021',1,'i',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55'),(90,477,'201021',1,'j',NULL,'2011-01-31','0','','SL','2011-01-31','0','',1,'',0,NULL,'2011-01-31','2011-01-31 15:43:55','2011-01-31 15:43:55');
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kardex`
--

DROP TABLE IF EXISTS `kardex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kardex` (
  `kardex_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_expected` date NOT NULL,
  `date_received` date DEFAULT NULL,
  `seq_number` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `serial_id` int(11) DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`kardex_id`),
  KEY `fk_serial` (`serial_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kardex`
--

LOCK TABLES `kardex` WRITE;
/*!40000 ALTER TABLE `kardex` DISABLE KEYS */;
INSERT INTO `kardex` VALUES (1,'2011-01-21',NULL,'1',NULL,1,'2011-01-21','2011-01-21');
/*!40000 ALTER TABLE `kardex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `loan_date` date NOT NULL,
  `due_date` date NOT NULL,
  `renewed` int(11) NOT NULL DEFAULT '0',
  `loan_rules_id` int(11) NOT NULL DEFAULT '0',
  `actual` date DEFAULT NULL,
  `is_lent` int(11) NOT NULL DEFAULT '0',
  `is_return` int(11) NOT NULL DEFAULT '0',
  `return_date` date DEFAULT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `item_code` (`item_code`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (1,'b00001','1','2011-01-31','2011-02-15',0,1,NULL,1,0,NULL),(2,'b00007','1','2011-01-31','2011-02-15',0,1,NULL,1,0,NULL),(3,'b00005','1','2011-01-31','2011-02-15',0,1,NULL,1,0,NULL),(4,'b00006','1','2011-01-31','2011-02-15',0,1,NULL,1,0,NULL),(5,'b00002','1','2011-01-31','2011-02-15',0,1,NULL,1,0,NULL);
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `member_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(1) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `member_type_id` int(6) DEFAULT NULL,
  `member_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inst_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_new` int(1) DEFAULT NULL,
  `member_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pin` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_fax` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_since_date` date DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  `expire_date` date NOT NULL,
  `member_notes` text COLLATE utf8_unicode_ci,
  `is_pending` smallint(1) NOT NULL DEFAULT '0',
  `mpasswd` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `member_name` (`member_name`),
  KEY `member_type_id` (`member_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('M00001','Hendro Wicaksono',1,'1974-06-05',1,'','hendrowicaksono@yahoo.com','','Perpustakaan Depdiknas',NULL,NULL,'','','','2009-04-15','2009-04-15','2010-04-15','',0,NULL,NULL,NULL,'2009-04-15','2009-06-11'),('M00002','Arie Nugraha',1,'1982-12-06',1,'','dicarve@yahoo.com','','Perpustakaan Depdiknas',NULL,NULL,'','','','2009-04-15','2009-04-15','2010-04-15','',0,NULL,NULL,NULL,'2009-04-15','2009-06-11'),('1','iresh',1,'1992-01-10',1,'','ireshparmar@gmail.com','','',NULL,NULL,'','','','2011-01-10','2011-01-10','2012-01-10','',0,'e8803a533120facc671d141febf14c32','2011-01-27 15:49:39','127.0.0.1','2011-01-10','2011-01-10'),('2','harshit bhatt',1,'2011-01-26',1,'surat','hbhatt26@gmail.com','395003','Tatva Foundation',NULL,NULL,'','','','2011-01-10','2011-01-10','2012-01-10','',0,'e99a18c428cb38d5f260853678922e03','2011-01-12 16:47:09','192.168.1.20','2011-01-10','2011-01-10'),('3','hiren',1,'1994-01-11',1,'','','','',NULL,NULL,'','','','2011-01-01','2011-01-11','2012-01-11','',0,'ec560dff9aaf87483e469b6abd8cd50c','2011-01-22 13:52:15','127.0.0.1','2011-01-11','2011-01-11'),('5','hiren',0,'0000-00-00',1,'','ireshparmar@gmail.com','','',NULL,NULL,'','','','2011-01-08','2011-01-17','2012-01-17','',0,'ec560dff9aaf87483e469b6abd8cd50c','2011-01-17 16:20:19','127.0.0.1','2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_author`
--

DROP TABLE IF EXISTS `mst_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `authority_type` enum('p','o','c') COLLATE utf8_unicode_ci DEFAULT 'p',
  `auth_list` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  UNIQUE KEY `author_name` (`author_name`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_author`
--

LOCK TABLES `mst_author` WRITE;
/*!40000 ALTER TABLE `mst_author` DISABLE KEYS */;
INSERT INTO `mst_author` VALUES (1,'Valade, Janet','p',NULL,'2007-11-29','2007-11-29'),(2,'Siever, Ellen','p',NULL,'2007-11-29','2007-11-29'),(3,'Love, Robert','p',NULL,'2007-11-29','2007-11-29'),(4,'Robbins, Arnold','p',NULL,'2007-11-29','2007-11-29'),(5,'Figgins, Stephen','p',NULL,'2007-11-29','2007-11-29'),(6,'Weber, Aaron','p',NULL,'2007-11-29','2007-11-29'),(7,'Kofler, Michael','p',NULL,'2007-11-29','2007-11-29'),(8,'Kramer, David','p',NULL,'2007-11-29','2007-11-29'),(9,'Raymond, Eric','p',NULL,'2007-11-29','2007-11-29'),(10,'Fogel, Karl','p',NULL,'2007-11-29','2007-11-29'),(11,'Douglas, Korry','p',NULL,'2007-11-29','2007-11-29'),(12,'Douglas, Susan','p',NULL,'2007-11-29','2007-11-29'),(13,'Shklar, Leon','p',NULL,'2007-11-29','2007-11-29'),(14,'Rosen, Richard','p',NULL,'2007-11-29','2007-11-29'),(15,'Woychowsky, Edmond','p',NULL,'2007-11-29','2007-11-29'),(16,'Taylor, Arlene G.','p',NULL,'2007-11-29','2007-11-29'),(17,'Stueart, Robert D.','p',NULL,'2007-11-29','2007-11-29'),(18,'Moran, Barbara B.','p',NULL,'2007-11-29','2007-11-29'),(19,'Morville, Peter','p',NULL,'2007-11-29','2007-11-29'),(20,'Rosenfeld, Louis','p',NULL,'2007-11-29','2007-11-29'),(21,'Robinson, Mark','p',NULL,'2007-11-29','2007-11-29'),(22,'Bracking, Sarah','p',NULL,'2007-11-29','2007-11-29'),(23,'Huffington, Arianna Stassinopoulos','p',NULL,'2007-11-29','2007-11-29'),(24,'Hancock, Graham','p',NULL,'2007-11-29','2007-11-29'),(25,'iresh','p',NULL,'2011-01-12','2011-01-12'),(26,'birthdate','p',NULL,'2011-01-17','2011-01-17'),(27,'23/11/1989','p',NULL,'2011-01-17','2011-01-17'),(28,'24/08/1989','p',NULL,'2011-01-17','2011-01-17'),(29,'8/7/1987','p',NULL,'2011-01-17','2011-01-17'),(30,'13/04/1986','p',NULL,'2011-01-17','2011-01-17'),(31,'27/11/1984','p',NULL,'2011-01-17','2011-01-17'),(32,'17/05/1989','p',NULL,'2011-01-17','2011-01-17'),(33,'9/7/1989','p',NULL,'2011-01-17','2011-01-17'),(34,'11/8/1987','p',NULL,'2011-01-17','2011-01-17'),(35,'11/9/1988','p',NULL,'2011-01-17','2011-01-17'),(36,'19/11/1985','p',NULL,'2011-01-17','2011-01-17'),(37,'24/10/1984','p',NULL,'2011-01-17','2011-01-17'),(38,'7/10/1987','p',NULL,'2011-01-17','2011-01-17'),(39,'5/6/1989','p',NULL,'2011-01-17','2011-01-17'),(40,'22/12/1989','p',NULL,'2011-01-17','2011-01-17'),(41,'28/08/1983','p',NULL,'2011-01-17','2011-01-17'),(42,'18/06/1990','p',NULL,'2011-01-17','2011-01-17'),(43,'22/04/1989','p',NULL,'2011-01-17','2011-01-17'),(44,'5/6/1990','p',NULL,'2011-01-17','2011-01-17'),(45,'13/06/1988','p',NULL,'2011-01-17','2011-01-17'),(46,'15/08/1989','p',NULL,'2011-01-17','2011-01-17'),(47,'13/11/1989','p',NULL,'2011-01-17','2011-01-17'),(48,'8/2/1990','p',NULL,'2011-01-17','2011-01-17'),(49,'6/1/1986','p',NULL,'2011-01-17','2011-01-17'),(50,'2/10/1989','p',NULL,'2011-01-17','2011-01-17'),(51,'6/8/1990','p',NULL,'2011-01-17','2011-01-17'),(52,'25/06/1989','p',NULL,'2011-01-17','2011-01-17'),(53,'24/03/1989','p',NULL,'2011-01-17','2011-01-17'),(54,'15/06/1989','p',NULL,'2011-01-17','2011-01-17'),(55,'22/05/1987','p',NULL,'2011-01-17','2011-01-17'),(56,'3/12/1989','p',NULL,'2011-01-17','2011-01-17'),(57,'4/6/1990','p',NULL,'2011-01-17','2011-01-17'),(58,'9/12/1989','p',NULL,'2011-01-17','2011-01-17'),(59,'20/11/1989','p',NULL,'2011-01-17','2011-01-17'),(60,'6/12/1989','p',NULL,'2011-01-17','2011-01-17'),(61,'28/05/1989','p',NULL,'2011-01-17','2011-01-17'),(62,'24/03/1990','p',NULL,'2011-01-17','2011-01-17'),(63,'15/10/1988','p',NULL,'2011-01-17','2011-01-17'),(64,'19/08/1990','p',NULL,'2011-01-17','2011-01-17'),(65,'1/9/1985','p',NULL,'2011-01-17','2011-01-17'),(66,'14/11/1989','p',NULL,'2011-01-17','2011-01-17'),(67,'9/3/1990','p',NULL,'2011-01-17','2011-01-17'),(68,'19/11/1989','p',NULL,'2011-01-17','2011-01-17'),(69,'18/05/1989','p',NULL,'2011-01-17','2011-01-17'),(70,'16/08/1988','p',NULL,'2011-01-17','2011-01-17'),(71,'4/8/1982','p',NULL,'2011-01-17','2011-01-17'),(72,'19/04/1989','p',NULL,'2011-01-17','2011-01-17'),(73,'31/08/1984','p',NULL,'2011-01-17','2011-01-17'),(74,'6/10/1989','p',NULL,'2011-01-17','2011-01-17'),(75,'18/08/1988','p',NULL,'2011-01-17','2011-01-17'),(76,'23/02/1989','p',NULL,'2011-01-17','2011-01-17'),(77,'26/08/1989','p',NULL,'2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_coll_type`
--

DROP TABLE IF EXISTS `mst_coll_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_coll_type` (
  `coll_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `coll_type_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`coll_type_id`),
  UNIQUE KEY `coll_type_name` (`coll_type_name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_coll_type`
--

LOCK TABLES `mst_coll_type` WRITE;
/*!40000 ALTER TABLE `mst_coll_type` DISABLE KEYS */;
INSERT INTO `mst_coll_type` VALUES (2,'Reference','2011-01-25','2011-01-25'),(1,'Textbook','2011-01-25','2011-01-25'),(3,'Fiction','2011-01-25','2011-01-25');
/*!40000 ALTER TABLE `mst_coll_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_frequency`
--

DROP TABLE IF EXISTS `mst_frequency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_frequency` (
  `frequency_id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `language_prefix` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_increment` smallint(6) DEFAULT NULL,
  `time_unit` enum('day','week','month','year') COLLATE utf8_unicode_ci DEFAULT 'day',
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`frequency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_frequency`
--

LOCK TABLES `mst_frequency` WRITE;
/*!40000 ALTER TABLE `mst_frequency` DISABLE KEYS */;
INSERT INTO `mst_frequency` VALUES (1,'Weekly','en',1,'week','2009-05-23','2009-05-23'),(2,'Bi-weekly','en',2,'week','2009-05-23','2009-05-23'),(3,'Fourth-Nightly','en',14,'day','2009-05-23','2009-05-23'),(4,'Monthly','en',1,'month','2009-05-23','2009-05-23'),(5,'Bi-Monthly','en',2,'month','2009-05-23','2009-05-23'),(6,'Quarterly','en',3,'month','2009-05-23','2009-05-23'),(7,'3 Times a Year','en',4,'month','2009-05-23','2009-05-23'),(8,'Annualy','en',1,'year','2009-05-23','2009-05-23');
/*!40000 ALTER TABLE `mst_frequency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_gmd`
--

DROP TABLE IF EXISTS `mst_gmd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_gmd` (
  `gmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `gmd_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmd_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `icon_image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`gmd_id`),
  UNIQUE KEY `gmd_name` (`gmd_name`),
  UNIQUE KEY `gmd_code` (`gmd_code`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_gmd`
--

LOCK TABLES `mst_gmd` WRITE;
/*!40000 ALTER TABLE `mst_gmd` DISABLE KEYS */;
INSERT INTO `mst_gmd` VALUES (1,'TE','Text',NULL,'2011-01-10','2011-01-10'),(2,'AR','Art Original',NULL,'2011-01-10','2011-01-10'),(3,'CH','Chart',NULL,'2011-01-10','2011-01-10'),(4,'CO','Computer Software',NULL,'2011-01-10','2011-01-10'),(5,'DI','Diorama',NULL,'2011-01-10','2011-01-10'),(6,'FI','Filmstrip',NULL,'2011-01-10','2011-01-10'),(7,'FL','Flash Card',NULL,'2011-01-10','2011-01-10'),(8,'GA','Game',NULL,'2011-01-10','2011-01-10'),(9,'GL','Globe',NULL,'2011-01-10','2011-01-10'),(10,'KI','Kit',NULL,'2011-01-10','2011-01-10'),(11,'MA','Map',NULL,'2011-01-10','2011-01-10'),(12,'MI','Microform',NULL,'2011-01-10','2011-01-10'),(13,'MN','Manuscript',NULL,'2011-01-10','2011-01-10'),(14,'MO','Model',NULL,'2011-01-10','2011-01-10'),(15,'MP','Motion Picture',NULL,'2011-01-10','2011-01-10'),(16,'MS','Microscope Slide',NULL,'2011-01-10','2011-01-10'),(17,'MU','Music',NULL,'2011-01-10','2011-01-10'),(18,'PI','Picture',NULL,'2011-01-10','2011-01-10'),(19,'RE','Realia',NULL,'2011-01-10','2011-01-10'),(20,'SL','Slide',NULL,'2011-01-10','2011-01-10'),(21,'SO','Sound Recording',NULL,'2011-01-10','2011-01-10'),(22,'TD','Technical Drawing',NULL,'2011-01-10','2011-01-10'),(23,'TR','Transparency',NULL,'2011-01-10','2011-01-10'),(24,'VI','Video Recording',NULL,'2011-01-10','2011-01-10'),(25,'EQ','Equipment',NULL,'2011-01-10','2011-01-10'),(26,'CF','Computer File',NULL,'2011-01-10','2011-01-10'),(27,'CA','Cartographic Material',NULL,'2011-01-10','2011-01-10'),(28,'CD','CD-ROM',NULL,'2011-01-10','2011-01-10'),(29,'MV','Multimedia',NULL,'2011-01-10','2011-01-10'),(30,'ER','Electronic Resource',NULL,'2011-01-10','2011-01-10'),(31,'DVD','Digital Versatile Disc',NULL,'2011-01-10','2011-01-10'),(32,NULL,'last_name',NULL,'2011-01-17','2011-01-17'),(33,NULL,'SHAH',NULL,'2011-01-17','2011-01-17'),(34,NULL,'PANDYA',NULL,'2011-01-17','2011-01-17'),(35,NULL,'GOSWAMI',NULL,'2011-01-17','2011-01-17'),(36,NULL,'DAVE',NULL,'2011-01-17','2011-01-17'),(37,NULL,'BHEDA',NULL,'2011-01-17','2011-01-17'),(38,NULL,'JOSHI',NULL,'2011-01-17','2011-01-17'),(39,NULL,'BHATT',NULL,'2011-01-17','2011-01-17'),(40,NULL,'PATEL',NULL,'2011-01-17','2011-01-17'),(41,NULL,'DHANDHA',NULL,'2011-01-17','2011-01-17'),(42,NULL,'JETHVA',NULL,'2011-01-17','2011-01-17'),(43,NULL,'RATHOD',NULL,'2011-01-17','2011-01-17'),(44,NULL,'KARNAVAT',NULL,'2011-01-17','2011-01-17'),(45,NULL,'GOHEL',NULL,'2011-01-17','2011-01-17'),(46,NULL,'KHAMBHOLJA',NULL,'2011-01-17','2011-01-17'),(47,NULL,'CHHATTRALA',NULL,'2011-01-17','2011-01-17'),(48,NULL,'RABARA',NULL,'2011-01-17','2011-01-17'),(49,NULL,'SHARMA',NULL,'2011-01-17','2011-01-17'),(50,NULL,'TIRMIZI',NULL,'2011-01-17','2011-01-17'),(51,NULL,'NATHANI',NULL,'2011-01-17','2011-01-17'),(52,NULL,'JHA',NULL,'2011-01-17','2011-01-17'),(53,NULL,'DESAI',NULL,'2011-01-17','2011-01-17'),(54,NULL,'ADESHARA',NULL,'2011-01-17','2011-01-17'),(55,NULL,'VASANI',NULL,'2011-01-17','2011-01-17'),(56,NULL,'DAS',NULL,'2011-01-17','2011-01-17'),(57,NULL,'SHAIKH',NULL,'2011-01-17','2011-01-17'),(58,NULL,'KOTADIYA',NULL,'2011-01-17','2011-01-17'),(59,NULL,'SANKHAVARA',NULL,'2011-01-17','2011-01-17'),(60,NULL,'KAKADIYA',NULL,'2011-01-17','2011-01-17'),(61,NULL,'SONI',NULL,'2011-01-17','2011-01-17'),(62,NULL,'NALIYADHARA',NULL,'2011-01-17','2011-01-17'),(63,NULL,'VAGHANI',NULL,'2011-01-17','2011-01-17'),(64,NULL,'PANCHAL',NULL,'2011-01-17','2011-01-17'),(65,NULL,'THAKKAR',NULL,'2011-01-17','2011-01-17'),(66,NULL,'',NULL,'2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_gmd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_item_status`
--

DROP TABLE IF EXISTS `mst_item_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_item_status` (
  `item_status_id` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `item_status_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `rules` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_loan` smallint(1) NOT NULL DEFAULT '0',
  `skip_stock_take` smallint(1) NOT NULL DEFAULT '0',
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`item_status_id`),
  UNIQUE KEY `item_status_name` (`item_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_item_status`
--

LOCK TABLES `mst_item_status` WRITE;
/*!40000 ALTER TABLE `mst_item_status` DISABLE KEYS */;
INSERT INTO `mst_item_status` VALUES ('R','Repair','a:1:{i:0;s:1:\"1\";}',0,0,'2011-01-10','2011-01-10'),('NL','No Loan','a:1:{i:0;s:1:\"1\";}',0,0,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_item_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_label`
--

DROP TABLE IF EXISTS `mst_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_label` (
  `label_id` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `label_desc` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label_image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`label_id`),
  UNIQUE KEY `label_name` (`label_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_label`
--

LOCK TABLES `mst_label` WRITE;
/*!40000 ALTER TABLE `mst_label` DISABLE KEYS */;
INSERT INTO `mst_label` VALUES (1,'label-new','New Title','label-new.png','2011-01-10','2011-01-10'),(2,'label-favorite','Favorite Title','label-favorite.png','2011-01-10','2011-01-17'),(3,'label-multimedia','Multimedia','label-multimedia.png','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_language`
--

DROP TABLE IF EXISTS `mst_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_language` (
  `language_id` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `language_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `language_name` (`language_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_language`
--

LOCK TABLES `mst_language` WRITE;
/*!40000 ALTER TABLE `mst_language` DISABLE KEYS */;
INSERT INTO `mst_language` VALUES ('','Indonesia','2011-01-12','2011-01-12'),('en','English','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_loan_rules`
--

DROP TABLE IF EXISTS `mst_loan_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_loan_rules` (
  `loan_rules_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_id` int(11) NOT NULL DEFAULT '0',
  `coll_type_id` int(11) DEFAULT '0',
  `gmd_id` int(11) DEFAULT '0',
  `loan_limit` int(3) DEFAULT '0',
  `loan_periode` int(3) DEFAULT '0',
  `reborrow_limit` int(3) DEFAULT '0',
  `fine_each_day` int(3) DEFAULT '0',
  `grace_periode` int(2) DEFAULT '0',
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`loan_rules_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_loan_rules`
--

LOCK TABLES `mst_loan_rules` WRITE;
/*!40000 ALTER TABLE `mst_loan_rules` DISABLE KEYS */;
INSERT INTO `mst_loan_rules` VALUES (1,1,2,1,15,15,15,5,5,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_loan_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_location`
--

DROP TABLE IF EXISTS `mst_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_location` (
  `location_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `location_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_name` (`location_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_location`
--

LOCK TABLES `mst_location` WRITE;
/*!40000 ALTER TABLE `mst_location` DISABLE KEYS */;
INSERT INTO `mst_location` VALUES ('SL','My Library','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_member_type`
--

DROP TABLE IF EXISTS `mst_member_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_member_type` (
  `member_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `loan_limit` int(11) NOT NULL,
  `loan_periode` int(11) NOT NULL,
  `enable_reserve` int(1) NOT NULL DEFAULT '0',
  `reserve_limit` int(11) NOT NULL DEFAULT '0',
  `member_periode` int(11) NOT NULL,
  `reborrow_limit` int(11) NOT NULL,
  `fine_each_day` int(11) NOT NULL,
  `grace_periode` int(2) DEFAULT '0',
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`member_type_id`),
  UNIQUE KEY `member_type_name` (`member_type_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_member_type`
--

LOCK TABLES `mst_member_type` WRITE;
/*!40000 ALTER TABLE `mst_member_type` DISABLE KEYS */;
INSERT INTO `mst_member_type` VALUES (1,'Standard',2,7,1,2,365,1,0,0,'2011-01-10','2011-01-11');
/*!40000 ALTER TABLE `mst_member_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_module`
--

DROP TABLE IF EXISTS `mst_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_module` (
  `module_id` int(3) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `module_path` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `module_name` (`module_name`,`module_path`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_module`
--

LOCK TABLES `mst_module` WRITE;
/*!40000 ALTER TABLE `mst_module` DISABLE KEYS */;
INSERT INTO `mst_module` VALUES (1,'book','bibliography','Manage your bibliographic/catalog and items/copies database'),(2,'circulation','circulation','Module for doing library items circulation such as loan and return'),(3,'membership','membership','Manage your library membership and membership type'),(4,'master_file','master_file','Manage your referential data that will be used by other modules'),(5,'stock_take','stock_take','Ease your pain in doing library stock opname process'),(6,'system','system','Configure system behaviour, user and backups'),(7,'reporting','reporting','Real time and dynamic report about library collections and circulation'),(8,'serial control','serial_control','Serial publication management');
/*!40000 ALTER TABLE `mst_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_place`
--

DROP TABLE IF EXISTS `mst_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_place` (
  `place_id` int(11) NOT NULL AUTO_INCREMENT,
  `place_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`place_id`),
  UNIQUE KEY `place_name` (`place_name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_place`
--

LOCK TABLES `mst_place` WRITE;
/*!40000 ALTER TABLE `mst_place` DISABLE KEYS */;
INSERT INTO `mst_place` VALUES (1,'Hoboken, NJ','2007-11-29','2007-11-29'),(2,'Sebastopol, CA','2007-11-29','2007-11-29'),(3,'Indianapolis','2007-11-29','2007-11-29'),(4,'Upper Saddle River, NJ','2007-11-29','2007-11-29'),(5,'Westport, Conn.','2007-11-29','2007-11-29'),(6,'Cambridge, Mass','2007-11-29','2007-11-29'),(7,'London','2007-11-29','2007-11-29'),(8,'New York','2007-11-29','2007-11-29'),(9,'','2011-01-12','2011-01-12'),(10,'religion','2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_publisher`
--

DROP TABLE IF EXISTS `mst_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_publisher` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`publisher_id`),
  UNIQUE KEY `publisher_name` (`publisher_name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_publisher`
--

LOCK TABLES `mst_publisher` WRITE;
/*!40000 ALTER TABLE `mst_publisher` DISABLE KEYS */;
INSERT INTO `mst_publisher` VALUES (1,'Wiley','2007-11-29','2007-11-29'),(2,'OReilly','2007-11-29','2007-11-29'),(3,'Apress','2007-11-29','2007-11-29'),(4,'Sams','2007-11-29','2007-11-29'),(5,'John Wiley','2007-11-29','2007-11-29'),(6,'Prentice Hall','2007-11-29','2007-11-29'),(7,'Libraries Unlimited','2007-11-29','2007-11-29'),(8,'Taylor & Francis Inc.','2007-11-29','2007-11-29'),(9,'Palgrave Macmillan','2007-11-29','2007-11-29'),(10,'Crown publishers','2007-11-29','2007-11-29'),(11,'Atlantic Monthly Press','2007-11-29','2007-11-29'),(13,'name_suffix','2011-01-17','2011-01-17'),(14,'Miss','2011-01-17','2011-01-17'),(15,'Mr','2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_supplier`
--

DROP TABLE IF EXISTS `mst_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` char(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` char(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `e_mail` char(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `supplier_name` (`supplier_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_supplier`
--

LOCK TABLES `mst_supplier` WRITE;
/*!40000 ALTER TABLE `mst_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `mst_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_topic`
--

DROP TABLE IF EXISTS `mst_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `topic_type` enum('t','g','n','tm','gr','oc') COLLATE utf8_unicode_ci NOT NULL,
  `auth_list` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic` (`topic`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_topic`
--

LOCK TABLES `mst_topic` WRITE;
/*!40000 ALTER TABLE `mst_topic` DISABLE KEYS */;
INSERT INTO `mst_topic` VALUES (1,'Programming','t',NULL,'2007-11-29','2007-11-29'),(2,'Website','t',NULL,'2007-11-29','2007-11-29'),(3,'Operating System','t',NULL,'2007-11-29','2007-11-29'),(4,'Linux','t',NULL,'2007-11-29','2007-11-29'),(5,'Computer','t',NULL,'2007-11-29','2007-11-29'),(6,'Database','t',NULL,'2007-11-29','2007-11-29'),(7,'RDBMS','t',NULL,'2007-11-29','2007-11-29'),(8,'Open Source','t',NULL,'2007-11-29','2007-11-29'),(9,'Project','t',NULL,'2007-11-29','2007-11-29'),(10,'Design','t',NULL,'2007-11-29','2007-11-29'),(11,'Information','t',NULL,'2007-11-29','2007-11-29'),(12,'Organization','t',NULL,'2007-11-29','2007-11-29'),(13,'Metadata','t',NULL,'2007-11-29','2007-11-29'),(14,'Library','t',NULL,'2007-11-29','2007-11-29'),(15,'Corruption','t',NULL,'2007-11-29','2007-11-29'),(16,'Development','t',NULL,'2007-11-29','2007-11-29'),(17,'Poverty','t',NULL,'2007-11-29','2007-11-29'),(18,'birthtime','t',NULL,'2011-01-17','2011-01-17');
/*!40000 ALTER TABLE `mst_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserve`
--

DROP TABLE IF EXISTS `reserve`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserve` (
  `reserve_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `biblio_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `reserve_date` date NOT NULL,
  PRIMARY KEY (`reserve_id`),
  KEY `references_idx` (`member_id`,`biblio_id`),
  KEY `item_code_idx` (`item_code`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserve`
--

LOCK TABLES `reserve` WRITE;
/*!40000 ALTER TABLE `reserve` DISABLE KEYS */;
INSERT INTO `reserve` VALUES (103,'2',8,'b00001','2011-01-28');
/*!40000 ALTER TABLE `reserve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serial`
--

DROP TABLE IF EXISTS `serial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serial` (
  `serial_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date DEFAULT NULL,
  `period` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `biblio_id` int(11) DEFAULT NULL,
  `gmd_id` int(11) DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`serial_id`),
  KEY `fk_serial_biblio` (`biblio_id`),
  KEY `fk_serial_gmd` (`gmd_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serial`
--

LOCK TABLES `serial` WRITE;
/*!40000 ALTER TABLE `serial` DISABLE KEYS */;
INSERT INTO `serial` VALUES (1,'2011-01-21',NULL,'Period 1','Period 1',477,NULL,'2011-01-21','2011-01-21');
/*!40000 ALTER TABLE `serial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `setting_id` int(3) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `setting_name` (`setting_name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'library_name','s:4:\"Triz\";'),(2,'library_subname','s:37:\"Open Source Library Management System\";'),(3,'template','a:2:{s:5:\"theme\";s:4:\"igos\";s:3:\"css\";s:23:\"template/igos/style.css\";}'),(4,'admin_template','a:2:{s:5:\"theme\";s:4:\"igos\";s:3:\"css\";s:29:\"admin_template/igos/style.css\";}'),(5,'default_lang','s:5:\"en_US\";'),(6,'opac_result_num','s:2:\"10\";'),(7,'enable_promote_titles','a:1:{i:0;s:1:\"1\";}'),(8,'quick_return','b:1;'),(9,'allow_loan_date_change','b:1;'),(10,'loan_limit_override','b:1;'),(11,'enable_xml_detail','b:0;'),(12,'enable_xml_result','b:0;'),(13,'allow_file_download','b:1;'),(14,'session_timeout','s:4:\"7200\";'),(15,'circulation_receipt','b:1;'),(16,'barcode_encoding','s:4:\"128B\";');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take`
--

DROP TABLE IF EXISTS `stock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take` (
  `stock_take_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_take_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `init_user` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `total_item_stock_taked` int(11) DEFAULT NULL,
  `total_item_lost` int(11) DEFAULT NULL,
  `total_item_exists` int(11) DEFAULT '0',
  `total_item_loan` int(11) DEFAULT NULL,
  `stock_take_users` mediumtext COLLATE utf8_unicode_ci,
  `is_active` int(1) NOT NULL DEFAULT '0',
  `report_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`stock_take_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take`
--

LOCK TABLES `stock_take` WRITE;
/*!40000 ALTER TABLE `stock_take` DISABLE KEYS */;
INSERT INTO `stock_take` VALUES (1,'h','2011-01-10 15:51:53','2011-01-10 14:21:49','Administrator',1,1,0,0,'Administrator\n',0,'h_report.html'),(2,'h','2011-01-11 13:09:18',NULL,'Administrator',4,2,0,1,'Administrator\n',1,NULL);
/*!40000 ALTER TABLE `stock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take_item`
--

DROP TABLE IF EXISTS `stock_take_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take_item` (
  `stock_take_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gmd_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `classification` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coll_type_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('e','m','u','l') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'm',
  `checked_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`stock_take_id`,`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `status` (`status`),
  KEY `item_properties_idx` (`gmd_name`,`classification`,`coll_type_name`,`location`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take_item`
--

LOCK TABLES `stock_take_item` WRITE;
/*!40000 ALTER TABLE `stock_take_item` DISABLE KEYS */;
INSERT INTO `stock_take_item` VALUES (2,2,'101','',NULL,NULL,NULL,NULL,'My Library','l','Administrator',NULL),(2,3,'102','',NULL,NULL,NULL,NULL,'My Library','e','Administrator','2011-01-20 13:45:49'),(2,4,'103','',NULL,NULL,NULL,NULL,'My Library','m','Administrator',NULL),(2,5,'201','',NULL,NULL,NULL,NULL,'My Library','m','Administrator',NULL),(2,6,'301','',NULL,NULL,NULL,NULL,'My Library','e','Administrator','2011-01-11 16:33:43');
/*!40000 ALTER TABLE `stock_take_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` enum('staff','member','system') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'staff',
  `id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `log_msg` text COLLATE utf8_unicode_ci NOT NULL,
  `log_date` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=893 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
INSERT INTO `system_log` VALUES (1,'member','2','circulation','Administrator reserve item B00005 for member (2)','2011-01-17 16:57:26'),(2,'member','2','circulation','Administrator remove reservation for item B00005 for member (2)','2011-01-17 16:57:34'),(3,'member','2','circulation','Administrator reserve item B00005 for member (2)','2011-01-17 16:58:22'),(4,'member','2','circulation','Administrator remove reservation for item B00005 for member (2)','2011-01-17 16:58:33'),(5,'member','2','circulation','Administrator reserve item B00004 for member (2)','2011-01-17 17:20:33'),(6,'member','2','circulation','Administrator remove reservation for item B00002 for member (2)','2011-01-17 17:20:56'),(7,'member','2','circulation','Administrator remove reservation for item B00004 for member (2)','2011-01-17 17:21:04'),(8,'member','2','circulation','Administrator reserve item B00004 for member (2)','2011-01-17 17:22:21'),(9,'member','2','circulation','Administrator remove reservation for item B00004 for member (2)','2011-01-17 17:23:03'),(10,'member','2','circulation','Administrator reserve item B00004 for member (2)','2011-01-17 17:23:08'),(11,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-17 17:29:33'),(12,'member','2','circulation','Administrator start transaction with member (2)','2011-01-17 17:30:33'),(13,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-17 17:32:35'),(14,'member','','circulation','Administrator start transaction with member ()','2011-01-17 17:32:44'),(15,'member','1','circulation','Administrator start transaction with member (1)','2011-01-17 18:45:25'),(16,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-18 10:52:11'),(17,'member','1','circulation','Administrator start transaction with member (1)','2011-01-18 12:41:35'),(18,'staff','1','bibliography','Administrator insert bibliographic data (Ajax : creating Web pages with asynchronous JavaScript and XML) with biblio_id (475)','2011-01-18 12:52:35'),(19,'staff','1','bibliography','Administrator insert bibliographic data (Ajax : creating Web pages with asynchronous JavaScript and XML) with biblio_id (476)','2011-01-18 12:52:42'),(20,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-18 13:22:31'),(21,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-18 15:51:49'),(22,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-19 11:44:35'),(23,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-19 11:52:58'),(24,'member','','Login','Log Out from address 127.0.0.1','2011-01-19 11:54:46'),(25,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-19 11:54:54'),(26,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-19 12:22:34'),(27,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-19 12:23:44'),(28,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-19 12:23:52'),(29,'staff','1','system','update content data (Welcome To Admin Page) with contentname ()','2011-01-19 12:58:39'),(30,'staff','1','system','Administrator update module data (serialcontrol) with path (serial_control)','2011-01-19 13:27:21'),(31,'staff','1','system','Administrator update module data (serial control) with path (serial_control)','2011-01-19 13:27:46'),(32,'staff','1','system','Administrator update module data (master_file) with path (master_file)','2011-01-19 13:30:48'),(33,'staff','admin','Login','Login success for user admin from address ::1','2011-01-19 15:34:08'),(34,'member','1','circulation','Administrator start transaction with member (1)','2011-01-19 17:29:01'),(35,'member','1','circulation','Administrator extend loan for item b00002 for member (1)','2011-01-19 18:08:36'),(36,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-20 10:41:50'),(37,'member','1','circulation','Administrator start transaction with member (1)','2011-01-20 10:50:37'),(38,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-20 11:55:02'),(39,'member','1','circulation','Administrator return item b00002 for member (1)','2011-01-20 11:55:04'),(40,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-20 11:55:38'),(41,'staff','1','stock_take','Stock Take ERROR : Item Code b00001 doesnt exists in stock take data. Invalid Item Code OR Maybe out of Stock Take range','2011-01-20 13:46:25'),(42,'staff','1','stock_take','Stock Take Re-Synchronization','2011-01-20 14:24:25'),(43,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-20 16:48:34'),(44,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-20 16:48:42'),(45,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 10:55:00'),(46,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-21 13:20:01'),(47,'staff','1','system','Administrator change application global configuration','2011-01-21 13:20:20'),(48,'staff','1','system','Administrator change application global configuration','2011-01-21 13:20:51'),(49,'staff','1','system','Administrator change application global configuration','2011-01-21 13:21:21'),(50,'staff','1','system','Administrator change application global configuration','2011-01-21 13:21:48'),(51,'staff','1','system','Administrator change application global configuration','2011-01-21 13:22:05'),(52,'staff','1','system','Administrator change application global configuration','2011-01-21 13:22:21'),(53,'staff','1','system','Administrator change application global configuration','2011-01-21 13:23:19'),(54,'staff','1','system','Administrator change application global configuration','2011-01-21 13:24:21'),(55,'staff','1','bibliography','Administrator upload image file images.jpg.jpg','2011-01-21 13:45:56'),(56,'staff','1','bibliography','Administrator insert bibliographic data (Learn PHP5) with biblio_id (477)','2011-01-21 13:45:57'),(57,'staff','1','bibliography','Administrator insert item data (D101) with title (Learn PHP5)','2011-01-21 13:48:17'),(58,'staff','1','bibliography','Administrator insert item data (D102) with title (Learn PHP5)','2011-01-21 13:49:06'),(59,'staff','1','bibliography','Administrator insert item data (D103) with title (Learn PHP5)','2011-01-21 13:49:45'),(60,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 13:51:08'),(61,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 13:51:30'),(62,'staff','1','bibliography','Administrator update bibliographic data (Learn PHP5) with biblio_id ()','2011-01-21 13:54:37'),(63,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 13:59:20'),(64,'member','1','circulation','Administrator remove reservation for item B00003 for member (1)','2011-01-21 13:59:44'),(65,'member','1','circulation','Administrator reserve item D101 for member (1)','2011-01-21 14:00:12'),(66,'member','1','Login','Login success for member 1 from address 192.168.1.10','2011-01-21 14:03:08'),(67,'staff','1','system','Administrator update user data (Administrator) with username (admin)','2011-01-21 14:11:43'),(68,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 15:21:19'),(69,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-21 15:21:52'),(70,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 15:24:40'),(71,'staff','1','system','Administrator Log Out from application from address 192.168.1.10','2011-01-21 15:30:30'),(72,'member','','Login','Log Out from address 192.168.1.10','2011-01-21 15:31:34'),(73,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-21 15:32:08'),(74,'staff','1','system','Administrator Log Out from application from address 192.168.1.10','2011-01-21 15:38:46'),(75,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-21 15:40:13'),(76,'staff','1','bibliography','Administrator DELETE bibliographic data (Linux In a Nutshell) with biblio_id (2)','2011-01-21 16:17:01'),(77,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:38:37'),(78,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:38:59'),(79,'member','','circulation','Administrator start transaction with member ()','2011-01-21 16:39:29'),(80,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:39:40'),(81,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:43:17'),(82,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:43:38'),(83,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:44:06'),(84,'member','1','circulation','Administrator start transaction with member (1)','2011-01-21 16:44:32'),(85,'member','1','circulation','Administrator extend loan for item D103 for member (1)','2011-01-21 16:48:35'),(86,'member','1','circulation','Administrator return item D103 for member (1)','2011-01-21 16:48:56'),(87,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-21 16:50:32'),(88,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-21 16:52:23'),(89,'staff','1','serial_control','Administrator add new subcription(1) Period 1','2011-01-21 17:15:03'),(90,'staff','1','system','Administrator Log Out from application from address 192.168.1.10','2011-01-21 17:29:20'),(91,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-21 17:38:42'),(92,'staff','1','system','Administrator change application global configuration','2011-01-21 17:47:59'),(93,'staff','1','system','Administrator change application global configuration','2011-01-21 17:48:12'),(94,'staff','1','system','Administrator change application global configuration','2011-01-21 17:48:27'),(95,'staff','1','system','Administrator change application global configuration','2011-01-21 17:48:42'),(96,'staff','1','system','Administrator change application global configuration','2011-01-21 18:03:00'),(97,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 12:16:32'),(98,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 12:20:27'),(99,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 12:22:39'),(100,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 12:25:59'),(101,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 12:27:28'),(102,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 12:27:33'),(103,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 12:27:42'),(104,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 12:27:57'),(105,'staff','1','Login','Login FAILED for user 1 from address 127.0.0.1','2011-01-22 12:28:10'),(106,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:33:57'),(107,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:34:11'),(108,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:34:23'),(109,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:34:25'),(110,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:36:13'),(111,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:36:14'),(112,'member','s','Login','Login FAILED for member s from address 127.0.0.1','2011-01-22 13:49:29'),(113,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:49:34'),(114,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:51:34'),(115,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 13:51:41'),(116,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 13:51:49'),(117,'member','3','Login','Login success for member 3 from address 127.0.0.1','2011-01-22 13:52:15'),(118,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:52:22'),(119,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:52:36'),(120,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:52:54'),(121,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:52:59'),(122,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:54:06'),(123,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:54:13'),(124,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:54:17'),(125,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:54:26'),(126,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:54:49'),(127,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:54:56'),(128,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:56:22'),(129,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:57:07'),(130,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:57:13'),(131,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:57:19'),(132,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:57:28'),(133,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:57:53'),(134,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:58:17'),(135,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:58:22'),(136,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:59:10'),(137,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 13:59:16'),(138,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 13:59:59'),(139,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:00:06'),(140,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:00:28'),(141,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:00:33'),(142,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:03:11'),(143,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:16:00'),(144,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:17:03'),(145,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:17:13'),(146,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:19:03'),(147,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:19:12'),(148,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:19:47'),(149,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:19:52'),(150,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:20:13'),(151,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:20:20'),(152,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:20:27'),(153,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:22:20'),(154,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 14:23:00'),(155,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 14:23:06'),(156,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:18:29'),(157,'member','`1','Login','Login FAILED for member `1 from address 127.0.0.1','2011-01-22 15:19:21'),(158,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:19:54'),(159,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:20:06'),(160,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:20:11'),(161,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:20:27'),(162,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:20:40'),(163,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:22:59'),(164,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:23:08'),(165,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:23:47'),(166,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:23:59'),(167,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:25:16'),(168,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:25:21'),(169,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:25:36'),(170,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:25:48'),(171,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:26:04'),(172,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:26:09'),(173,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:26:44'),(174,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:26:49'),(175,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:26:59'),(176,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:27:05'),(177,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:27:48'),(178,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 15:27:52'),(179,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:28:08'),(180,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:28:11'),(181,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 15:28:18'),(182,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 15:28:35'),(183,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:33:28'),(184,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:33:50'),(185,'staff','1','Login','Login FAILED for user 1 from address 127.0.0.1','2011-01-22 15:43:28'),(186,'staff','1','Login','Login FAILED for user 1 from address 127.0.0.1','2011-01-22 15:43:42'),(187,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 15:43:53'),(188,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 15:44:10'),(189,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 15:44:12'),(190,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 15:44:28'),(191,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 15:44:47'),(192,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 15:44:49'),(193,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 15:46:16'),(194,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 15:46:18'),(195,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 15:47:52'),(196,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 15:47:53'),(197,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 15:49:34'),(198,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 15:49:36'),(199,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 15:57:40'),(200,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 15:58:37'),(201,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 15:59:12'),(202,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 15:59:20'),(203,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:06:04'),(204,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:06:14'),(205,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:06:18'),(206,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:06:53'),(207,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:09:37'),(208,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:11:04'),(209,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:11:19'),(210,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:11:34'),(211,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:13:31'),(212,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:13:36'),(213,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:14:11'),(214,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:14:19'),(215,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:14:47'),(216,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 16:15:23'),(217,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 16:15:43'),(218,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:15:52'),(219,'member','2','Login','Login FAILED for member 2 from address 127.0.0.1','2011-01-22 16:16:16'),(220,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:16:35'),(221,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:17:37'),(222,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:17:47'),(223,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 16:17:56'),(224,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 16:18:01'),(225,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 16:18:26'),(226,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 16:18:28'),(227,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 16:18:35'),(228,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 16:20:34'),(229,'staff','','system','Log Out from application from address 127.0.0.1','2011-01-22 16:20:46'),(230,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-22 16:23:10'),(231,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 16:23:18'),(232,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 16:23:20'),(233,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:23:30'),(234,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:29:48'),(235,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:34:35'),(236,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:35:03'),(237,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:35:43'),(238,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 16:36:35'),(239,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 16:36:38'),(240,'staff','1','Login','Login FAILED for user 1 from address 127.0.0.1','2011-01-22 16:36:59'),(241,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:37:20'),(242,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:37:27'),(243,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:37:58'),(244,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:38:33'),(245,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:41:48'),(246,'staff','1','Login','Login FAILED for user 1 from address 127.0.0.1','2011-01-22 16:42:12'),(247,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 16:42:23'),(248,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 16:42:39'),(249,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 16:42:44'),(250,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 16:43:41'),(251,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-22 16:46:00'),(252,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 16:59:58'),(253,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 17:00:24'),(254,'member','1','Login','Login FAILED for member 1 from address 127.0.0.1','2011-01-22 17:00:31'),(255,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 17:00:41'),(256,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 17:02:29'),(257,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-22 17:02:38'),(258,'member','','Login','Log Out from address 127.0.0.1','2011-01-22 17:04:29'),(259,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 17:29:26'),(260,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 17:29:29'),(261,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 17:29:36'),(262,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 17:33:27'),(263,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 18:15:57'),(264,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-22 18:16:09'),(265,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-22 18:16:29'),(266,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-25 10:32:53'),(267,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-25 10:33:03'),(268,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-25 10:37:50'),(269,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-25 10:37:59'),(270,'member','','circulation','Administrator start transaction with member ()','2011-01-25 10:52:35'),(271,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-25 11:41:19'),(272,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-25 11:42:46'),(273,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-25 11:42:56'),(274,'member','5','circulation','Administrator start transaction with member (5)','2011-01-25 12:25:14'),(275,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-25 12:57:59'),(276,'staff','1','system','Administrator update module data (book) with path (bibliography)','2011-01-25 16:08:14'),(277,'staff','1','bibliography','Administrator insert item data (102) with title (Learn PHP5)','2011-01-25 18:10:43'),(278,'staff','1','bibliography','Administrator insert item data (102) with title (Learn PHP5)','2011-01-25 18:15:56'),(279,'staff','1','bibliography','Administrator insert item data (102) with title (Learn PHP5)','2011-01-25 18:17:49'),(280,'staff','1','bibliography','Administrator insert item data (555) with title (Learn PHP5)','2011-01-25 18:23:32'),(281,'staff','1','bibliography','Administrator insert item data (301) with title (Learn PHP5)','2011-01-25 18:24:31'),(282,'staff','1','bibliography','Administrator insert item data (dsds) with title (Learn PHP5)','2011-01-25 18:28:10'),(283,'staff','admin','Login','Login success for user admin from address ::1','2011-01-25 18:55:07'),(284,'member','','circulation','Administrator start transaction with member ()','2011-01-25 18:56:32'),(285,'member','1','circulation','Administrator start transaction with member (1)','2011-01-25 18:56:35'),(286,'staff','1','system','Administrator Log Out from application from address ::1','2011-01-25 18:56:50'),(287,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-26 10:52:49'),(288,'staff','1','system','update content data (Welcome To Admin Page) with contentname ()','2011-01-26 10:54:10'),(289,'staff','1','bibliography','Administrator insert item data (dsdsds) with title (Learn PHP5)','2011-01-26 11:07:21'),(290,'staff','1','bibliography','Administrator insert item data (swdsds) with title (Learn PHP5)','2011-01-26 11:07:40'),(291,'staff','1','bibliography','Administrator insert item data (dfdf) with title (Learn PHP5)','2011-01-26 11:08:34'),(292,'staff','1','bibliography','Administrator insert item data (103dd) with title (Learn PHP5)','2011-01-26 11:09:26'),(293,'staff','1','bibliography','Administrator insert item data (1111111111) with title (Learn PHP5)','2011-01-26 11:12:16'),(294,'staff','1','bibliography','Administrator insert item data (dsds) with title (Learn PHP5)','2011-01-26 11:13:08'),(295,'staff','1','bibliography','Administrator insert item data (dfdf) with title (Learn PHP5)','2011-01-26 11:15:21'),(296,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-26 11:15:59'),(297,'staff','1','bibliography','Administrator insert item data (sdsdsd) with title (Learn PHP5)','2011-01-26 11:16:28'),(298,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-26 11:24:16'),(299,'staff','1','bibliography','Administrator insert item data (sdsdsdsd) with title (Learn PHP5)','2011-01-26 11:25:21'),(300,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:28:11'),(301,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:28:55'),(302,'staff','1','bibliography','Administrator insert item data (gfhjgjgh) with title (Learn PHP5)','2011-01-26 11:31:46'),(303,'staff','1','bibliography','Administrator insert item data (sdfsdfdsfs) with title (Learn PHP5)','2011-01-26 11:34:39'),(304,'staff','1','bibliography','Administrator insert item data (fff) with title (Learn PHP5)','2011-01-26 11:38:54'),(305,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:46:38'),(306,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:46:38'),(307,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:46:38'),(308,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:46:38'),(309,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:46:38'),(310,'staff','1','bibliography','Administrator insert item data (iresh) with title (Learn PHP5)','2011-01-26 11:46:38'),(311,'staff','1','bibliography','Administrator insert item data (gggg) with title (Learn PHP5)','2011-01-26 11:47:50'),(312,'staff','1','bibliography','Administrator insert item data (gggg) with title (Learn PHP5)','2011-01-26 11:47:50'),(313,'staff','1','bibliography','Administrator insert item data (gggg) with title (Learn PHP5)','2011-01-26 11:47:50'),(314,'staff','1','bibliography','Administrator insert item data (gggg) with title (Learn PHP5)','2011-01-26 11:47:50'),(315,'staff','1','bibliography','Administrator insert item data (gggg) with title (Learn PHP5)','2011-01-26 11:47:50'),(316,'staff','1','bibliography','Administrator insert item data (gggg) with title (Learn PHP5)','2011-01-26 11:47:50'),(317,'staff','1','bibliography','Administrator insert item data () with title (Learn PHP5)','2011-01-26 12:18:24'),(318,'staff','1','bibliography','Administrator insert item data (107) with title (Learn PHP5)','2011-01-26 12:21:45'),(319,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:24:17'),(320,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:26:07'),(321,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:26:51'),(322,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:27:20'),(323,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:28:52'),(324,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:30:08'),(325,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:32:21'),(326,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:33:23'),(327,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:34:30'),(328,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:35:04'),(329,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:35:52'),(330,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:36:56'),(331,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:37:38'),(332,'staff','1','bibliography','Administrator insert item data (103) with title (Learn PHP5)','2011-01-26 12:38:11'),(333,'staff','1','bibliography','Administrator insert item data (107) with title (Learn PHP5)','2011-01-26 12:39:35'),(334,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 12:42:54'),(335,'staff','1','bibliography','Administrator insert item data (i16) with title (Learn PHP5)','2011-01-26 12:44:02'),(336,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:07:20'),(337,'member','','circulation','Administrator start transaction with member ()','2011-01-26 13:07:28'),(338,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:07:31'),(339,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:08:03'),(340,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:08:09'),(341,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-26 13:20:54'),(342,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:20:59'),(343,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-26 13:25:24'),(344,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:25:29'),(345,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-26 13:27:15'),(346,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:27:19'),(347,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:28:24'),(348,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:32:55'),(349,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:33:47'),(350,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:33:53'),(351,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:33:56'),(352,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:34:06'),(353,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:34:07'),(354,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:34:50'),(355,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:34:51'),(356,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:35:04'),(357,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:35:05'),(358,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:35:37'),(359,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:35:39'),(360,'member','','circulation','Administrator start transaction with member ()','2011-01-26 13:37:03'),(361,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:37:06'),(362,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:37:07'),(363,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:37:56'),(364,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:37:57'),(365,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:38:47'),(366,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:38:49'),(367,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:39:56'),(368,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:41:44'),(369,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:43:02'),(370,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:43:03'),(371,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:43:10'),(372,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:43:11'),(373,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:44:21'),(374,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:47:29'),(375,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:48:56'),(376,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:49:04'),(377,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:49:30'),(378,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:49:35'),(379,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:49:49'),(380,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:49:52'),(381,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:49:58'),(382,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:50:05'),(383,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:51:11'),(384,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:51:54'),(385,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:53:19'),(386,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:54:35'),(387,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 13:54:40'),(388,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 13:56:43'),(389,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 14:01:02'),(390,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 14:03:29'),(391,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 14:03:39'),(392,'member','1','circulation','Administrator return item D101 for member (1)','2011-01-26 14:03:45'),(393,'member','1','circulation','Administrator return item D102 for member (1)','2011-01-26 14:03:47'),(394,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 14:05:35'),(395,'member','2','circulation','Administrator start transaction with member (2)','2011-01-26 14:05:44'),(396,'member','2','circulation','Administrator return item b00005 for member (2)','2011-01-26 14:05:49'),(397,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-26 14:10:18'),(398,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 14:10:51'),(399,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 14:10:56'),(400,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 14:21:25'),(401,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:31:18'),(402,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:38:05'),(403,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:38:17'),(404,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:38:49'),(405,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:38:58'),(406,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:39:19'),(407,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:39:24'),(408,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:39:33'),(409,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:41:30'),(410,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:41:45'),(411,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:44:42'),(412,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:44:53'),(413,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:48:03'),(414,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:48:51'),(415,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:49:10'),(416,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:51:46'),(417,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:54:26'),(418,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:54:41'),(419,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:54:42'),(420,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:54:55'),(421,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:56:14'),(422,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:56:25'),(423,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:56:28'),(424,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:56:33'),(425,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:56:35'),(426,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 15:58:16'),(427,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 15:58:22'),(428,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:00:41'),(429,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:00:43'),(430,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:01:08'),(431,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:01:09'),(432,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:01:37'),(433,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:01:40'),(434,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:01:45'),(435,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:01:46'),(436,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:07:12'),(437,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:07:26'),(438,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:07:31'),(439,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:07:38'),(440,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:07:42'),(441,'member','1','circulation','Administrator return item b00002 for member (1)','2011-01-26 16:07:46'),(442,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 16:50:28'),(443,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 16:50:31'),(444,'member','1','circulation','Administrator return item b00002 for member (1)','2011-01-26 16:51:02'),(445,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 17:31:03'),(446,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 17:31:06'),(447,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-26 17:34:16'),(448,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 17:34:26'),(449,'staff','1','system','Administrator change application global configuration','2011-01-26 18:12:11'),(450,'staff','1','system','Administrator change application global configuration','2011-01-26 18:12:20'),(451,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 18:23:15'),(452,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 18:23:18'),(453,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 18:44:27'),(454,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 18:55:03'),(455,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-26 18:55:07'),(456,'member','1','circulation','Administrator start transaction with member (1)','2011-01-26 18:55:14'),(457,'staff','1','bibliography','Administrator insert item data (3) with title (Learn PHP5)','2011-01-26 18:55:56'),(458,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-26 18:57:05'),(459,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 10:54:52'),(460,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 10:55:00'),(461,'member','1','circulation','Administrator return item b00007 for member (1)','2011-01-27 11:39:49'),(462,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-27 11:43:26'),(463,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 11:43:29'),(464,'member','1','circulation','Administrator return item b00007 for member (1)','2011-01-27 11:52:59'),(465,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-27 11:59:32'),(466,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 11:59:41'),(467,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-27 13:28:55'),(468,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 13:29:47'),(469,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 13:29:56'),(470,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 13:47:42'),(471,'member','ff','Login','Login FAILED for member ff from address 127.0.0.1','2011-01-27 13:48:28'),(472,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 13:52:43'),(473,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 13:53:09'),(474,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 13:53:22'),(475,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:20:05'),(476,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 15:20:12'),(477,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:34:22'),(478,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:34:38'),(479,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:34:50'),(480,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:35:01'),(481,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:35:15'),(482,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:35:31'),(483,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:35:48'),(484,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:36:00'),(485,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:37:00'),(486,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:37:21'),(487,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:38:20'),(488,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:38:35'),(489,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:38:42'),(490,'staff','kl;l;l;lk','Login','Login FAILED for user kl;l;l;lk from address 127.0.0.1','2011-01-27 15:39:21'),(491,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:39:29'),(492,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-27 15:39:33'),(493,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:39:38'),(494,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:39:48'),(495,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-27 15:39:59'),(496,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-27 15:40:07'),(497,'member','','Login','Log Out from address 127.0.0.1','2011-01-27 15:40:24'),(498,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:40:40'),(499,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-27 15:46:45'),(500,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-27 15:47:02'),(501,'member','','Login','Log Out from address 127.0.0.1','2011-01-27 15:47:08'),(502,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-27 15:47:48'),(503,'member','','Login','Log Out from address 127.0.0.1','2011-01-27 15:49:24'),(504,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-27 15:49:29'),(505,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-27 15:49:39'),(506,'member','','Login','Log Out from address 127.0.0.1','2011-01-27 15:49:44'),(507,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:49:51'),(508,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 15:50:06'),(509,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 15:51:46'),(510,'staff','j;lkj','Login','Login FAILED for user j;lkj from address 127.0.0.1','2011-01-27 16:20:17'),(511,'staff','ghjg','Login','Login FAILED for user ghjg from address 127.0.0.1','2011-01-27 16:22:38'),(512,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 16:22:51'),(513,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 16:23:00'),(514,'staff','adminh','Login','Login FAILED for user adminh from address 127.0.0.1','2011-01-27 16:26:01'),(515,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 16:26:16'),(516,'staff','sdsd','Login','Login FAILED for user sdsd from address 127.0.0.1','2011-01-27 16:26:20'),(517,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 16:26:27'),(518,'staff','j','Login','Login FAILED for user j from address 127.0.0.1','2011-01-27 16:26:41'),(519,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 16:28:03'),(520,'staff','dfdf','Login','Login FAILED for user dfdf from address 127.0.0.1','2011-01-27 16:28:11'),(521,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 16:30:57'),(522,'staff','sdsd','Login','Login FAILED for user sdsd from address 127.0.0.1','2011-01-27 16:31:03'),(523,'staff','sdsd','Login','Login FAILED for user sdsd from address 127.0.0.1','2011-01-27 16:31:19'),(524,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 16:31:28'),(525,'staff','admin','Login','Login FAILED for user admin from address 127.0.0.1','2011-01-27 16:31:36'),(526,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-27 16:31:50'),(527,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 16:31:56'),(528,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-27 17:00:43'),(529,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 17:00:46'),(530,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-27 17:01:03'),(531,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 17:01:07'),(532,'member','1','circulation','Administrator remove reservation for item B00004 for member (1)','2011-01-27 17:32:14'),(533,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-27 18:30:25'),(534,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 18:30:27'),(535,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-27 18:31:42'),(536,'member','5','circulation','Administrator start transaction with member (5)','2011-01-27 18:32:34'),(537,'member','5','circulation','Administrator finish circulation transaction with member (5)','2011-01-27 18:32:38'),(538,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 18:32:40'),(539,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-27 18:42:30'),(540,'member','1','circulation','Administrator start transaction with member (1)','2011-01-27 18:42:32'),(541,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-28 11:01:10'),(542,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 11:01:17'),(543,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 11:09:59'),(544,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 11:10:02'),(545,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 11:10:07'),(546,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 11:10:13'),(547,'member','1','circulation','Administrator return item b00008 for member (1)','2011-01-28 11:24:30'),(548,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 11:37:03'),(549,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 11:37:14'),(550,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 11:48:02'),(551,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 11:48:47'),(552,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 11:56:14'),(553,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 11:56:17'),(554,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 12:04:21'),(555,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 12:04:23'),(556,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 12:04:56'),(557,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 12:04:58'),(558,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 12:09:55'),(559,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 12:09:57'),(560,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 12:35:52'),(561,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 12:36:00'),(562,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 12:37:47'),(563,'member','1','circulation','Administrator remove reservation for item D101 for member (1)','2011-01-28 12:37:55'),(564,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 12:43:29'),(565,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 13:09:11'),(566,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 13:09:21'),(567,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 13:28:46'),(568,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 13:28:49'),(569,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 13:40:28'),(570,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 13:40:36'),(571,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 13:44:41'),(572,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 13:44:44'),(573,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 13:45:15'),(574,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 13:45:24'),(575,'member','1','circulation','Administrator extend loan for item b00007 for member (1)','2011-01-28 13:57:12'),(576,'member','1','circulation','Administrator extend loan for item b00002 for member (1)','2011-01-28 13:57:30'),(577,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 15:35:56'),(578,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 15:35:59'),(579,'member','1','circulation','Administrator extend loan for item 104 for member (1)','2011-01-28 15:38:01'),(580,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 15:41:49'),(581,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 15:41:51'),(582,'member','1','circulation','Administrator return item 104 for member (1)','2011-01-28 15:50:00'),(583,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-28 15:56:19'),(584,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-28 15:56:28'),(585,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 15:56:35'),(586,'staff','admin','Login','Login success for user admin from address 192.168.1.10','2011-01-28 15:59:13'),(587,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 15:59:21'),(588,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 16:09:58'),(589,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 16:10:05'),(590,'member','1','circulation','Administrator return item 106 for member (1)','2011-01-28 16:10:52'),(591,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 16:26:46'),(592,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 16:26:49'),(593,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 17:27:39'),(594,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 17:28:19'),(595,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 17:28:21'),(596,'member','1','circulation','Administrator remove reservation for item b00002 for member (1)','2011-01-28 17:41:04'),(597,'member','1','circulation','Administrator reserve item B00002 for member (1)','2011-01-28 17:41:50'),(598,'member','1','circulation','Administrator remove reservation for item B00002 for member (1)','2011-01-28 17:42:20'),(599,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 17:49:14'),(600,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 17:49:22'),(601,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 17:49:49'),(602,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 17:51:15'),(603,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 17:51:22'),(604,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 17:51:47'),(605,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 17:52:48'),(606,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 17:52:54'),(607,'member','1','circulation','Administrator reserve item B00002 for member (1)','2011-01-28 17:53:15'),(608,'member','1','circulation','Administrator remove reservation for item B00002 for member (1)','2011-01-28 17:53:21'),(609,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 17:58:44'),(610,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 17:58:47'),(611,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 17:58:51'),(612,'member','2','circulation','Administrator remove reservation for item b00001 for member (2)','2011-01-28 17:59:53'),(613,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 18:07:05'),(614,'member','2','circulation','Administrator remove reservation for item b00001 for member (2)','2011-01-28 18:07:55'),(615,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 18:07:59'),(616,'member','2','circulation','Administrator remove reservation for item b00001 for member (2)','2011-01-28 18:08:07'),(617,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:08:43'),(618,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:08:45'),(619,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 18:08:49'),(620,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 18:08:53'),(621,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:08:59'),(622,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:09:02'),(623,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 18:09:08'),(624,'member','2','circulation','Administrator remove reservation for item b00001 for member (2)','2011-01-28 18:09:47'),(625,'member','2','circulation','Administrator reserve item B00002 for member (2)','2011-01-28 18:12:26'),(626,'member','2','circulation','Administrator remove reservation for item B00002 for member (2)','2011-01-28 18:13:41'),(627,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:13:43'),(628,'member','','circulation','Administrator start transaction with member ()','2011-01-28 18:13:46'),(629,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:13:50'),(630,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 18:13:53'),(631,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 18:13:57'),(632,'member','1','circulation','Administrator reserve item B00002 for member (1)','2011-01-28 18:14:03'),(633,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:14:07'),(634,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:14:10'),(635,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 18:14:14'),(636,'member','2','circulation','Administrator remove reservation for item b00001 for member (2)','2011-01-28 18:14:21'),(637,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:14:38'),(638,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:14:41'),(639,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 18:14:44'),(640,'member','1','circulation','Administrator remove reservation for item B00002 for member (1)','2011-01-28 18:14:48'),(641,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 18:14:52'),(642,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:14:55'),(643,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:14:57'),(644,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 18:15:24'),(645,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:15:39'),(646,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:17:26'),(647,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:17:47'),(648,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:17:50'),(649,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:17:51'),(650,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:17:52'),(651,'member','2','circulation','Administrator remove reservation for item b00001 for member (2)','2011-01-28 18:17:58'),(652,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:18:01'),(653,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:18:02'),(654,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-28 18:18:27'),(655,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-28 18:18:39'),(656,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:20:00'),(657,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:20:03'),(658,'member','','circulation','Administrator finish circulation transaction with member ()','2011-01-28 18:25:37'),(659,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:25:39'),(660,'member','','circulation','Administrator finish circulation transaction with member ()','2011-01-28 18:31:50'),(661,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:31:53'),(662,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-28 18:47:07'),(663,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:47:25'),(664,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:47:27'),(665,'member','2','circulation','Administrator reserve item b00001 for member (2)','2011-01-28 18:47:30'),(666,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:47:33'),(667,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:47:35'),(668,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:52:10'),(669,'member','2','circulation','Administrator start transaction with member (2)','2011-01-28 18:52:15'),(670,'member','2','circulation','Administrator finish circulation transaction with member (2)','2011-01-28 18:54:26'),(671,'member','1','circulation','Administrator start transaction with member (1)','2011-01-28 18:55:13'),(672,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-28 18:55:20'),(673,'member','5','circulation','Administrator start transaction with member (5)','2011-01-28 18:55:22'),(674,'member','5','circulation','Administrator finish circulation transaction with member (5)','2011-01-28 18:58:18'),(675,'member','5','circulation','Administrator start transaction with member (5)','2011-01-28 18:58:21'),(676,'member','5','circulation','Administrator extend loan for item 106 for member (5)','2011-01-28 18:58:29'),(677,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-28 19:01:15'),(678,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 10:57:03'),(679,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 10:57:07'),(680,'member','1','circulation','Administrator extend loan for item b00004 for member (1)','2011-01-29 11:01:19'),(681,'member','1','circulation','Administrator extend loan for item b00002 for member (1)','2011-01-29 11:01:30'),(682,'member','1','circulation','Administrator extend loan for item b00007 for member (1)','2011-01-29 11:01:42'),(683,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-29 11:19:38'),(684,'member','5','circulation','Administrator start transaction with member (5)','2011-01-29 11:19:40'),(685,'member','5','circulation','Administrator extend loan for item 106 for member (5)','2011-01-29 11:19:52'),(686,'member','5','circulation','Administrator finish circulation transaction with member (5)','2011-01-29 11:19:55'),(687,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 11:19:58'),(688,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-29 11:40:44'),(689,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 11:40:46'),(690,'member','1','circulation','Administrator return item b00007 for member (1)','2011-01-29 11:41:37'),(691,'member','1','circulation','Administrator return item b00002 for member (1)','2011-01-29 11:41:40'),(692,'member','1','circulation','Administrator return item b00004 for member (1)','2011-01-29 11:41:42'),(693,'member','1','circulation','Administrator return item 102 for member (1)','2011-01-29 11:41:44'),(694,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-29 11:41:58'),(695,'member','','circulation','Administrator finish circulation transaction with member ()','2011-01-29 11:42:21'),(696,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 11:42:23'),(697,'staff','admin','Login','Login success for user admin from address 192.168.1.7','2011-01-29 13:23:16'),(698,'staff','1','system','Administrator change application global configuration','2011-01-29 13:41:10'),(699,'staff','1','system','Administrator change application global configuration','2011-01-29 13:41:22'),(700,'staff','1','system','Administrator change application global configuration','2011-01-29 13:42:30'),(701,'staff','1','system','Administrator change application global configuration','2011-01-29 13:43:10'),(702,'staff','1','system','Administrator change application global configuration','2011-01-29 13:43:23'),(703,'staff','1','system','Administrator change application global configuration','2011-01-29 13:43:56'),(704,'staff','1','system','Administrator change application global configuration','2011-01-29 13:44:10'),(705,'staff','1','system','Administrator change application global configuration','2011-01-29 13:44:30'),(706,'staff','1','system','Administrator change application global configuration','2011-01-29 13:44:49'),(707,'staff','1','system','Administrator change application global configuration','2011-01-29 13:45:11'),(708,'staff','1','system','Administrator change application global configuration','2011-01-29 13:45:22'),(709,'staff','1','system','Administrator change application global configuration','2011-01-29 13:45:39'),(710,'staff','1','system','Administrator change application global configuration','2011-01-29 13:46:01'),(711,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-29 13:47:29'),(712,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 13:47:35'),(713,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:18:13'),(714,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:18:47'),(715,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:18:54'),(716,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:20:40'),(717,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:20:47'),(718,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:20:52'),(719,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:25:01'),(720,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:25:12'),(721,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:25:17'),(722,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-29 15:29:25'),(723,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:29:26'),(724,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:29:34'),(725,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:29:38'),(726,'member','1','circulation','Administrator extend loan for item b00007 for member (1)','2011-01-29 15:29:45'),(727,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:32:32'),(728,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:32:39'),(729,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:32:45'),(730,'member','1','circulation','Administrator return item b00007 for member (1)','2011-01-29 15:32:48'),(731,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:34:10'),(732,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:34:20'),(733,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:34:37'),(734,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:34:43'),(735,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:35:51'),(736,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:35:59'),(737,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:36:02'),(738,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:39:18'),(739,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:39:26'),(740,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:39:30'),(741,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:39:45'),(742,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:39:52'),(743,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:39:56'),(744,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:42:12'),(745,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-29 15:42:17'),(746,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:42:30'),(747,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:42:34'),(748,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:44:51'),(749,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:44:58'),(750,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:45:03'),(751,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:46:18'),(752,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:46:26'),(753,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:46:30'),(754,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:47:07'),(755,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:47:14'),(756,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:47:19'),(757,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:48:27'),(758,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:48:40'),(759,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 15:49:38'),(760,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 15:50:01'),(761,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 15:50:06'),(762,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-29 16:05:26'),(763,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 16:05:29'),(764,'member','1','circulation','Administrator return item b00008 for member (1)','2011-01-29 16:10:29'),(765,'member','1','circulation','Administrator return item b00001 for member (1)','2011-01-29 16:10:31'),(766,'member','1','circulation','Administrator return item b00007 for member (1)','2011-01-29 16:10:34'),(767,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 16:42:04'),(768,'member','admin','Login','Login FAILED for member admin from address 127.0.0.1','2011-01-29 16:42:09'),(769,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 16:42:17'),(770,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 16:42:22'),(771,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 16:46:29'),(772,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 16:46:34'),(773,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 16:47:25'),(774,'member','','circulation','Administrator start transaction with member ()','2011-01-29 16:47:28'),(775,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 16:47:33'),(776,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 16:50:03'),(777,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 16:50:08'),(778,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 17:11:33'),(779,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 17:11:38'),(780,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 17:12:45'),(781,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 17:12:50'),(782,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 17:15:09'),(783,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 17:15:14'),(784,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 17:18:01'),(785,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 17:18:07'),(786,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 17:18:14'),(787,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 17:19:12'),(788,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 17:19:25'),(789,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 17:19:28'),(790,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-29 17:48:04'),(791,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 17:48:11'),(792,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 17:48:15'),(793,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:07:42'),(794,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 18:07:46'),(795,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:09:09'),(796,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 18:09:14'),(797,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:13:19'),(798,'member','1','circulation','Administrator start transaction with member (1)','2011-01-29 18:13:23'),(799,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:36:06'),(800,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:36:22'),(801,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:36:51'),(802,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:42:09'),(803,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-29 18:42:29'),(804,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 10:48:10'),(805,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 10:48:16'),(806,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:04:04'),(807,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:04:11'),(808,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:04:17'),(809,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:24:37'),(810,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:24:48'),(811,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:24:52'),(812,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:27:09'),(813,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:27:16'),(814,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:27:21'),(815,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:30:36'),(816,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:30:52'),(817,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:30:55'),(818,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:31:19'),(819,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:31:26'),(820,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:31:29'),(821,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:34:12'),(822,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:34:19'),(823,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:34:41'),(824,'member','1','circulation','Administrator reserve item b00001 for member (1)','2011-01-31 11:37:15'),(825,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 11:37:27'),(826,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:37:29'),(827,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 11:37:33'),(828,'member','5','circulation','Administrator start transaction with member (5)','2011-01-31 11:37:35'),(829,'member','5','circulation','Administrator finish circulation transaction with member (5)','2011-01-31 11:37:48'),(830,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:37:50'),(831,'member','1','circulation','Administrator remove reservation for item b00001 for member (1)','2011-01-31 11:38:04'),(832,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:38:15'),(833,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:38:23'),(834,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:38:27'),(835,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:41:21'),(836,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:41:28'),(837,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:41:32'),(838,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:45:57'),(839,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:46:03'),(840,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:46:07'),(841,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:46:33'),(842,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:46:40'),(843,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:46:44'),(844,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:48:07'),(845,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:48:15'),(846,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:48:18'),(847,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:50:18'),(848,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:50:25'),(849,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:50:28'),(850,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:55:15'),(851,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:55:22'),(852,'member','','circulation','Administrator start transaction with member ()','2011-01-31 11:55:26'),(853,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:55:29'),(854,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 11:57:57'),(855,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 11:58:03'),(856,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 11:58:07'),(857,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 12:10:35'),(858,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 12:10:42'),(859,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 12:10:45'),(860,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-31 12:15:59'),(861,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 12:16:07'),(862,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 12:16:12'),(863,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 14:05:06'),(864,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 14:05:08'),(865,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 14:05:29'),(866,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 14:05:31'),(867,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 14:16:21'),(868,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 14:16:23'),(869,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 15:21:00'),(870,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 15:21:04'),(871,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 15:26:42'),(872,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 15:26:45'),(873,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 15:31:16'),(874,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 15:31:19'),(875,'member','1','circulation','Administrator return item 106 for member (1)','2011-01-31 15:32:19'),(876,'staff','1','bibliography','Administrator insert item data (k) with title (Learn PHP5)','2011-01-31 15:43:55'),(877,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-31 15:44:44'),(878,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 15:46:49'),(879,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 15:51:21'),(880,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 15:51:24'),(881,'member','1','circulation','Administrator extend loan for item 106 for member (1)','2011-01-31 15:57:34'),(882,'member','1','circulation','Administrator return item 106 for member (1)','2011-01-31 15:57:40'),(883,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 16:02:57'),(884,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 16:03:05'),(885,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 16:03:37'),(886,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 16:03:53'),(887,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 16:03:57'),(888,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 16:04:04'),(889,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 16:11:16'),(890,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 16:11:37'),(891,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-31 16:20:37'),(892,'member','1','circulation','Administrator start transaction with member (1)','2011-01-31 16:20:38');
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp`
--

DROP TABLE IF EXISTS `temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp` (
  `temp_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(30) NOT NULL,
  `member_id` int(11) NOT NULL,
  `loan_date` date NOT NULL,
  `due_date` date NOT NULL,
  PRIMARY KEY (`temp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp`
--

LOCK TABLES `temp` WRITE;
/*!40000 ALTER TABLE `temp` DISABLE KEYS */;
INSERT INTO `temp` VALUES (66,'106',1,'2011-01-31','0000-00-00');
/*!40000 ALTER TABLE `temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `realname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `passwd` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT '0000-00-00',
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `realname` (`realname`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','Administrator','21232f297a57a5a743894a0e4a801fc3','2011-01-31 15:44:44','127.0.0.1','a:1:{i:0;s:1:\"1\";}','2011-01-10','2011-01-21'),(2,'iresh','Administrator','iresh',NULL,NULL,NULL,'0000-00-00',NULL),(3,'harshit','harshit','83a75f0b31435193bafd3b9c5fd45aec',NULL,NULL,'a:1:{i:0;s:1:\"2\";}','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
INSERT INTO `user_group` VALUES (1,'Administrator','2011-01-10','2011-01-10'),(2,'Students','2011-01-10','2011-01-17');
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_count`
--

DROP TABLE IF EXISTS `visitor_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitor_count` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `institution` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `checkin_date` datetime NOT NULL,
  PRIMARY KEY (`visitor_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_count`
--

LOCK TABLES `visitor_count` WRITE;
/*!40000 ALTER TABLE `visitor_count` DISABLE KEYS */;
INSERT INTO `visitor_count` VALUES (1,'1','iresh',NULL,'2011-01-12 12:25:04'),(2,'harshit','harshit bhatt','Tatva Foundation','2011-01-12 12:25:40');
/*!40000 ALTER TABLE `visitor_count` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-31 16:00:33
