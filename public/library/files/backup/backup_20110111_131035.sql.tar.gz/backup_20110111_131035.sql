-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: senayan
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `senayan`
--

USE `senayan`;

--
-- Table structure for table `backup_log`
--

DROP TABLE IF EXISTS `backup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_log` (
  `backup_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `backup_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `backup_file` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`backup_log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_log`
--

LOCK TABLES `backup_log` WRITE;
/*!40000 ALTER TABLE `backup_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio`
--

DROP TABLE IF EXISTS `biblio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio` (
  `biblio_id` int(11) NOT NULL AUTO_INCREMENT,
  `gmd_id` int(3) DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `edition` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isbn_issn` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `publish_year` int(4) DEFAULT NULL,
  `collation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `series_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_id` char(5) COLLATE utf8_unicode_ci DEFAULT 'en',
  `source` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish_place_id` int(11) DEFAULT NULL,
  `classification` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_att` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opac_hide` smallint(1) DEFAULT '0',
  `promoted` smallint(1) DEFAULT '0',
  `labels` text COLLATE utf8_unicode_ci,
  `frequency_id` int(11) NOT NULL DEFAULT '0',
  `spec_detail_info` text COLLATE utf8_unicode_ci,
  `input_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`biblio_id`),
  KEY `references_idx` (`gmd_id`,`publisher_id`,`language_id`,`publish_place_id`),
  KEY `classification` (`classification`),
  KEY `biblio_flag_idx` (`opac_hide`,`promoted`),
  FULLTEXT KEY `title_ft_idx` (`title`,`series_title`),
  FULLTEXT KEY `notes_ft_idx` (`notes`),
  FULLTEXT KEY `labels` (`labels`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio`
--

LOCK TABLES `biblio` WRITE;
/*!40000 ALTER TABLE `biblio` DISABLE KEYS */;
INSERT INTO `biblio` VALUES (1,1,'science','1','',NULL,0,'','','','en',NULL,NULL,'','',NULL,NULL,0,1,NULL,0,'fgdf','2011-01-10 15:18:57','2011-01-10 15:40:37'),(2,1,'Communication Skill','5th Edition','100100010101',1,2008,'','','1001','en',NULL,1,'','Communication Skill',NULL,NULL,0,1,NULL,0,'Communication Skill','2011-01-10 16:24:44','2011-01-10 16:41:45'),(3,1,'biology','1st','',NULL,0,'','','','en',NULL,NULL,'','',NULL,NULL,0,0,NULL,0,'dcvfdsf','2011-01-11 12:25:45','2011-01-11 12:27:03');
/*!40000 ALTER TABLE `biblio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_attachment`
--

DROP TABLE IF EXISTS `biblio_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_attachment` (
  `biblio_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  `access_type` enum('public','private') COLLATE utf8_unicode_ci NOT NULL,
  `access_limit` text COLLATE utf8_unicode_ci,
  KEY `biblio_id` (`biblio_id`),
  KEY `file_id` (`file_id`),
  KEY `biblio_id_2` (`biblio_id`,`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_attachment`
--

LOCK TABLES `biblio_attachment` WRITE;
/*!40000 ALTER TABLE `biblio_attachment` DISABLE KEYS */;
INSERT INTO `biblio_attachment` VALUES (1,0,'public','a:1:{i:0;s:1:\"1\";}');
/*!40000 ALTER TABLE `biblio_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_author`
--

DROP TABLE IF EXISTS `biblio_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_author` (
  `biblio_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biblio_id`,`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_author`
--

LOCK TABLES `biblio_author` WRITE;
/*!40000 ALTER TABLE `biblio_author` DISABLE KEYS */;
INSERT INTO `biblio_author` VALUES (1,1,2),(2,2,1),(3,1,1);
/*!40000 ALTER TABLE `biblio_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_custom`
--

DROP TABLE IF EXISTS `biblio_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_custom` (
  `biblio_id` int(11) NOT NULL,
  PRIMARY KEY (`biblio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='one to one relation with real biblio table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_custom`
--

LOCK TABLES `biblio_custom` WRITE;
/*!40000 ALTER TABLE `biblio_custom` DISABLE KEYS */;
/*!40000 ALTER TABLE `biblio_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biblio_topic`
--

DROP TABLE IF EXISTS `biblio_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `biblio_topic` (
  `biblio_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `level` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biblio_id`,`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biblio_topic`
--

LOCK TABLES `biblio_topic` WRITE;
/*!40000 ALTER TABLE `biblio_topic` DISABLE KEYS */;
INSERT INTO `biblio_topic` VALUES (2,1,1);
/*!40000 ALTER TABLE `biblio_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `content_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `content_path` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`content_id`),
  KEY `content_path` (`content_path`),
  FULLTEXT KEY `content_title` (`content_title`),
  FULLTEXT KEY `content_desc` (`content_desc`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,'Library Information','<h3>Contact Information</h3>\r\n<p><strong>Address :</strong> <br /> Jenderal Sudirman Road, Senayan, Jakarta, Indonesia - Postal Code : 10270 <br /> <strong>Phone Number :</strong> <br /> (021) 5711144 <br /> <strong>Fax Number :</strong> <br /> (021) 5711144</p>\r\n<h3>Opening Hours</h3>\r\n<p><strong>Monday - Friday :</strong> <br /> Open : 08.00 AM<br /> Break : 12.00 - 13.00 PM<br /> Close : 20.00 PM <br /> <strong>Saturday  :</strong> <br /> Open : 08.00 AM<br /> Break : 12.00 - 13.00 PM<br /> Close : 17.00 PM</p>\r\n<h3>Collections</h3>\r\n<p>We have many types of collections in our library, range from Fictions to Sciences Material, from printed material to digital collections such CD-ROM, CD, VCD and DVD. We also collect daily serials publications such as newspaper and also monthly serials such as magazines.</p>\r\n<h3>Library Membership</h3>\r\n<p>To be able to loan our library collections, you must first become library member. There is terms and conditions that you must obey.</p>','libinfo','2009-09-13 19:48:16','2009-09-13 19:48:16'),(2,'Help On Usage','<h3>Searching</h3>\r\n<p>There is 2 method available on searching library catalog. The first one is <strong>SIMPLE SEARCH</strong>, which is the simplest method on searching catalog, you just enter any keyword, either it contained in document titles, authors name or subjects. You can supply more than one keywords in Simple Search method and it will expanding your search results.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>ADVANCED SEARCH</strong>, lets you define keywords in more specific fields. If you want your keywords only contained in title field, then type your keyword in Title field and the system will scope it search only on <strong>Title</strong> field, not in other fields. Location field lets you narrowing search results by specific location, so only collection that exists in selected location get fetched by system.</p>','help','2009-09-13 19:48:16','2009-09-13 19:48:16'),(3,'Welcome To Admin Page','<table style=\"width: 100%;\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n<tbody>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon biblioIcon\" href=\"?mod=bibliography\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Bibliography</div>\r\nThe Bibliography module lets you manage your library bibliographical data. It also include collection items management     to manage a copies of your library collection so it can be used in library circulation.</td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon circulationIcon\" href=\"?mod=circulation\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Circulation</div>\r\nThe Circulation module is used for doing library circulation transaction such as collection loans and return. In this module you can also create loan rules that will be used in loan transaction proccess.</td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon memberIcon\" href=\"?mod=membership\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Membership</div>\r\nThe Membership module lets you manage library members such adding, updating and also removing. You can also manage membership type in this module.<br /><br /></td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon stockTakeIcon\" href=\"?mod=stock_take\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Stock Take</div>\r\nThe Stock Take module is the easy way to do Stock Opname for your library collections. Follow several steps that ease your pain in Stock Opname proccess. <br /><br /></td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon masterFileIcon\" href=\"?mod=master_file\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Master File</div>\r\nThe Master File modules lets you manage referential data that will be used by another modules. It include Authority File management such     as Authority, Subject/Topic List, GMD and other data.</td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon systemIcon\" href=\"?mod=system\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">System</div>\r\nThe System module is used to configure application globally.</td>\r\n</tr>\r\n<tr>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon reportIcon\" href=\"?mod=reporting\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Reporting</div>\r\n<p>Reporting lets you view various type of reports regardings membership data, circulation data and bibliographic data. All compiled on-the-fly from         current library database.</p>\r\n<br /></td>\r\n<td width=\"5%\" valign=\"top\"><a class=\"icon serialIcon\" href=\"?mod=serial_control\"></a></td>\r\n<td width=\"45%\" valign=\"top\">\r\n<div class=\"heading\">Serial Control</div>\r\nSerial Control module help you manage library\'s serial publication subscription. You can track issues for each subscription.\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>','adminhome','2009-09-13 19:48:16','2009-09-13 22:02:11'),(4,'Homepage Info','<p>Welcome To <strong>Triz\'s</strong> Online Public Access Catalog (OPAC). Use OPAC to search collection in our library.</p>','headerinfo','2009-09-13 19:48:16','2011-01-10 17:38:48');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_title` text COLLATE utf8_unicode_ci NOT NULL,
  `file_name` text COLLATE utf8_unicode_ci NOT NULL,
  `file_url` text COLLATE utf8_unicode_ci,
  `file_dir` text COLLATE utf8_unicode_ci,
  `mime_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_desc` text COLLATE utf8_unicode_ci,
  `uploader_id` int(11) NOT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  FULLTEXT KEY `file_name` (`file_name`),
  FULLTEXT KEY `file_dir` (`file_dir`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fines`
--

DROP TABLE IF EXISTS `fines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fines` (
  `fines_id` int(11) NOT NULL AUTO_INCREMENT,
  `fines_date` date NOT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `debet` int(11) DEFAULT '0',
  `credit` int(11) DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`fines_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fines`
--

LOCK TABLES `fines` WRITE;
/*!40000 ALTER TABLE `fines` DISABLE KEYS */;
/*!40000 ALTER TABLE `fines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_access`
--

DROP TABLE IF EXISTS `group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_access` (
  `group_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `r` int(1) NOT NULL DEFAULT '0',
  `w` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`,`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_access`
--

LOCK TABLES `group_access` WRITE;
/*!40000 ALTER TABLE `group_access` DISABLE KEYS */;
INSERT INTO `group_access` VALUES (1,1,1,1),(1,2,1,1),(1,3,1,1),(1,4,1,1),(1,5,1,1),(1,6,1,1),(1,7,1,1),(1,8,1,1),(2,1,1,0),(2,2,1,0),(2,3,1,0),(2,4,1,0),(2,5,1,0),(2,6,1,0),(2,7,1,0),(2,8,1,0);
/*!40000 ALTER TABLE `group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holiday` (
  `holiday_id` int(11) NOT NULL AUTO_INCREMENT,
  `holiday_dayname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `holiday_date` date DEFAULT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`holiday_id`),
  UNIQUE KEY `holiday_dayname` (`holiday_dayname`,`holiday_date`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday`
--

LOCK TABLES `holiday` WRITE;
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
INSERT INTO `holiday` VALUES (1,'Mon','2009-06-01','Tes Libur'),(2,'Tue','2009-06-02','Tes Libur'),(3,'Wed','2009-06-03','Tes Libur'),(4,'Thu','2009-06-04','Tes Libur'),(5,'Fri','2009-06-05','Tes Libur'),(6,'Sat','2009-06-06','Tes Libur');
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `biblio_id` int(11) DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coll_type_id` int(3) DEFAULT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inventory_code` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `supplier_id` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_no` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `item_status_id` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `site` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` int(1) NOT NULL DEFAULT '0',
  `invoice` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `price_currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `input_date` datetime NOT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `item_references_idx` (`coll_type_id`,`location_id`,`item_status_id`),
  KEY `biblio_id_idx` (`biblio_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (2,2,'1001',2,'101','201001','2011-01-10','0','301','SL','2011-01-10','0','Library',1,'501',200,'Ruppee','2011-01-10','2011-01-10 16:26:35','2011-01-10 16:26:35'),(3,2,'1001',2,'102','201002','2011-01-10','0','302','SL','2011-01-10','0','Library',1,'502',200,'Ruppee','2011-01-10','2011-01-10 16:41:02','2011-01-10 16:41:02'),(4,2,'1001',2,'103','201003','2011-01-10','0','303','SL','2011-01-10','0','Library',1,'503',200,NULL,'2011-01-10','2011-01-10 16:41:36','2011-01-10 16:41:36'),(5,1,'',2,'201',NULL,'2011-01-11','0','','SL','2011-01-11','0','',1,'',0,NULL,'2011-01-11','2011-01-11 12:19:46','2011-01-11 12:19:46'),(6,3,'',2,'301',NULL,'2011-01-06','0','','SL','2011-01-01','0','',1,'',0,NULL,'2011-01-11','2011-01-11 12:26:24','2011-01-11 12:26:24');
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kardex`
--

DROP TABLE IF EXISTS `kardex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kardex` (
  `kardex_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_expected` date NOT NULL,
  `date_received` date DEFAULT NULL,
  `seq_number` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `serial_id` int(11) DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`kardex_id`),
  KEY `fk_serial` (`serial_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kardex`
--

LOCK TABLES `kardex` WRITE;
/*!40000 ALTER TABLE `kardex` DISABLE KEYS */;
/*!40000 ALTER TABLE `kardex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `loan_date` date NOT NULL,
  `due_date` date NOT NULL,
  `renewed` int(11) NOT NULL DEFAULT '0',
  `loan_rules_id` int(11) NOT NULL DEFAULT '0',
  `actual` date DEFAULT NULL,
  `is_lent` int(11) NOT NULL DEFAULT '0',
  `is_return` int(11) NOT NULL DEFAULT '0',
  `return_date` date DEFAULT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `item_code` (`item_code`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (1,'101','harshit','2011-01-10','2011-01-17',0,0,NULL,1,1,'2011-01-10'),(2,'101','1','2011-01-10','2011-01-25',0,1,NULL,1,1,'2011-01-11'),(3,'101','1','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-11'),(4,'102','harshit','2011-01-11','2011-01-26',0,1,NULL,1,1,'2011-01-11'),(5,'101','3','2011-01-11','2011-01-26',1,1,NULL,1,0,'2011-01-11');
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `member_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(1) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `member_type_id` int(6) DEFAULT NULL,
  `member_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inst_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_new` int(1) DEFAULT NULL,
  `member_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pin` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_fax` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_since_date` date DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  `expire_date` date NOT NULL,
  `member_notes` text COLLATE utf8_unicode_ci,
  `is_pending` smallint(1) NOT NULL DEFAULT '0',
  `mpasswd` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `member_name` (`member_name`),
  KEY `member_type_id` (`member_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('M00001','Hendro Wicaksono',1,'1974-06-05',1,'','hendrowicaksono@yahoo.com','','Perpustakaan Depdiknas',NULL,NULL,'','','','2009-04-15','2009-04-15','2010-04-15','',0,NULL,NULL,NULL,'2009-04-15','2009-06-11'),('M00002','Arie Nugraha',1,'1982-12-06',1,'','dicarve@yahoo.com','','Perpustakaan Depdiknas',NULL,NULL,'','','','2009-04-15','2009-04-15','2010-04-15','',0,NULL,NULL,NULL,'2009-04-15','2009-06-11'),('1','iresh',1,'1992-01-10',1,'','ireshparmar@gmail.com','','',NULL,NULL,'','','','2011-01-10','2011-01-10','2012-01-10','',0,'e8803a533120facc671d141febf14c32','2011-01-10 18:20:18','127.0.0.1','2011-01-10','2011-01-10'),('harshit','harshit bhatt',1,'2011-01-26',1,'surat','hbhatt26@gmail.com','395003','Tatva Foundation',NULL,NULL,'','','','2011-01-10','2011-01-10','2012-01-10','',0,'e99a18c428cb38d5f260853678922e03','2011-01-10 16:50:41','127.0.0.1','2011-01-10','2011-01-10'),('3','hiren',1,'1994-01-11',1,'','','','',NULL,NULL,'','','','2011-01-01','2011-01-11','2012-01-11','',0,'ec560dff9aaf87483e469b6abd8cd50c',NULL,NULL,'2011-01-11','2011-01-11');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_author`
--

DROP TABLE IF EXISTS `mst_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `authority_type` enum('p','o','c') COLLATE utf8_unicode_ci DEFAULT 'p',
  `auth_list` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  UNIQUE KEY `author_name` (`author_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_author`
--

LOCK TABLES `mst_author` WRITE;
/*!40000 ALTER TABLE `mst_author` DISABLE KEYS */;
INSERT INTO `mst_author` VALUES (1,'iresh','p',NULL,'2011-01-10','2011-01-10'),(2,'Rojar Pressman','p',NULL,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_coll_type`
--

DROP TABLE IF EXISTS `mst_coll_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_coll_type` (
  `coll_type_id` int(3) NOT NULL AUTO_INCREMENT,
  `coll_type_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`coll_type_id`),
  UNIQUE KEY `coll_type_name` (`coll_type_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_coll_type`
--

LOCK TABLES `mst_coll_type` WRITE;
/*!40000 ALTER TABLE `mst_coll_type` DISABLE KEYS */;
INSERT INTO `mst_coll_type` VALUES (1,'Reference','2007-11-29','2007-11-29'),(2,'Textbook','2007-11-29','2007-11-29'),(3,'Fiction','2007-11-29','2007-11-29');
/*!40000 ALTER TABLE `mst_coll_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_frequency`
--

DROP TABLE IF EXISTS `mst_frequency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_frequency` (
  `frequency_id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `language_prefix` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_increment` smallint(6) DEFAULT NULL,
  `time_unit` enum('day','week','month','year') COLLATE utf8_unicode_ci DEFAULT 'day',
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`frequency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_frequency`
--

LOCK TABLES `mst_frequency` WRITE;
/*!40000 ALTER TABLE `mst_frequency` DISABLE KEYS */;
INSERT INTO `mst_frequency` VALUES (1,'Weekly','en',1,'week','2009-05-23','2009-05-23'),(2,'Bi-weekly','en',2,'week','2009-05-23','2009-05-23'),(3,'Fourth-Nightly','en',14,'day','2009-05-23','2009-05-23'),(4,'Monthly','en',1,'month','2009-05-23','2009-05-23'),(5,'Bi-Monthly','en',2,'month','2009-05-23','2009-05-23'),(6,'Quarterly','en',3,'month','2009-05-23','2009-05-23'),(7,'3 Times a Year','en',4,'month','2009-05-23','2009-05-23'),(8,'Annualy','en',1,'year','2009-05-23','2009-05-23');
/*!40000 ALTER TABLE `mst_frequency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_gmd`
--

DROP TABLE IF EXISTS `mst_gmd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_gmd` (
  `gmd_id` int(11) NOT NULL AUTO_INCREMENT,
  `gmd_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmd_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `icon_image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`gmd_id`),
  UNIQUE KEY `gmd_name` (`gmd_name`),
  UNIQUE KEY `gmd_code` (`gmd_code`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_gmd`
--

LOCK TABLES `mst_gmd` WRITE;
/*!40000 ALTER TABLE `mst_gmd` DISABLE KEYS */;
INSERT INTO `mst_gmd` VALUES (1,'TE','Text',NULL,'2011-01-10','2011-01-10'),(2,'AR','Art Original',NULL,'2011-01-10','2011-01-10'),(3,'CH','Chart',NULL,'2011-01-10','2011-01-10'),(4,'CO','Computer Software',NULL,'2011-01-10','2011-01-10'),(5,'DI','Diorama',NULL,'2011-01-10','2011-01-10'),(6,'FI','Filmstrip',NULL,'2011-01-10','2011-01-10'),(7,'FL','Flash Card',NULL,'2011-01-10','2011-01-10'),(8,'GA','Game',NULL,'2011-01-10','2011-01-10'),(9,'GL','Globe',NULL,'2011-01-10','2011-01-10'),(10,'KI','Kit',NULL,'2011-01-10','2011-01-10'),(11,'MA','Map',NULL,'2011-01-10','2011-01-10'),(12,'MI','Microform',NULL,'2011-01-10','2011-01-10'),(13,'MN','Manuscript',NULL,'2011-01-10','2011-01-10'),(14,'MO','Model',NULL,'2011-01-10','2011-01-10'),(15,'MP','Motion Picture',NULL,'2011-01-10','2011-01-10'),(16,'MS','Microscope Slide',NULL,'2011-01-10','2011-01-10'),(17,'MU','Music',NULL,'2011-01-10','2011-01-10'),(18,'PI','Picture',NULL,'2011-01-10','2011-01-10'),(19,'RE','Realia',NULL,'2011-01-10','2011-01-10'),(20,'SL','Slide',NULL,'2011-01-10','2011-01-10'),(21,'SO','Sound Recording',NULL,'2011-01-10','2011-01-10'),(22,'TD','Technical Drawing',NULL,'2011-01-10','2011-01-10'),(23,'TR','Transparency',NULL,'2011-01-10','2011-01-10'),(24,'VI','Video Recording',NULL,'2011-01-10','2011-01-10'),(25,'EQ','Equipment',NULL,'2011-01-10','2011-01-10'),(26,'CF','Computer File',NULL,'2011-01-10','2011-01-10'),(27,'CA','Cartographic Material',NULL,'2011-01-10','2011-01-10'),(28,'CD','CD-ROM',NULL,'2011-01-10','2011-01-10'),(29,'MV','Multimedia',NULL,'2011-01-10','2011-01-10'),(30,'ER','Electronic Resource',NULL,'2011-01-10','2011-01-10'),(31,'DVD','Digital Versatile Disc',NULL,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_gmd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_item_status`
--

DROP TABLE IF EXISTS `mst_item_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_item_status` (
  `item_status_id` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `item_status_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `rules` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_loan` smallint(1) NOT NULL DEFAULT '0',
  `skip_stock_take` smallint(1) NOT NULL DEFAULT '0',
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`item_status_id`),
  UNIQUE KEY `item_status_name` (`item_status_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_item_status`
--

LOCK TABLES `mst_item_status` WRITE;
/*!40000 ALTER TABLE `mst_item_status` DISABLE KEYS */;
INSERT INTO `mst_item_status` VALUES ('R','Repair','a:1:{i:0;s:1:\"1\";}',0,0,'2011-01-10','2011-01-10'),('NL','No Loan','a:1:{i:0;s:1:\"1\";}',0,0,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_item_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_label`
--

DROP TABLE IF EXISTS `mst_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_label` (
  `label_id` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `label_desc` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `label_image` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`label_id`),
  UNIQUE KEY `label_name` (`label_name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_label`
--

LOCK TABLES `mst_label` WRITE;
/*!40000 ALTER TABLE `mst_label` DISABLE KEYS */;
INSERT INTO `mst_label` VALUES (1,'label-new','New Title','label-new.png','2011-01-10','2011-01-10'),(2,'label-favorite','Favorite Title','label-favorite.png','2011-01-10','2011-01-10'),(3,'label-multimedia','Multimedia','label-multimedia.png','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_language`
--

DROP TABLE IF EXISTS `mst_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_language` (
  `language_id` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `language_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `language_name` (`language_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_language`
--

LOCK TABLES `mst_language` WRITE;
/*!40000 ALTER TABLE `mst_language` DISABLE KEYS */;
INSERT INTO `mst_language` VALUES ('id','Indonesia','2011-01-10','2011-01-10'),('en','English','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_loan_rules`
--

DROP TABLE IF EXISTS `mst_loan_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_loan_rules` (
  `loan_rules_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_id` int(11) NOT NULL DEFAULT '0',
  `coll_type_id` int(11) DEFAULT '0',
  `gmd_id` int(11) DEFAULT '0',
  `loan_limit` int(3) DEFAULT '0',
  `loan_periode` int(3) DEFAULT '0',
  `reborrow_limit` int(3) DEFAULT '0',
  `fine_each_day` int(3) DEFAULT '0',
  `grace_periode` int(2) DEFAULT '0',
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`loan_rules_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_loan_rules`
--

LOCK TABLES `mst_loan_rules` WRITE;
/*!40000 ALTER TABLE `mst_loan_rules` DISABLE KEYS */;
INSERT INTO `mst_loan_rules` VALUES (1,1,2,1,15,15,15,5,5,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_loan_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_location`
--

DROP TABLE IF EXISTS `mst_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_location` (
  `location_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `location_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_name` (`location_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_location`
--

LOCK TABLES `mst_location` WRITE;
/*!40000 ALTER TABLE `mst_location` DISABLE KEYS */;
INSERT INTO `mst_location` VALUES ('SL','My Library','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_member_type`
--

DROP TABLE IF EXISTS `mst_member_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_member_type` (
  `member_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_type_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `loan_limit` int(11) NOT NULL,
  `loan_periode` int(11) NOT NULL,
  `enable_reserve` int(1) NOT NULL DEFAULT '0',
  `reserve_limit` int(11) NOT NULL DEFAULT '0',
  `member_periode` int(11) NOT NULL,
  `reborrow_limit` int(11) NOT NULL,
  `fine_each_day` int(11) NOT NULL,
  `grace_periode` int(2) DEFAULT '0',
  `input_date` date NOT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`member_type_id`),
  UNIQUE KEY `member_type_name` (`member_type_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_member_type`
--

LOCK TABLES `mst_member_type` WRITE;
/*!40000 ALTER TABLE `mst_member_type` DISABLE KEYS */;
INSERT INTO `mst_member_type` VALUES (1,'Standard',2,7,1,2,365,1,0,0,'2011-01-10','2011-01-11');
/*!40000 ALTER TABLE `mst_member_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_module`
--

DROP TABLE IF EXISTS `mst_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_module` (
  `module_id` int(3) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `module_path` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_desc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `module_name` (`module_name`,`module_path`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_module`
--

LOCK TABLES `mst_module` WRITE;
/*!40000 ALTER TABLE `mst_module` DISABLE KEYS */;
INSERT INTO `mst_module` VALUES (1,'bibliography','bibliography','Manage your bibliographic/catalog and items/copies database'),(2,'circulation','circulation','Module for doing library items circulation such as loan and return'),(3,'membership','membership','Manage your library membership and membership type'),(4,'master_file','master_file','Manage your referential data that will be used by other modules'),(5,'stock_take','stock_take','Ease your pain in doing library stock opname process'),(6,'system','system','Configure system behaviour, user and backups'),(7,'reporting','reporting','Real time and dynamic report about library collections and circulation'),(8,'serial_control','serial_control','Serial publication management');
/*!40000 ALTER TABLE `mst_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_place`
--

DROP TABLE IF EXISTS `mst_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_place` (
  `place_id` int(11) NOT NULL AUTO_INCREMENT,
  `place_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`place_id`),
  UNIQUE KEY `place_name` (`place_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_place`
--

LOCK TABLES `mst_place` WRITE;
/*!40000 ALTER TABLE `mst_place` DISABLE KEYS */;
INSERT INTO `mst_place` VALUES (1,'UK','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_place` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_publisher`
--

DROP TABLE IF EXISTS `mst_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_publisher` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `publisher_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`publisher_id`),
  UNIQUE KEY `publisher_name` (`publisher_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_publisher`
--

LOCK TABLES `mst_publisher` WRITE;
/*!40000 ALTER TABLE `mst_publisher` DISABLE KEYS */;
INSERT INTO `mst_publisher` VALUES (1,'PBP','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_supplier`
--

DROP TABLE IF EXISTS `mst_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_supplier` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` char(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` char(14) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `e_mail` char(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  UNIQUE KEY `supplier_name` (`supplier_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_supplier`
--

LOCK TABLES `mst_supplier` WRITE;
/*!40000 ALTER TABLE `mst_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `mst_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mst_topic`
--

DROP TABLE IF EXISTS `mst_topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mst_topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `topic` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `topic_type` enum('t','g','n','tm','gr','oc') COLLATE utf8_unicode_ci NOT NULL,
  `auth_list` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic` (`topic`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mst_topic`
--

LOCK TABLES `mst_topic` WRITE;
/*!40000 ALTER TABLE `mst_topic` DISABLE KEYS */;
INSERT INTO `mst_topic` VALUES (1,'Communication','t',NULL,'2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `mst_topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserve`
--

DROP TABLE IF EXISTS `reserve`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserve` (
  `reserve_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `biblio_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `reserve_date` datetime NOT NULL,
  PRIMARY KEY (`reserve_id`),
  KEY `references_idx` (`member_id`,`biblio_id`),
  KEY `item_code_idx` (`item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserve`
--

LOCK TABLES `reserve` WRITE;
/*!40000 ALTER TABLE `reserve` DISABLE KEYS */;
/*!40000 ALTER TABLE `reserve` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serial`
--

DROP TABLE IF EXISTS `serial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serial` (
  `serial_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date DEFAULT NULL,
  `period` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `biblio_id` int(11) DEFAULT NULL,
  `gmd_id` int(11) DEFAULT NULL,
  `input_date` date NOT NULL,
  `last_update` date NOT NULL,
  PRIMARY KEY (`serial_id`),
  KEY `fk_serial_biblio` (`biblio_id`),
  KEY `fk_serial_gmd` (`gmd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serial`
--

LOCK TABLES `serial` WRITE;
/*!40000 ALTER TABLE `serial` DISABLE KEYS */;
/*!40000 ALTER TABLE `serial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `setting_id` int(3) NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `setting_name` (`setting_name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'library_name','s:4:\"Triz\";'),(2,'library_subname','s:37:\"Open Source Library Management System\";'),(3,'template','a:2:{s:5:\"theme\";s:7:\"default\";s:3:\"css\";s:26:\"template/default/style.css\";}'),(4,'admin_template','a:2:{s:5:\"theme\";s:7:\"default\";s:3:\"css\";s:32:\"admin_template/default/style.css\";}'),(5,'default_lang','s:5:\"en_US\";'),(6,'opac_result_num','s:2:\"10\";'),(7,'enable_promote_titles','a:1:{i:0;s:1:\"1\";}'),(8,'quick_return','b:1;'),(9,'allow_loan_date_change','b:1;'),(10,'loan_limit_override','b:1;'),(11,'enable_xml_detail','b:1;'),(12,'enable_xml_result','b:1;'),(13,'allow_file_download','b:1;'),(14,'session_timeout','s:4:\"7200\";'),(15,'circulation_receipt','b:1;'),(16,'barcode_encoding','s:4:\"128B\";');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take`
--

DROP TABLE IF EXISTS `stock_take`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take` (
  `stock_take_id` int(11) NOT NULL AUTO_INCREMENT,
  `stock_take_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `init_user` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `total_item_stock_taked` int(11) DEFAULT NULL,
  `total_item_lost` int(11) DEFAULT NULL,
  `total_item_exists` int(11) DEFAULT '0',
  `total_item_loan` int(11) DEFAULT NULL,
  `stock_take_users` mediumtext COLLATE utf8_unicode_ci,
  `is_active` int(1) NOT NULL DEFAULT '0',
  `report_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`stock_take_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take`
--

LOCK TABLES `stock_take` WRITE;
/*!40000 ALTER TABLE `stock_take` DISABLE KEYS */;
INSERT INTO `stock_take` VALUES (1,'h','2011-01-10 15:51:53','2011-01-10 14:21:49','Administrator',1,1,0,0,'Administrator\n',0,'h_report.html'),(2,'h','2011-01-11 13:09:18',NULL,'Administrator',4,4,0,1,'Administrator\n',1,NULL);
/*!40000 ALTER TABLE `stock_take` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_take_item`
--

DROP TABLE IF EXISTS `stock_take_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_take_item` (
  `stock_take_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gmd_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `classification` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `coll_type_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('e','m','u','l') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'm',
  `checked_by` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_update` datetime DEFAULT NULL,
  PRIMARY KEY (`stock_take_id`,`item_id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `status` (`status`),
  KEY `item_properties_idx` (`gmd_name`,`classification`,`coll_type_name`,`location`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_take_item`
--

LOCK TABLES `stock_take_item` WRITE;
/*!40000 ALTER TABLE `stock_take_item` DISABLE KEYS */;
INSERT INTO `stock_take_item` VALUES (2,2,'101','Communication Skill','Text','','Textbook','1001','My Library','l','Administrator',NULL),(2,3,'102','Communication Skill','Text','','Textbook','1001','My Library','m','Administrator',NULL),(2,4,'103','Communication Skill','Text','','Textbook','1001','My Library','m','Administrator',NULL),(2,5,'201','science','Text','','Textbook','','My Library','m','Administrator',NULL),(2,6,'301','biology','Text','','Textbook','','My Library','m','Administrator',NULL);
/*!40000 ALTER TABLE `stock_take_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_log`
--

DROP TABLE IF EXISTS `system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` enum('staff','member','system') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'staff',
  `id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_location` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `log_msg` text COLLATE utf8_unicode_ci NOT NULL,
  `log_date` datetime NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_log`
--

LOCK TABLES `system_log` WRITE;
/*!40000 ALTER TABLE `system_log` DISABLE KEYS */;
INSERT INTO `system_log` VALUES (1,'staff','iresh','Login','Login FAILED for user iresh from address 127.0.0.1','2011-01-10 14:14:50'),(2,'staff','iresh','Login','Login FAILED for user iresh from address 127.0.0.1','2011-01-10 14:15:53'),(3,'staff','iresh','Login','Login FAILED for user iresh from address 127.0.0.1','2011-01-10 14:17:26'),(4,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 14:19:29'),(5,'member','','circulation','Administrator start transaction with member ()','2011-01-10 14:27:44'),(6,'staff','1','bibliography','Administrator insert bibliographic data (science) with biblio_id (1)','2011-01-10 15:18:57'),(7,'staff','1','membership','Administrator add new member (iresh) with ID (1)','2011-01-10 15:25:39'),(8,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 15:25:44'),(9,'staff','iresh','Login','Login FAILED for user iresh from address 127.0.0.1','2011-01-10 15:25:57'),(10,'staff','iresh','Login','Login FAILED for user iresh from address 127.0.0.1','2011-01-10 15:26:05'),(11,'member','iresh','Login','Login FAILED for member iresh from address 127.0.0.1','2011-01-10 15:26:16'),(12,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-10 15:27:08'),(13,'staff','','system','Log Out from application from address 127.0.0.1','2011-01-10 15:30:31'),(14,'staff','','system','Log Out from application from address 127.0.0.1','2011-01-10 15:30:33'),(15,'member','','Login','Log Out from address 127.0.0.1','2011-01-10 15:30:51'),(16,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 15:31:00'),(17,'member','1','circulation','Administrator start transaction with member (1)','2011-01-10 15:31:09'),(18,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-10 15:31:23'),(19,'member','1','circulation','Administrator start transaction with member (1)','2011-01-10 15:31:52'),(20,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 15:32:18'),(21,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 15:32:27'),(22,'staff','1','bibliography','Administrator update bibliographic data (science) with biblio_id ()','2011-01-10 15:35:37'),(23,'staff','1','bibliography','Administrator insert item data (1) with title (science)','2011-01-10 15:39:39'),(24,'staff','1','bibliography','Administrator updating file attachment data','2011-01-10 15:40:24'),(25,'staff','1','bibliography','Administrator update bibliographic data (science) with biblio_id ()','2011-01-10 15:40:37'),(26,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-10 15:41:10'),(27,'staff','1','system','Administrator change application global configuration','2011-01-10 15:47:55'),(28,'staff','1','system','Administrator change application global configuration','2011-01-10 15:49:01'),(29,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 15:49:19'),(30,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 15:50:21'),(31,'staff','1','system','Administrator change application global configuration','2011-01-10 15:50:39'),(32,'staff','1','system','Administrator change application global configuration','2011-01-10 15:50:50'),(33,'staff','1','stock_take','Administrator initialize stock take (h) from address 127.0.0.1','2011-01-10 15:51:53'),(34,'staff','1','stock_take','Administrator finish stock take (h) from address 127.0.0.1','2011-01-10 15:52:13'),(35,'member','1','circulation','Administrator start transaction with member (1)','2011-01-10 15:53:34'),(36,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-10 15:57:10'),(37,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 16:01:16'),(38,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 16:02:53'),(39,'staff','1','system','Administrator add new group (Students)','2011-01-10 16:07:29'),(40,'staff','1','system','Administrator add new user (harshit) with username (harshit)','2011-01-10 16:08:00'),(41,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-10 16:16:04'),(42,'staff','1','membership','Administrator add new member (harshit bhatt) with ID (harshit)','2011-01-10 16:18:44'),(43,'staff','1','membership','Administrator update member data (harshit bhatt) with ID (harshit)','2011-01-10 16:19:22'),(44,'staff','1','bibliography','Administrator insert bibliographic data (Communication Skill) with biblio_id (2)','2011-01-10 16:24:44'),(45,'staff','1','bibliography','Administrator insert item data (101) with title (Communication Skill)','2011-01-10 16:26:35'),(46,'staff','1','bibliography','Administrator update bibliographic data (Communication Skill) with biblio_id ()','2011-01-10 16:26:45'),(47,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 16:32:12'),(48,'member','harshit','Login','Login FAILED for member harshit from address 127.0.0.1','2011-01-10 16:33:18'),(49,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-10 16:33:54'),(50,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 16:37:20'),(51,'staff','1','system','Administrator change application global configuration','2011-01-10 16:37:32'),(52,'staff','1','system','Administrator change application global configuration','2011-01-10 16:37:40'),(53,'staff','1','system','Administrator change application global configuration','2011-01-10 16:37:56'),(54,'staff','1','system','Administrator change application global configuration','2011-01-10 16:38:09'),(55,'staff','1','system','Administrator change application global configuration','2011-01-10 16:38:16'),(56,'staff','1','bibliography','Administrator insert item data (102) with title (Communication Skill)','2011-01-10 16:41:02'),(57,'staff','1','bibliography','Administrator insert item data (103) with title (Communication Skill)','2011-01-10 16:41:36'),(58,'staff','1','bibliography','Administrator update bibliographic data (Communication Skill) with biblio_id ()','2011-01-10 16:41:45'),(59,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 16:42:11'),(60,'member','harshit','Login','Login success for member harshit from address 127.0.0.1','2011-01-10 16:42:32'),(61,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 16:42:50'),(62,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-10 16:43:01'),(63,'member','harshit','circulation','Administrator finish circulation transaction with member (harshit)','2011-01-10 16:43:56'),(64,'member','harshit','circulation','Administrator return item (101) with title (Communication Skill) with Quick Return method','2011-01-10 16:45:32'),(65,'member','harshit','Login','Login success for member harshit from address 127.0.0.1','2011-01-10 16:46:24'),(66,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-10 16:46:44'),(67,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 16:47:31'),(68,'member','','Login','Log Out from address 127.0.0.1','2011-01-10 16:47:44'),(69,'member','harshit','Login','Login success for member harshit from address 127.0.0.1','2011-01-10 16:47:51'),(70,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 16:48:18'),(71,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-10 16:48:25'),(72,'member','harshit','Login','Login success for member harshit from address 127.0.0.1','2011-01-10 16:50:41'),(73,'member','','Login','Log Out from address 127.0.0.1','2011-01-10 16:51:13'),(74,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 16:53:03'),(75,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 17:08:16'),(76,'staff','1','system','Administrator change application global configuration','2011-01-10 17:09:10'),(77,'member','1','circulation','Administrator start transaction with member (1)','2011-01-10 17:15:35'),(78,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-10 17:17:40'),(79,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 17:18:09'),(80,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-10 17:18:22'),(81,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 17:22:47'),(82,'staff','1','system','Administrator change application global configuration','2011-01-10 17:23:08'),(83,'staff','1','system','Administrator change application global configuration','2011-01-10 17:23:36'),(84,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 17:36:35'),(85,'staff','1','system','update content data (Homepage Info) with contentname ()','2011-01-10 17:38:33'),(86,'staff','1','system','update content data (Homepage Info) with contentname ()','2011-01-10 17:38:48'),(87,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 17:45:22'),(88,'staff','1','system','Administrator change application global configuration','2011-01-10 17:45:41'),(89,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-10 18:11:38'),(90,'staff','1','system','Administrator change application global configuration','2011-01-10 18:11:50'),(91,'staff','1','system','Administrator change application global configuration','2011-01-10 18:12:27'),(92,'staff','1','system','Administrator change application global configuration','2011-01-10 18:16:23'),(93,'member','1','Login','Login success for member 1 from address 127.0.0.1','2011-01-10 18:20:18'),(94,'member','','Login','Log Out from address 127.0.0.1','2011-01-10 18:20:44'),(95,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-10 18:48:54'),(96,'staff','','system','Log Out from application from address 127.0.0.1','2011-01-10 18:51:58'),(97,'staff','','system','Log Out from application from address 127.0.0.1','2011-01-10 18:52:02'),(98,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-11 11:24:19'),(99,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-11 11:24:49'),(100,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-11 11:38:31'),(101,'staff','1','system','Administrator Log Out from application from address 127.0.0.1','2011-01-11 11:54:01'),(102,'staff','admin','Login','Login success for user admin from address 127.0.0.1','2011-01-11 11:54:08'),(103,'member','1','circulation','Administrator return item (101) with title (Communication Skill) with Quick Return method','2011-01-11 12:08:03'),(104,'member','1','circulation','Administrator start transaction with member (1)','2011-01-11 12:08:30'),(105,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-11 12:08:39'),(106,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-11 12:08:54'),(107,'member','harshit','circulation','Administrator finish circulation transaction with member (harshit)','2011-01-11 12:09:13'),(108,'member','1','circulation','Administrator return item (101) with title (Communication Skill) with Quick Return method','2011-01-11 12:09:18'),(109,'member','harshit','circulation','Administrator return item (102) with title (Communication Skill) with Quick Return method','2011-01-11 12:09:23'),(110,'member','1','circulation','Administrator start transaction with member (1)','2011-01-11 12:17:00'),(111,'staff','1','bibliography','Administrator insert item data (201) with title (science)','2011-01-11 12:19:46'),(112,'member','1','circulation','Administrator finish circulation transaction with member (1)','2011-01-11 12:20:26'),(113,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-11 12:20:33'),(114,'member','harshit','circulation','Administrator finish circulation transaction with member (harshit)','2011-01-11 12:20:49'),(115,'member','','circulation','Administrator start transaction with member ()','2011-01-11 12:20:59'),(116,'member','','circulation','Administrator start transaction with member ()','2011-01-11 12:21:04'),(117,'member','harshit','circulation','Administrator start transaction with member (harshit)','2011-01-11 12:21:21'),(118,'staff','1','bibliography','Administrator insert bibliographic data (301) with biblio_id (3)','2011-01-11 12:25:45'),(119,'staff','1','bibliography','Administrator insert item data (301) with title (301)','2011-01-11 12:26:24'),(120,'staff','1','bibliography','Administrator update bibliographic data (biology) with biblio_id ()','2011-01-11 12:27:03'),(121,'staff','1','membership','Administrator add new member (hiren) with ID (3)','2011-01-11 12:31:11'),(122,'member','harshit','circulation','Administrator finish circulation transaction with member (harshit)','2011-01-11 12:31:24'),(123,'member','3','circulation','Administrator start transaction with member (3)','2011-01-11 12:31:27'),(124,'member','3','circulation','Administrator finish circulation transaction with member (3)','2011-01-11 12:40:57'),(125,'member','3','circulation','Administrator start transaction with member (3)','2011-01-11 12:41:10'),(126,'member','3','circulation','Administrator extend loan for item 101 for member (3)','2011-01-11 12:41:19'),(127,'staff','1','stock_take','Administrator initialize stock take (h) from address 127.0.0.1','2011-01-11 13:09:18'),(128,'staff','1','stock_take','Stock Take Re-Synchronization','2011-01-11 13:10:13');
/*!40000 ALTER TABLE `system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `realname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `passwd` varchar(35) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT '0000-00-00',
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `realname` (`realname`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','Administrator','21232f297a57a5a743894a0e4a801fc3','2011-01-11 11:54:08','127.0.0.1','a:1:{i:0;s:1:\"1\";}','2011-01-10','2011-01-10'),(2,'iresh','Administrator','iresh',NULL,NULL,NULL,'0000-00-00',NULL),(3,'harshit','harshit','83a75f0b31435193bafd3b9c5fd45aec',NULL,NULL,'a:1:{i:0;s:1:\"2\";}','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
INSERT INTO `user_group` VALUES (1,'Administrator','2011-01-10','2011-01-10'),(2,'Students','2011-01-10','2011-01-10');
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_count`
--

DROP TABLE IF EXISTS `visitor_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visitor_count` (
  `visitor_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `institution` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `checkin_date` datetime NOT NULL,
  PRIMARY KEY (`visitor_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_count`
--

LOCK TABLES `visitor_count` WRITE;
/*!40000 ALTER TABLE `visitor_count` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitor_count` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-01-11 11:40:35
